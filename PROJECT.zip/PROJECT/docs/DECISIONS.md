# Decisions

Recorded when the spec was ambiguous. Simplest option chosen.

| Date | Decision | Rationale |
|---|---|---|
| 2026-09-28 | Claude model IDs: `CLAUDE_MODEL_DEV=claude-haiku-4-5`, `CLAUDE_MODEL_DEMO=claude-sonnet-5` | Current Anthropic docs (Haiku-class / Sonnet-class). Never hard-coded in agent code. |
| 2026-09-28 | TLS terminated by nginx on EC2 with a self-signed cert from `user_data` | Let's Encrypt HTTP-01 needs port 80 from the internet, which contradicts NFR-1 (ingress only from `allowed_ip_cidrs`). |
| 2026-09-28 | Architecture diagram labels the edge proxy as **nginx on EC2**, not ALB | Design mermaid said "ALB"; compute is a single EC2 instance. |
| 2026-09-28 | Vector index: HNSW cosine on `resume_chunks.embedding` | pgvector HNSW is the simpler default vs ivfflat (no train step). |
| 2026-09-28 | Password hashing: bcrypt via `passlib` | Standard, available, sufficient for a single seed user. |
| 2026-09-28 | JWT algorithm: HS256 | Simplest; secret from env / Secrets Manager. |
| 2026-09-28 | `LLM_MODE=fake` used in tests and local compose default for E2E | Tests must never hit Anthropic. |
| 2026-09-28 | Relative dates in tracker agent resolved with `datetime.date.today()` injected into the system prompt | Spec requires current date in the prompt. |
| 2026-09-28 | S3 buckets use `force_destroy = true` | Required so `terraform destroy` is clean for this project. |
| 2026-09-28 | Frontend JWT stored in `localStorage` | Spec requires refresh mid-interview to preserve session (E2E-05). |
| 2026-09-28 | Git repository lives in this project directory | Parent home-directory git must not receive this code. |
| 2026-09-28 | Local docker-compose nginx is HTTP on port 80 | TLS certs are generated on EC2 `user_data`. Compose would fail without those files. |
| 2026-09-28 | Tests patch `embed_texts` with a 384-d hash embedding | Avoids downloading MiniLM in CI unit jobs; production still uses sentence-transformers. |
