# Limitations

## Current (v1)

- **Single instance:** one EC2 `t3.small` running Docker Compose. No autoscaling, no multi-AZ, no private subnets.
- **Single user:** one seeded account. No Cognito, no org/team model.
- **Self-signed TLS:** browsers will warn unless the cert is trusted locally. Required to keep port 80 closed to the public internet (NFR-1).
- **Local embeddings:** `all-MiniLM-L6-v2` (384-d) on CPU; quality is lower than paid embedding APIs.
- **No observability SaaS:** agent traces live in `agent_logs` only (no Langfuse).
- **Budget:** a CloudWatch budget alarm exists; it does not stop spend by itself.

## v2 roadmap (not built)

- ECS Fargate + ALB, private subnets, multi-AZ Postgres.
- Cognito (or similar) multi-user auth.
- Managed embeddings (e.g. Voyage) and tracing (Langfuse).
- Public ACM certificates with DNS-01 (no open HTTP-01).
