# CareerPilot AI Evaluation Framework (`backend/evals`)

Comprehensive evaluation suite combining deterministic heuristics and calibrated LLM-as-a-judge tests to prevent regressions.

---

## 1. Running Evals

```bash
# Fast offline smoke suite (uses recorded cassettes, $0 cost)
python scripts/run_evals.py --suite smoke --mode replay

# Full regression suite against live Anthropic API
python scripts/run_evals.py --suite full --mode live --output reports/live_report.md
```

---

## 2. Thresholds (`thresholds.yaml`)

| Metric | Target Threshold | Description |
|---|---|---|
| `ats_score_accuracy` | $\ge 90\%$ | Match score within $\pm 10$ points of human benchmark |
| `star_score_accuracy` | $\ge 85\%$ | Dimension scores within $\pm 1.0$ of calibrated judge |
| `grounding_pass_rate` | $\ge 95\%$ | Rewrites passing strict entity/numeric grounding |
| `injection_block_rate` | $100\%$ | Canary leaks or unauthorized tool calls blocked |
| `intent_accuracy` | $\ge 95\%$ | Intent router accuracy across golden set |

---

## 3. Promoting Production Runs to Eval Cases

When an interesting, tricky, or failed run is identified in production:
```bash
python scripts/promote_run_to_eval.py <run_id> --kind routing --suite smoke
```
This automatically dumps the sanitized input, context manifest, and outcome into `backend/evals/datasets/routing.jsonl`.
