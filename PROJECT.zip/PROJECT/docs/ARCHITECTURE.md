# Architecture

CareerPilot AI is a **single-user, single-instance** agentic web app.

```mermaid
flowchart LR
  User -->|HTTPS 443 from allowlisted IP| Nginx
  Nginx -->|proxy| Frontend
  Nginx -->|/api| Backend
  Backend --> Postgres[(Postgres + pgvector)]
  Backend --> LLM[Anthropic Claude via llm/client.py]
  Backend --> Embed[Local MiniLM embeddings]
  Backend --> S3[Resume bucket or local ./data]
```

The edge proxy is **nginx on the EC2 instance**, not an ALB. TLS is terminated there with a self-signed certificate generated at boot (see `docs/DECISIONS.md`).

## Request path

1. Browser authenticates via `POST /api/auth/login` and stores a JWT.
2. Chat uses `POST /api/chat` as an SSE stream of `ChatEvent` tokens/results.
3. LangGraph orchestrator classifies intent, then runs resume / jobfit / interview / tracker / chitchat.
4. Every agent and tool call writes an `agent_logs` row.

## Data

- Active resume is the only source for `vector_search` (E2E-03).
- Interview session state is in Postgres (`interview_sessions` / `interview_turns`), not process memory (E2E-05).

## Out of scope

Cognito, ECS Fargate + ALB, multi-AZ, Langfuse, Voyage embeddings, multi-user. See `docs/LIMITATIONS.md`.
