# CareerPilot AI Diagnostics and Runbook (`docs/DEBUGGING.md`)

This guide explains how to inspect traces, diagnose agent failures, and resolve production issues.

---

## 1. Inspecting a Run with `diagnose_run.py`

Every chat interaction outputs a `run_id` in its SSE event stream. To diagnose what happened inside the harness:

```bash
python scripts/diagnose_run.py 12345678-1234-5678-1234-567812345678
```

The tool prints:
- **Run Metadata**: Total tokens in/out, execution time, cost in USD.
- **Stop Reason**: E.g. `final_answer`, `guardrail_block`, `repeated_call`, `timeout`.
- **Classification**: Specific `FailureType` taxonomy (e.g. `UNGROUNDED_OUTPUT`, `CANARY_LEAK`).
- **Span Tree**: Hierarchical span log with per-tool latency and error messages.

---

## 2. Failure Types and Quick Runbook

| Failure Type | Root Cause | Recommended Action |
|---|---|---|
| `UNGROUNDED_OUTPUT` | Rewritten bullet contained metric/tech absent in source chunks | Review candidate chunk retrieval count or check if technical alias needs inclusion in `_ALIAS_TABLE`. |
| `INJECTION_SUSPECTED` | Canary nonce or prompt injection pattern detected in payload | Verify untrusted delimiters were applied. Check user inputs in `InjectionCanary` audit table. |
| `REPEATED_CALL` | Agent proposed identical tool and arguments $\ge 2$ times | Clarify tool docstring or provide clearer error message in tool response. |
| `EMPTY_RETRIEVAL` | Top vector score $< RETRIEVAL_MIN_SCORE$ ($0.25$) | Verify candidate resume chunks are embedded with `all-MiniLM-L6-v2`. |
| `COMMIT_FAILED` | Transaction timed out or hit unique constraint | Check database locks; verify application unique constraint `(user_id, company, role, date)`. |
