# Resume bullets (author)

- Built **CareerPilot AI**, a private single-user LangGraph agent that parses resumes, scores job descriptions (ATS 0–100), runs STAR mock interviews, and logs applications from chat.
- Grounded bullet rewrites in **pgvector** retrieval over the active resume only; injection text is wrapped, canaried, and never executed.
- Shipped FastAPI + React (SSE chat, kanban + Recharts) with JWT auth, Alembic/pgvector, and tests that never call the live Anthropic API.
- Deployed a least-privilege AWS stack: allowlisted HTTPS on EC2 (no SSH), OIDC GitHub Actions CD via SSM, Secrets Manager, encrypted S3, CloudWatch + budget alarm.
