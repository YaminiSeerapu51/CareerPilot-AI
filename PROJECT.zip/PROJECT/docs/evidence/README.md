# Evidence

Placeholder for CI logs, Playwright traces, `terraform plan`, and SEC script output after a real deploy.

See `latency.txt` for the NFR-2 note used in the README.
