# CareerPilot AI Agent Harness (`app/harness`)

The **Harness** is the safety, execution, memory, and observability runtime that surrounds every LLM interaction. Agents propose actions; the harness enforces boundaries, tracks telemetry, validates outputs, and commits state.

---

## 1. Memory Architecture

| Memory Layer | Content | Storage Location | Writers | Readers |
|---|---|---|---|---|
| **Working** | Current turn: prompt messages, retrieved chunks, staged loop state | `RunContext` (in-memory) | Harness runtime | Sub-agent loop (this run only) |
| **Procedural** | Prompts, STAR rubrics, skills (`system_resume.md`, `star.yaml`, `bullet_rewrite.md`) | `app/harness/procedural_assets/` (versioned git assets) | Humans via PRs only | `PromptRegistry` |
| **Semantic** | Structured profile, extracted skills, parsed resumes, job keywords, learned facts | `resumes`, `resume_chunks`, `job_descriptions`, `memory_facts` | `MemoryWriter` | Hybrid/Vector Retrieval, `ContextBuilder` |
| **Episodic** | Historical interview turns, per-session summaries, application events, weakness trends | `interview_turns`, `session_summaries`, `application_events`, `runs` | Agents via tools, `SessionSummarizer` | `EpisodicStore`, `ContextBuilder` |

---

## 2. Hook Lifecycle

Mandatory runtime hooks installed at startup by `build_harness()` in deterministic phase order:

```mermaid
flowchart TD
    A[RUN_START] -->|mint_canary, start_trace, load_budget| B[Context Assembly]
    B --> C[PRE_LLM]
    C -->|enforce_untrusted_wrapping, budget_check| D[LLM Call]
    D --> E[POST_LLM]
    E -->|canary_scan, record_usage, schema_parse| F{Tool Call?}
    F -->|Yes| G[PRE_TOOL]
    G -->|permission_check, repeat_detector, confirmation_gate| H[Execute / Stage Tool]
    H --> I[POST_TOOL]
    I -->|record_tool_span, error_streak, progress_detector| C
    F -->|No| J[PRE_FINAL]
    J -->|final_gate: schema, canary, grounding, scope, claims| K[CommitCoordinator]
    K --> L[RUN_END]
```

---

## 3. Guarantees: Enforced vs. Heuristic

| Guarantee Class | Controls | Claim You Can Make |
|---|---|---|
| **Structural (Enforced in Code)** | Sealed bus, tool allow-lists, harness-injected `user_id`/`run_id`, staged writes + single commit, confirmation gate, unique DB constraints. | *"The model cannot perform unauthorized writes or confirm destructive actions, because the code execution path does not exist."* |
| **Heuristic (Risk Reduction)** | Sliding-window canary scan, system-prompt n-gram leak detection, deterministic entity grounding, prompt injection regexes, LLM judge. | *"This detects and blocks common injection patterns and metric hallucinations at a measured pass rate."* |

---

## 4. Staging and Commit Coordination

1. Write tools never mutate domain tables during intermediate reasoning steps.
2. Actions are validated and appended to `ctx.staged`.
3. If the loop stops due to timeout, repeat-call, or guardrail failure, `ctx.staged` is discarded.
4. Only upon `FINAL_ANSWER` and a passing `FinalGate` does `CommitCoordinator` open a single short transaction (`SET LOCAL statement_timeout = '5s'`) to persist staged actions, memory facts, and idempotency keys atomically.
