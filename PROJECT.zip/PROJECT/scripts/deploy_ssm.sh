#!/usr/bin/env bash
set -euo pipefail
INSTANCE_ID="${INSTANCE_ID:?set INSTANCE_ID}"
aws ssm send-command \
  --instance-ids "$INSTANCE_ID" \
  --document-name "AWS-RunShellScript" \
  --parameters 'commands=["cd /opt/careerpilot && docker compose pull && docker compose up -d"]'
