"""
scripts/promote_run_to_eval.py
──────────────────────────────
Promotes an actual production or test run into a labeled regression eval case.

Usage:
  python scripts/promote_run_to_eval.py <run_id> --kind routing|grounding|jobfit|interview [--suite smoke|full]
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from uuid import UUID

from sqlalchemy import select

# Add backend to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from app.db.models import Run
from app.db.session import SessionLocal


async def promote(run_id_str: str, kind: str, suite: str) -> None:
    try:
        run_id = UUID(run_id_str)
    except ValueError:
        print(f"Error: Invalid UUID '{run_id_str}'")
        sys.exit(1)

    async with SessionLocal() as db:
        res = await db.execute(select(Run).where(Run.id == run_id))
        run = res.scalar_one_or_none()
        if not run:
            print(f"Run '{run_id}' not found in database.")
            sys.exit(1)

        case = {
            "id": f"promoted_{str(run.id)[:8]}",
            "suite": suite,
            "kind": kind,
            "source": f"promoted_run:{run.id}",
            "intent": run.root_intent,
            "stop_reason": run.stop_reason,
            "tokens": {"in": run.total_tokens_in, "out": run.total_tokens_out},
            "expected": {"intent": run.root_intent},
        }

    target_file = Path(__file__).resolve().parent.parent / "backend" / "evals" / "datasets" / f"{kind}.jsonl"
    target_file.parent.mkdir(parents=True, exist_ok=True)

    with open(target_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(case) + "\n")

    print(f"✅ Successfully promoted run {run_id} to {target_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Promote a run to an eval test case")
    parser.add_argument("run_id", help="UUID of the run")
    parser.add_argument("--kind", choices=["routing", "grounding", "jobfit", "interview"], default="routing")
    parser.add_argument("--suite", choices=["smoke", "full"], default="smoke")
    args = parser.parse_args()

    asyncio.run(promote(args.run_id, args.kind, args.suite))
