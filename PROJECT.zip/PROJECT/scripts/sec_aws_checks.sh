#!/usr/bin/env bash
set -euo pipefail
# SEC-01/02/03/06 helpers. Requires AWS creds and INSTANCE_ID / SG_ID.
SG_ID="${SG_ID:?}"
echo "== SEC-03 no SSH =="
aws ec2 describe-security-groups --group-ids "$SG_ID" \
  --query 'SecurityGroups[0].IpPermissions[?FromPort==`22`]' --output text
echo "== SEC-01/02 ingress CIDRs =="
aws ec2 describe-security-groups --group-ids "$SG_ID" \
  --query 'SecurityGroups[0].IpPermissions[].IpRanges[].CidrIp' --output text
echo "Reject 0.0.0.0/0 on ingress (operator assertion)."
