"""
scripts/diagnose_run.py
───────────────────────
CLI utility to inspect and diagnose agent execution traces by run_id.

Usage:
  python scripts/diagnose_run.py <run_id>
"""
from __future__ import annotations

import asyncio
import sys
from uuid import UUID

from sqlalchemy import select

# Ensure backend root is on sys.path
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from app.db.models import Run, SpanModel
from app.db.session import SessionLocal
from app.harness.diagnosis.taxonomy import classify_failure


async def diagnose(run_id_str: str) -> None:
    try:
        run_id = UUID(run_id_str)
    except ValueError:
        print(f"Error: Invalid UUID '{run_id_str}'")
        sys.exit(1)

    async with SessionLocal() as db:
        run_res = await db.execute(select(Run).where(Run.id == run_id))
        run = run_res.scalar_one_or_none()
        if not run:
            print(f"Run {run_id} not found in database.")
            sys.exit(1)

        spans_res = await db.execute(
            select(SpanModel).where(SpanModel.run_id == run_id).order_by(SpanModel.started_at.asc())
        )
        spans = spans_res.scalars().all()

    print("=" * 70)
    print(f"RUN DIAGNOSTIC: {run.id}")
    print("=" * 70)
    print(f"User ID:       {run.user_id}")
    print(f"Root Intent:   {run.root_intent}")
    print(f"Stop Reason:   {run.stop_reason}")
    print(f"Tokens In/Out: {run.total_tokens_in} / {run.total_tokens_out}")
    print(f"Cost (USD):    ${run.cost_usd:.6f}")
    print(f"Started:       {run.started_at}")
    print(f"Ended:         {run.ended_at}")
    print("-" * 70)

    # Classify failure
    span_dicts = [
        {"kind": s.kind, "name": s.name, "latency_ms": s.latency_ms, "status": s.status, "error": s.error}
        for s in spans
    ]
    classification = classify_failure(run.stop_reason or "unknown", spans=span_dicts)

    print("CLASSIFICATION & ANOMALIES:")
    print(f"  Failure Types:      {[t.value for t in classification.failure_types]}")
    print(f"  Recoverable:        {classification.recoverable}")
    print(f"  Recommended Action: {classification.recommended_action}")
    print("-" * 70)

    print(f"SPAN TREE ({len(spans)} spans):")
    for s in spans:
        status_flag = "[OK]   " if s.status == "ok" else f"[{s.status.upper()}]"
        lat_str = f"{s.latency_ms}ms" if s.latency_ms is not None else "-"
        print(f"  {status_flag} {s.kind.ljust(10)} | {s.name.ljust(25)} | {lat_str.rjust(8)} | Tokens: {s.tokens_in}+{s.tokens_out}")
        if s.error:
            print(f"         └─ ERROR: {s.error}")
    print("=" * 70)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/diagnose_run.py <run_id>")
        sys.exit(1)
    asyncio.run(diagnose(sys.argv[1]))
