#!/usr/bin/env bash
set -euo pipefail
# Fail if common secret patterns appear in tracked files (SEC-04).
if git grep -E -n "(AKIA[0-9A-Z]{16}|sk-ant-api03-|BEGIN RSA PRIVATE KEY)" -- ':!.github' ':!docs' ':!scripts/check_no_secrets.sh'; then
  echo "Possible secret found in tracked files" >&2
  exit 1
fi
echo "SEC-04 pattern scan clean"
