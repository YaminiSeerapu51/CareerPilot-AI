#!/usr/bin/env bash
# scripts/hooks/block_secrets.sh
# Blocks tool operations attempting to read or write sensitive secret or state files.

INPUT=$(cat)

if echo "$INPUT" | grep -Eq '(\.env|\.tfstate|\.tfvars|secrets/)'; then
  echo "❌ BLOCKED: Access to secret or infrastructure state files is prohibited by security policy." >&2
  exit 1
fi

exit 0
