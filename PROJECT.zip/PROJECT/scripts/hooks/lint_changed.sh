#!/usr/bin/env bash
# scripts/hooks/lint_changed.sh
# Lints and runs fast unit checks on modified files.

ruff check backend/app
ruff format --check backend/app
pytest backend/tests/unit -q --maxfail=1
