"""
scripts/run_evals.py
────────────────────
CLI entrypoint to run offline or live evaluation suites.

Usage:
  python scripts/run_evals.py --suite smoke|full --mode replay|live --output reports/latest.md
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

# Add backend to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from evals.report import generate_report
from evals.runner import EvalMode, EvalRunner, EvalSuite


async def main() -> None:
    parser = argparse.ArgumentParser(description="CareerPilot AI Evaluation Runner")
    parser.add_argument("--suite", choices=["smoke", "full"], default="smoke")
    parser.add_argument("--mode", choices=["replay", "live"], default="replay")
    parser.add_argument("--output", default="reports/latest.md")
    args = parser.parse_args()

    suite = EvalSuite(args.suite)
    mode = EvalMode(args.mode)
    out_path = Path(args.output)

    print(f"Running CareerPilot AI eval suite='{suite.value}' in mode='{mode.value}'...")
    runner = EvalRunner(suite=suite, mode=mode)
    results = await runner.run()

    report_md = generate_report(results, output_path=out_path)
    print("\n" + report_md)

    if not results.get("overall_pass", False):
        print("[FAIL] EVALUATION FAILED (Threshold regression)")
        sys.exit(1)
    else:
        print("[PASS] ALL EVALUATION THRESHOLDS PASSED")
        sys.exit(0)


if __name__ == "__main__":
    asyncio.run(main())
