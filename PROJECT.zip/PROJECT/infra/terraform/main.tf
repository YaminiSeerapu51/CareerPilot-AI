# Root module wiring. Resources live in sibling .tf files.
