resource "aws_cloudwatch_log_group" "app" {
  name              = "/careerpilot/containers"
  retention_in_days = 14
}

resource "aws_budgets_budget" "monthly" {
  name         = "careerpilot-monthly"
  budget_type  = "COST"
  limit_amount = tostring(var.budget_limit_usd)
  limit_unit   = "USD"
  time_unit    = "MONTHLY"

  notification {
    comparison_operator        = "GREATER_THAN"
    threshold                  = 80
    threshold_type             = "PERCENTAGE"
    notification_type          = "ACTUAL"
    subscriber_email_addresses = [var.budget_email]
  }
}
