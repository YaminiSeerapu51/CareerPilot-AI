variable "region" {
  type    = string
  default = "us-east-1"
}

variable "instance_type" {
  type    = string
  default = "t3.small"
}

variable "budget_limit_usd" {
  type    = number
  default = 50
}

variable "budget_email" {
  type = string
}

variable "github_repo" {
  type        = string
  description = "owner/repo for GitHub OIDC"
}

variable "allowed_ip_cidrs" {
  type        = list(string)
  description = "Ingress allowlist for HTTPS. No default — must be set."

  validation {
    condition     = length(var.allowed_ip_cidrs) > 0 && !contains(var.allowed_ip_cidrs, "0.0.0.0/0")
    error_message = "Provide at least one CIDR and do not use 0.0.0.0/0."
  }
}
