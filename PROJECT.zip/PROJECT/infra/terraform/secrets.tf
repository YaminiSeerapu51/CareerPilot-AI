resource "aws_secretsmanager_secret" "anthropic" {
  name                    = "careerpilot/anthropic_api_key"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret" "jwt" {
  name                    = "careerpilot/jwt_secret"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret" "seed" {
  name                    = "careerpilot/seed_password"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret" "database" {
  name                    = "careerpilot/database_url"
  recovery_window_in_days = 0
}
