output "instance_id" {
  value = aws_instance.app.id
}

output "public_ip" {
  value = aws_instance.app.public_ip
}

output "resume_bucket" {
  value = aws_s3_bucket.resumes.bucket
}

output "github_oidc_role_arn" {
  value = aws_iam_role.github.arn
}
