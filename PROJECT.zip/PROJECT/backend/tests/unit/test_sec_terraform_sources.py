"""SEC-01/02/03/06 are scripted against AWS; this unit-checks Terraform sources."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3] / "infra" / "terraform"


def test_sec_sg_has_no_ssh_and_no_world_open() -> None:
    text = (ROOT / "security.tf").read_text(encoding="utf-8")
    assert "from_port   = 22" not in text
    assert 'cidr_blocks = var.allowed_ip_cidrs' in text
    assert "0.0.0.0/0" not in text.split("egress")[0]


def test_sec_06_iam_scoped() -> None:
    text = (ROOT / "iam.tf").read_text(encoding="utf-8")
    assert "AmazonSSMManagedInstanceCore" in text
    assert "repo:${var.github_repo}:ref:refs/heads/main" in text
