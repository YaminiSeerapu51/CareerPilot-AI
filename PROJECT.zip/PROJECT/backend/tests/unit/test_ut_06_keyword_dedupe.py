from app.tools.jobfit_tools import extract_jd_keywords


def test_ut_06_keyword_dedupe() -> None:
    text = "Python, python, PYTHON\nFastAPI\nfastapi"
    kws = extract_jd_keywords(text)
    lowered = [k.lower() for k in kws]
    assert lowered.count("python") == 1
    assert lowered.count("fastapi") == 1
