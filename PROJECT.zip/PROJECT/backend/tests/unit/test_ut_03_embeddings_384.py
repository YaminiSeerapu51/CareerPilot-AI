import asyncio

from app.tools.resume_tools import embed_chunks


def test_ut_03_embeddings_are_384_dim() -> None:
    vectors = asyncio.run(embed_chunks(["python fastapi sql"]))
    assert len(vectors) == 1
    assert len(vectors[0]) == 384
