from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta

from jose import jwt

from app.auth import create_access_token, decode_access_token
from app.config import Settings


def test_ut_05_jwt_with_1s_ttl_rejected_after_2s() -> None:
    settings = Settings(jwt_secret="unit-test-secret", jwt_ttl_seconds=1)
    from uuid import uuid4

    token = create_access_token(uuid4(), "demo@careerpilot.local", settings, ttl_seconds=1)
    payload = decode_access_token(token, settings)
    assert payload["email"] == "demo@careerpilot.local"

    expired = jwt.encode(
        {
            "sub": str(uuid4()),
            "email": "demo@careerpilot.local",
            "exp": datetime.now(UTC) - timedelta(seconds=1),
            "iat": datetime.now(UTC) - timedelta(seconds=3),
        },
        settings.jwt_secret,
        algorithm="HS256",
    )
    try:
        decode_access_token(expired, settings)
        raise AssertionError("expired token should be rejected")
    except Exception:
        pass

    token2 = create_access_token(uuid4(), "demo@careerpilot.local", settings, ttl_seconds=1)
    asyncio.run(asyncio.sleep(2))
    try:
        decode_access_token(token2, settings)
        raise AssertionError("TTL elapsed token must be rejected")
    except Exception:
        pass
