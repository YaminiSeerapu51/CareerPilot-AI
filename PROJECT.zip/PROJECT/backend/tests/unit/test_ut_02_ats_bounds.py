from hypothesis import given, settings, strategies as st

from app.schemas.resume import StructuredResume
from app.tools.jobfit_tools import compute_ats_score


@given(
    skills=st.lists(st.text(min_size=1, max_size=12), max_size=8),
    keywords=st.lists(st.text(min_size=1, max_size=12), max_size=8),
    sim=st.floats(min_value=-2.0, max_value=2.0, allow_nan=False, allow_infinity=False),
)
@settings(max_examples=40)
def test_ut_02_ats_bounds(skills: list[str], keywords: list[str], sim: float) -> None:
    resume = StructuredResume(skills=skills, experience=[], education=[])
    score = compute_ats_score(resume, keywords, sim)
    assert 0.0 <= score <= 100.0
