from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from app.tools.tracker_tools import SaveApplicationError, save_application


def test_ut_04_malformed_save_application_raises_writes_nothing() -> None:
    db = MagicMock()
    db.add = MagicMock()
    db.flush = AsyncMock()

    async def _run() -> None:
        with pytest.raises(SaveApplicationError):
            await save_application(db, uuid4(), {"company": "", "role": "SWE"})
        db.add.assert_not_called()

    asyncio.run(_run())
