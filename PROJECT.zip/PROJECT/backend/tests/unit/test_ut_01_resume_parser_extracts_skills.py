from pathlib import Path

from app.tools.resume_tools import extract_raw_text, parse_resume


def test_ut_01_resume_parser_extracts_skills(fixtures_dir: Path) -> None:
    pdf = (fixtures_dir / "sample_resume.pdf").read_bytes()
    text = extract_raw_text(pdf, "sample_resume.pdf")
    assert "Python" in text
    import asyncio

    from app.llm.client import FakeLLM

    structured = asyncio.run(parse_resume(pdf, "sample_resume.pdf", llm=FakeLLM()))
    assert structured.skills
    docx = (fixtures_dir / "sample_resume.docx").read_bytes()
    structured_docx = asyncio.run(parse_resume(docx, "sample_resume.docx", llm=FakeLLM()))
    assert structured_docx.skills
