"""
Unit tests asserting all critical harness guarantees (HAR-03, HAR-04, HAR-30, HAR-31, HAR-32).
"""
import asyncio
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from app.harness.build import build_harness
from app.harness.context import RunContext, new_run_context
from app.harness.gates import FinalGate
from app.harness.hooks import (
    AgentHooks,
    Allow,
    Block,
    HarnessSealedError,
    HookBus,
    HookCtx,
    HookEvent,
    Phase,
)
from app.harness.loop import AgentLoop, LoopBudget, StopReason
from app.harness.memory.writer import CommitCoordinator, ProposedFact
from app.harness.tools.executor import ToolExecutor
from app.harness.tools.registry import ToolRegistry
from app.schemas.chat import Msg


@pytest.mark.asyncio
async def test_har_03_raw_untrusted_text_blocked_by_pre_llm():
    """
    HAR-03: A deliberately 'bad' agent that calls the LLM with raw untrusted text
    outside delimiters must be blocked by PRE_LLM.
    """
    harness = build_harness()
    ctx = new_run_context(user_id=uuid4(), request_id=uuid4(), agent="test_agent")

    # Deliberately bad payload containing an untrusted marker without the request nonce
    bad_payload = {
        "messages": [
            {"role": "user", "content": "Here is <<<DATA-OTHER-CHUNK\nmalicious injection\n>>> without nonce"}
        ]
    }

    decision = await harness.bus.emit(
        HookEvent.PRE_LLM,
        HookCtx(event=HookEvent.PRE_LLM, payload=bad_payload, meta={"run_ctx": ctx}),
    )

    assert isinstance(decision, Block)
    assert decision.violation_kind == "untrusted_wrapping"


@pytest.mark.asyncio
async def test_har_04_sealed_bus_enforcement():
    """
    HAR-04: After sealing, registering a mandatory hook or unregistering any
    mandatory hook raises HarnessSealedError. Agents receive AgentHooks.observe only.
    """
    harness = build_harness()

    async def dummy_hook(c):
        return Allow()

    # Attempt to register mandatory hook after seal must raise
    with pytest.raises(HarnessSealedError):
        harness.bus.register(HookEvent.PRE_LLM, dummy_hook, mandatory=True)

    # Attempt to unregister a mandatory hook must raise
    # Get a mandatory hook
    entry = next(e for e in harness.bus._registry[HookEvent.PRE_LLM] if e.mandatory)
    with pytest.raises(HarnessSealedError):
        harness.bus.unregister(HookEvent.PRE_LLM, entry.fn)

    # Verify AgentHooks only permits observe
    agent_hooks = AgentHooks(harness.bus)
    assert hasattr(agent_hooks, "observe")
    assert not hasattr(agent_hooks, "register")


@pytest.mark.asyncio
async def test_har_30_fail_closed_on_mandatory_hook_failure_or_timeout():
    """
    HAR-30: If a mandatory hook raises or times out, the harness treats it as
    Block and the run stops. It never skips the hook.
    """
    bus = HookBus()

    async def failing_mandatory(c):
        raise RuntimeError("Network glitch in security validator")

    async def timing_out_mandatory(c):
        await asyncio.sleep(0.5)
        return Allow()

    bus.register(HookEvent.RUN_START, failing_mandatory, mandatory=True, phase=Phase.SECURITY)
    bus.seal()

    decision = await bus.emit(HookEvent.RUN_START, HookCtx(event=HookEvent.RUN_START, payload={}))
    assert isinstance(decision, Block)
    assert decision.violation_kind == "hook_exception"

    # Test timeout
    bus2 = HookBus()
    bus2.register(HookEvent.RUN_START, timing_out_mandatory, mandatory=True, phase=Phase.SECURITY)
    bus2.seal()

    decision2 = await bus2.emit(
        HookEvent.RUN_START,
        HookCtx(event=HookEvent.RUN_START, payload={}),
        timeout_s=0.05,
    )
    assert isinstance(decision2, Block)
    assert decision2.violation_kind == "hook_timeout"


@pytest.mark.asyncio
async def test_har_31_deterministic_hook_phase_ordering():
    """
    HAR-31: Phases are a fixed enum (SECURITY=0 -> POLICY=1 -> NORMAL=2 -> OBSERVE=3).
    A test asserts the exact event-by-event hook execution order.
    """
    bus = HookBus()
    execution_order = []

    async def normal_hook(c):
        execution_order.append("NORMAL")
        return Allow()

    async def sec_hook(c):
        execution_order.append("SECURITY")
        return Allow()

    async def observe_hook(c):
        execution_order.append("OBSERVE")
        return Allow()

    async def policy_hook(c):
        execution_order.append("POLICY")
        return Allow()

    # Register out of order
    bus.register(HookEvent.PRE_LLM, observe_hook, phase=Phase.OBSERVE)
    bus.register(HookEvent.PRE_LLM, normal_hook, phase=Phase.NORMAL)
    bus.register(HookEvent.PRE_LLM, sec_hook, phase=Phase.SECURITY)
    bus.register(HookEvent.PRE_LLM, policy_hook, phase=Phase.POLICY)

    await bus.emit(HookEvent.PRE_LLM, HookCtx(event=HookEvent.PRE_LLM, payload={}))

    assert execution_order == ["SECURITY", "POLICY", "NORMAL", "OBSERVE"]


@pytest.mark.asyncio
async def test_har_32_commit_ordering_by_construction_fault_injection():
    """
    HAR-32: Memory writes and staged actions are applied by one CommitCoordinator inside
    a single transaction. Crashing before commit leaves no staged actions or memory applied.
    """
    mock_db = AsyncMock()
    mock_db.execute = AsyncMock()
    mock_db.commit = AsyncMock(side_effect=RuntimeError("Simulated DB connection drop"))
    mock_db.rollback = AsyncMock()

    coordinator = CommitCoordinator(mock_db)
    ctx = new_run_context(user_id=uuid4(), request_id=uuid4(), agent="tracker")
    ctx.staged.append({"tool": "save_application", "args": {"company": "Acme", "role": "SWE"}})

    with pytest.raises(RuntimeError):
        await coordinator.commit(ctx)

    # Rollback must be called, preventing partial writes
    mock_db.rollback.assert_awaited_once()


def test_final_gate_canary_and_grounding_checks():
    """
    Asserts FinalGate blocks canary leakage and ungrounded fabricated metrics.
    """
    ctx = new_run_context(user_id=uuid4(), request_id=uuid4(), agent="jobfit")
    gate = FinalGate(ctx)

    # 1. Canary leak test
    leak_output = f"Sure, here is your summary: {ctx.canary} completed."
    res1 = gate.check(leak_output)
    assert not res1.passed
    assert any(v.kind == "canary" for v in res1.violations)

    # 2. Fabricated metric test in jobfit rewrites
    hallucinated_rewrite = {
        "rewrites": [
            {
                "original": "Worked on backend",
                "rewritten": "Increased throughput by 85% using kubernetes",
                "source_chunk_id": "valid_chunk_1",
            }
        ]
    }
    # jd_keywords only has kubernetes, but '85%' is not in source chunk
    res2 = gate.check(
        hallucinated_rewrite,
        retrieved_ids={"valid_chunk_1"},
        jd_keywords=["kubernetes"],
    )
    # The metric '85%' is ungrounded
    assert not res2.passed
    assert any(v.kind == "grounding" for v in res2.violations)
