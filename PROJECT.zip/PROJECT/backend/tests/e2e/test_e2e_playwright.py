"""Playwright E2E lives in frontend/e2e. These skip unless COMPOSE_E2E=1."""

import os

import pytest


@pytest.mark.e2e
def test_e2e_01_happy_path() -> None:
    if os.environ.get("COMPOSE_E2E") != "1":
        pytest.skip("run frontend/e2e/flows.spec.ts against compose")


@pytest.mark.e2e
def test_e2e_02_empty_dashboard() -> None:
    if os.environ.get("COMPOSE_E2E") != "1":
        pytest.skip("run frontend/e2e/flows.spec.ts against compose")


@pytest.mark.e2e
def test_e2e_03_reupload_old_embeddings_excluded() -> None:
    if os.environ.get("COMPOSE_E2E") != "1":
        pytest.skip("run frontend/e2e/flows.spec.ts against compose")


@pytest.mark.e2e
def test_e2e_04_drag_drop_persists() -> None:
    if os.environ.get("COMPOSE_E2E") != "1":
        pytest.skip("run frontend/e2e/flows.spec.ts against compose")


@pytest.mark.e2e
def test_e2e_05_refresh_mid_interview() -> None:
    if os.environ.get("COMPOSE_E2E") != "1":
        pytest.skip("run frontend/e2e/flows.spec.ts against compose")
