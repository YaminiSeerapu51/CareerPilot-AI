from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from httpx import ASGITransport, AsyncClient

from app.agents.orchestrator import classify_intent, run_chat
from app.agents.state import GraphState
from app.llm.client import FakeLLM
from app.main import app
from app.schemas.chat import Msg

pytestmark = pytest.mark.asyncio


async def test_it_01_routing() -> None:
    llm = FakeLLM()
    cases = [
        ("please parse my resume.pdf", "resume"),
        ("score this job description for python", "jobfit"),
        ("start a mock interview for SWE", "interview"),
        ("log that I applied to Google, SWE, today", "tracker"),
        ("hello there", "chitchat"),
    ]
    for text, expected in cases:
        state: GraphState = {
            "user_id": uuid4(),
            "messages": [Msg(role="user", content=text)],
            "intent": None,
            "attachments": [],
            "active_resume_id": None,
            "active_jd_id": None,
            "interview_session_id": None,
            "result": None,
            "chain": [],
            "tokens": [],
            "error": None,
        }
        intent = await classify_intent(llm, state)
        assert intent == expected


async def test_it_05_sse_incremental() -> None:
    db = MagicMock()
    db.commit = AsyncMock()
    db.rollback = AsyncMock()
    db.close = AsyncMock()
    db.add = MagicMock()
    db.flush = AsyncMock()
    tokens: list[str] = []
    async for event in run_chat(uuid4(), "hello there", [], llm=FakeLLM(), db=db):
        if event.type == "token":
            tokens.append(str(event.data))
    assert len(tokens) >= 2
    assert "".join(tokens)


@pytest.mark.integration
async def test_healthz() -> None:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/healthz")
        assert resp.status_code == 200
