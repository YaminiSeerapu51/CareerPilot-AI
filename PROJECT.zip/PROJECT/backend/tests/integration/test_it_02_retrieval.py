from __future__ import annotations

import os

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from app.db.models import Resume, ResumeChunk, User
from app.tools.retrieval import vector_search
from tests.helpers import fake_embed_texts

pytestmark = pytest.mark.asyncio


def _db_url() -> str | None:
    return os.environ.get("TEST_DATABASE_URL") or os.environ.get("DATABASE_URL")


@pytest.mark.integration
async def test_it_02_retrieval_relevance() -> None:
    url = _db_url()
    if not url or "postgresql" not in url:
        pytest.skip("postgres required")
    engine = create_async_engine(url)
    try:
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
    except Exception:
        pytest.skip("postgres unavailable")
    from uuid import uuid4

    async with AsyncSession(engine) as db:
        user = User(email=f"it02-{uuid4()}@example.com", password_hash="x")
        db.add(user)
        await db.flush()
        resume = Resume(
            user_id=user.id,
            raw_text="python fastapi",
            structured_json={"skills": ["Python", "FastAPI"], "experience": [], "education": []},
            is_active=True,
        )
        db.add(resume)
        await db.flush()
        py = fake_embed_texts(["Built REST APIs with Python and FastAPI"])[0]
        java = fake_embed_texts(["Legacy COBOL batch jobs"])[0]
        db.add(ResumeChunk(resume_id=resume.id, chunk_text="Built REST APIs with Python and FastAPI", embedding=py))
        db.add(ResumeChunk(resume_id=resume.id, chunk_text="Legacy COBOL batch jobs", embedding=java))
        await db.commit()
        hits = await vector_search(db, user.id, "python web api", k=1)
        assert hits
        assert "Python" in hits[0].text or "FastAPI" in hits[0].text
    await engine.dispose()
