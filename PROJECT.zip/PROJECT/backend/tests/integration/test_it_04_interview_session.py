from __future__ import annotations

import os
from uuid import uuid4

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from app.agents.interview_agent import answer_turn, start_session
from app.auth import hash_password
from app.db.models import InterviewTurn, User
from app.llm.client import FakeLLM

pytestmark = pytest.mark.asyncio


@pytest.mark.integration
async def test_it_04_turns_linked_to_one_session() -> None:
    url = os.environ.get("TEST_DATABASE_URL") or os.environ.get("DATABASE_URL")
    if not url or "postgresql" not in url:
        pytest.skip("postgres required")
    engine = create_async_engine(url)
    async with AsyncSession(engine) as db:
        try:
            user = User(email=f"it04-{uuid4()}@ex.com", password_hash=hash_password("x"))
            db.add(user)
            await db.flush()
            session = await start_session(db, user.id, "SWE", None)
            db.add(InterviewTurn(session_id=session.id, question="Q1"))
            await db.flush()
            await answer_turn(
                db,
                FakeLLM(),
                user.id,
                session.id,
                "At Acme I led a migration, owned the design, shipped it, and cut latency 40 percent.",
            )
            await db.commit()
            turns = (
                await db.execute(select(InterviewTurn).where(InterviewTurn.session_id == session.id))
            ).scalars().all()
            assert len(turns) >= 2
            assert all(t.session_id == session.id for t in turns)
        except Exception as exc:
            pytest.skip(f"postgres unavailable: {exc}")
    await engine.dispose()
