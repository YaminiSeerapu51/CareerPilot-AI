from __future__ import annotations

import os
from datetime import date
from uuid import uuid4

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from app.auth import hash_password
from app.db.models import Application, User
from app.llm.client import FakeLLM
from app.schemas.application import ApplicationCreate
from app.schemas.chat import Msg
from app.agents.state import GraphState
from app.agents.tracker_agent import run as run_tracker
from app.tools.tracker_tools import save_application

pytestmark = pytest.mark.asyncio


def _url() -> str | None:
    return os.environ.get("TEST_DATABASE_URL") or os.environ.get("DATABASE_URL")


@pytest.mark.integration
async def test_it_03_conversational_db_write() -> None:
    url = _url()
    if not url or "postgresql" not in url:
        pytest.skip("postgres required")
    engine = create_async_engine(url)
    async with AsyncSession(engine) as db:
        try:
            user = User(email=f"it03-{uuid4()}@ex.com", password_hash=hash_password("x"))
            db.add(user)
            await db.flush()
            state: GraphState = {
                "user_id": user.id,
                "messages": [Msg(role="user", content="log that I applied to Google, SWE, today")],
                "intent": "tracker",
                "attachments": [],
                "active_resume_id": None,
                "active_jd_id": None,
                "interview_session_id": None,
                "result": None,
                "chain": [],
                "tokens": [],
                "error": None,
            }
            await run_tracker(state, FakeLLM(), db)
            await db.commit()
            rows = (await db.execute(__import__("sqlalchemy").select(Application).where(Application.user_id == user.id))).scalars().all()
            assert any(r.company == "Google" and r.role == "SWE" for r in rows)
            assert any(r.applied_date == date.today() for r in rows)
        except Exception as exc:
            pytest.skip(f"postgres unavailable: {exc}")
    await engine.dispose()
