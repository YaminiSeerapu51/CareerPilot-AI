from __future__ import annotations

import os
from collections.abc import AsyncIterator, Iterator
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

os.environ.setdefault("LLM_MODE", "fake")
os.environ.setdefault("JWT_SECRET", "test-secret")
os.environ.setdefault("SEED_USER_EMAIL", "demo@careerpilot.local")
os.environ.setdefault("SEED_USER_PASSWORD", "changeme")
os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://cp:cp@localhost:5432/careerpilot")

from app.config import get_settings
from tests.helpers import fake_embed_texts

get_settings.cache_clear()

FIXTURES = Path(__file__).resolve().parent / "fixtures"


@pytest.fixture
def fixtures_dir() -> Path:
    return FIXTURES


@pytest.fixture(autouse=True)
def _fake_embeddings() -> Iterator[None]:
    with patch("app.embeddings.embed_texts", side_effect=fake_embed_texts), patch(
        "app.tools.resume_tools.embed_texts", side_effect=fake_embed_texts
    ), patch("app.tools.retrieval.embed_texts", side_effect=fake_embed_texts), patch(
        "app.agents.jobfit_agent.embed_texts", side_effect=fake_embed_texts
    ):
        yield


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
async def db_session() -> AsyncIterator[Any]:
    from app.db.session import SessionLocal

    async with SessionLocal() as session:
        yield session
        await session.rollback()
