from __future__ import annotations

import hashlib
from pathlib import Path

from app.embeddings import cosine_similarity


def fake_embed_texts(texts: list[str]) -> list[list[float]]:
    vectors: list[list[float]] = []
    for text in texts:
        digest = hashlib.sha256(text.encode()).digest()
        vals: list[float] = []
        i = 0
        while len(vals) < 384:
            b = digest[i % len(digest)]
            vals.append((b / 127.5) - 1.0)
            i += 1
            digest = hashlib.sha256(digest + text.encode()).digest()
        norm = sum(v * v for v in vals) ** 0.5 or 1.0
        vectors.append([v / norm for v in vals])
    return vectors


def similarity(a: str, b: str) -> float:
    va, vb = fake_embed_texts([a, b])
    return cosine_similarity(va, vb)


FIXTURES = Path(__file__).resolve().parent
