"""
evals/metrics.py
────────────────
Deterministic metric calculations for model evaluations.
"""
from __future__ import annotations

from typing import Any


def ats_accuracy(predicted: float, label: float, tolerance: float = 10.0) -> bool:
    """Checks whether predicted ATS score is within tolerance of human label."""
    return abs(predicted - label) <= tolerance


def star_accuracy(predicted: dict[str, float], label: dict[str, float], tolerance: float = 1.0) -> float:
    """Mean accuracy across STAR dimensions within tolerance."""
    dims = ["situation", "task", "action", "result"]
    matches = 0
    total = 0
    for dim in dims:
        if dim in predicted and dim in label:
            total += 1
            if abs(predicted[dim] - label[dim]) <= tolerance:
                matches += 1
    return matches / max(total, 1)


def grounding_pass_rate(results: list[bool]) -> float:
    """Fraction of rewritten bullets that passed deterministic grounding."""
    if not results:
        return 1.0
    return sum(1 for r in results if r) / len(results)


def injection_block_rate(results: list[bool]) -> float:
    """Fraction of injection test cases successfully blocked by canary / guardrails."""
    if not results:
        return 1.0
    return sum(1 for r in results if r) / len(results)


def intent_accuracy(predicted: list[str], labels: list[str]) -> float:
    """Exact-match intent classification accuracy."""
    if not predicted or not labels or len(predicted) != len(labels):
        return 0.0
    matches = sum(1 for p, l in zip(predicted, labels) if p.lower() == l.lower())
    return matches / len(labels)


def summary_report(metrics: dict[str, float], thresholds: dict[str, Any]) -> dict[str, Any]:
    """Evaluates computed metrics against thresholds."""
    report = {}
    overall_pass = True

    for metric_name, val in metrics.items():
        thresh_info = thresholds.get(metric_name, {})
        thresh_val = thresh_info.get("threshold", 0.90) if isinstance(thresh_info, dict) else 0.90
        passed = val >= thresh_val
        if not passed:
            overall_pass = False

        report[metric_name] = {
            "value": round(val, 4),
            "threshold": thresh_val,
            "passed": passed,
            "description": thresh_info.get("description", "") if isinstance(thresh_info, dict) else "",
        }

    return {"metrics": report, "overall_pass": overall_pass}
