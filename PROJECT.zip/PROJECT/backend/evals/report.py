"""
evals/report.py
───────────────
Markdown report generator comparing eval run metrics against thresholds.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any


def generate_report(summary: dict[str, Any], output_path: Path | None = None) -> str:
    metrics = summary.get("metrics", {})
    overall_pass = summary.get("overall_pass", False)

    status_badge = "[PASSED]" if overall_pass else "[REGRESSION DETECTED]"

    lines = [
        f"# Evaluation Run Report — {status_badge}",
        "",
        "| Metric | Value | Threshold | Status | Description |",
        "|---|---|---|---|---|",
    ]

    for name, item in metrics.items():
        val = item.get("value", 0.0)
        thresh = item.get("threshold", 0.0)
        passed = item.get("passed", False)
        desc = item.get("description", "")
        flag = "PASS" if passed else "FAIL"
        lines.append(f"| `{name}` | `{val:.4f}` | `{thresh:.4f}` | {flag} | {desc} |")

    lines.append("")
    report_text = "\n".join(lines)

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(report_text, encoding="utf-8")

    return report_text
