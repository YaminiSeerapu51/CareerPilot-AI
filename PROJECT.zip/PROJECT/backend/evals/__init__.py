"""
evals package
─────────────
Exports metrics, runner, judge, and report utilities.
"""
from __future__ import annotations

from evals.judge import Judge, JudgeVerdict
from evals.metrics import (
    ats_accuracy,
    grounding_pass_rate,
    injection_block_rate,
    intent_accuracy,
    star_accuracy,
    summary_report,
)
from evals.report import generate_report
from evals.runner import EvalMode, EvalRunner, EvalSuite

__all__ = [
    "EvalSuite",
    "EvalMode",
    "EvalRunner",
    "Judge",
    "JudgeVerdict",
    "generate_report",
    "ats_accuracy",
    "star_accuracy",
    "grounding_pass_rate",
    "injection_block_rate",
    "intent_accuracy",
    "summary_report",
]
