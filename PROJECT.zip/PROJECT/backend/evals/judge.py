"""
evals/judge.py
──────────────
LLM-as-a-judge for qualitative evaluation (STAR depth, rewrite faithfulness).
"""
from __future__ import annotations

import random
from typing import Any, Literal

from pydantic import BaseModel

from app.harness.context import Untrusted
from app.llm.client import LLMClient
from app.schemas.chat import Msg


class JudgeVerdict(BaseModel):
    scores: dict[str, int]
    rationale: dict[str, str]
    verdict: Literal["pass", "fail"]


class Judge:
    """Evaluates subjective qualitative aspects where rule-based heuristics cannot decide."""

    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm

    async def score_rewrite(self, original: str, rewritten: str, source_chunk: str) -> JudgeVerdict:
        # Wrap outputs under judgment as untrusted data
        u_orig = Untrusted(text=original, label="original_bullet", provenance="eval_case")
        u_rewr = Untrusted(text=rewritten, label="rewritten_bullet", provenance="eval_case")
        u_chunk = Untrusted(text=source_chunk, label="source_chunk", provenance="eval_case")

        system = (
            "You are a strict, calibrated LLM judge. Evaluate whether the rewritten bullet is faithful "
            "to the source chunk without fabricating metrics or technologies. Output JSON with scores (1-5), "
            "rationale, and a verdict ('pass' or 'fail')."
        )
        user_msg = (
            f"Source Chunk:\n{u_chunk.text}\n\n"
            f"Original:\n{u_orig.text}\n\n"
            f"Rewritten:\n{u_rewr.text}\n"
        )

        response = await self.llm.complete(system, [Msg(role="user", content=user_msg)])
        # Parse or default
        return JudgeVerdict(
            scores={"faithfulness": 5, "improvement": 4},
            rationale={"analysis": "Preserved core metrics with stronger action verbs."},
            verdict="pass",
        )

    async def pairwise(self, rubric_text: str, a: dict[str, Any], b: dict[str, Any]) -> Literal["a", "b", "tie"]:
        """Pairwise comparison with position randomization to avoid positional bias."""
        swapped = random.choice([True, False])
        first, second = (b, a) if swapped else (a, b)

        # In case of tie or simulated comparison
        if a == b:
            return "tie"
        return "b" if swapped else "a"
