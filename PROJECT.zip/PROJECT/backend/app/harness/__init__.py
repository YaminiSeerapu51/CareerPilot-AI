"""
CareerPilot AI Agent Harness Package (`app/harness`)
────────────────────────────────────────────────────
Centralized runtime providing safety, execution loops, memory coordination,
distributed tracing, and output guardrails.
"""
from __future__ import annotations

from app.harness.agent_spec import AgentSpec
from app.harness.build import Harness, build_harness
from app.harness.context import BuiltContext, ContextBuilder, RunContext, TaskSpec, Untrusted, new_run_context
from app.harness.gates import FinalGate, GateResult, Violation
from app.harness.hooks import (
    AgentHooks,
    Allow,
    Block,
    HarnessSealedError,
    HookBus,
    HookCtx,
    HookDecision,
    HookEvent,
    Modify,
    Phase,
)
from app.harness.loop import AgentLoop, LoopBudget, LoopResult, StopReason

__all__ = [
    "HookBus",
    "HookEvent",
    "HookDecision",
    "Allow",
    "Block",
    "Modify",
    "Phase",
    "HookCtx",
    "AgentHooks",
    "HarnessSealedError",
    "RunContext",
    "Untrusted",
    "ContextBuilder",
    "BuiltContext",
    "TaskSpec",
    "new_run_context",
    "AgentLoop",
    "LoopBudget",
    "LoopResult",
    "StopReason",
    "FinalGate",
    "GateResult",
    "Violation",
    "Harness",
    "build_harness",
    "AgentSpec",
]
