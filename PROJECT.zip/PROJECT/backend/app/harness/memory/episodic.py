"""
harness/memory/episodic.py
──────────────────────────
Episodic memory: historical interview sessions, application events, and candidate weak area recall.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import ApplicationEvent, InterviewSession, InterviewTurn, SessionSummary


class WeakArea(BaseModel):
    dimension: Literal["situation", "task", "action", "result"]
    mean_score: float
    sample_size: int


class PastTurn(BaseModel):
    session_id: UUID
    question: str
    answer: str | None
    star_score: float | None
    similarity: float = 1.0


class EpisodicSessionSummary(BaseModel):
    session_id: UUID
    role: str | None
    topics: list[str]
    questions_asked: list[str]
    star_means: dict[str, float]
    strengths: list[str]
    weaknesses: list[str]
    summarized_at: datetime


class EpisodicStore:
    """Provides episodic memory recall for recent sessions and interview performance trends."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def record_event(
        self,
        user_id: UUID,
        kind: str,
        payload: dict[str, Any],
        run_id: UUID | None = None,
        application_id: UUID | None = None,
    ) -> None:
        event = ApplicationEvent(
            id=uuid4(),
            user_id=user_id,
            application_id=application_id,
            kind=kind,
            payload=payload,
            run_id=run_id,
            ts=datetime.utcnow(),
        )
        self.db.add(event)
        await self.db.flush()

    async def recent_sessions(self, user_id: UUID, limit: int = 3) -> list[EpisodicSessionSummary]:
        q = (
            select(SessionSummary, InterviewSession.role)
            .join(InterviewSession, SessionSummary.session_id == InterviewSession.id, isouter=True)
            .where(SessionSummary.user_id == user_id)
            .order_by(SessionSummary.created_at.desc())
            .limit(limit)
        )
        res = await self.db.execute(q)
        rows = res.all()

        results: list[EpisodicSessionSummary] = []
        for s_summary, role in rows:
            data = s_summary.summary or {}
            results.append(
                EpisodicSessionSummary(
                    session_id=s_summary.session_id or s_summary.id,
                    role=role,
                    topics=data.get("topics", []),
                    questions_asked=data.get("questions_asked", []),
                    star_means=data.get("star_means", {}),
                    strengths=data.get("strengths", []),
                    weaknesses=data.get("weaknesses", []),
                    summarized_at=s_summary.created_at,
                )
            )
        return results

    async def weak_areas(self, user_id: UUID, window: int = 5) -> list[WeakArea]:
        """Calculates dimensions where average score < 3.0 across recent turns."""
        q = (
            select(InterviewTurn)
            .join(InterviewSession, InterviewTurn.session_id == InterviewSession.id)
            .where(InterviewSession.user_id == user_id)
            .order_by(InterviewTurn.created_at.desc())
            .limit(window * 4)
        )
        res = await self.db.execute(q)
        turns = res.scalars().all()

        dims: dict[str, list[float]] = {"situation": [], "task": [], "action": [], "result": []}
        for turn in turns:
            fb = turn.feedback or {}
            for dim in dims:
                if dim in fb and isinstance(fb[dim], (int, float)):
                    dims[dim].append(float(fb[dim]))

        weak: list[WeakArea] = []
        for dim, scores in dims.items():
            if scores:
                mean = sum(scores) / len(scores)
                if mean < 3.0:
                    weak.append(
                        WeakArea(
                            dimension=dim,  # type: ignore[arg-type]
                            mean_score=round(mean, 2),
                            sample_size=len(scores),
                        )
                    )
        return weak

    async def similar_past_questions(self, user_id: UUID, question: str, k: int = 3) -> list[PastTurn]:
        """Finds previously asked questions to avoid repetition in interview turns."""
        q = (
            select(InterviewTurn)
            .join(InterviewSession, InterviewTurn.session_id == InterviewSession.id)
            .where(InterviewSession.user_id == user_id)
            .order_by(InterviewTurn.created_at.desc())
            .limit(k * 3)
        )
        res = await self.db.execute(q)
        turns = res.scalars().all()

        results: list[PastTurn] = []
        words = set(question.lower().split())
        for turn in turns:
            q_words = set(turn.question.lower().split())
            intersection = words.intersection(q_words)
            sim = len(intersection) / max(len(words.union(q_words)), 1)
            results.append(
                PastTurn(
                    session_id=turn.session_id,
                    question=turn.question,
                    answer=turn.answer,
                    star_score=turn.star_score,
                    similarity=round(sim, 3),
                )
            )

        results.sort(key=lambda x: x.similarity, reverse=True)
        return results[:k]
