"""
harness/memory/writer.py
────────────────────────
MemoryWriter and CommitCoordinator.
Applies staged actions and durable memory writes in ONE single, short database transaction.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.db.models import Application, ApplicationEvent, ApplicationStatus, IdempotencyKey, MemoryConflict, MemoryFact
from app.harness.context import RunContext, Untrusted

logger = logging.getLogger(__name__)


class ProposedFact(BaseModel):
    kind: str
    key: str
    value: Any
    source: str
    confidence: float = 1.0


class CommitReport(BaseModel):
    facts_written: int = 0
    facts_superseded: int = 0
    conflicts_logged: int = 0
    staged_actions_applied: int = 0


class MemoryWriter:
    """Extracts, validates, and commits facts with provenance caps and conflict tracking."""

    def __init__(self, db: AsyncSession, llm: Any = None) -> None:
        self.db = db
        self.llm = llm

    def validate_and_cap_fact(self, fact: ProposedFact) -> ProposedFact:
        # Defense against memory poisoning: untrusted resume/JD sources capped at 0.6
        if fact.source in ("resume_doc", "jd_doc") and fact.confidence > 0.6:
            fact.confidence = 0.6
        return fact

    async def commit_facts(
        self,
        ctx: RunContext,
        facts: list[ProposedFact],
    ) -> tuple[int, int, int]:
        written = 0
        superseded = 0
        conflicts = 0

        # Deduplicate facts by (kind, key) keeping highest confidence
        deduped: dict[tuple[str, str], ProposedFact] = {}
        for f in facts:
            f = self.validate_and_cap_fact(f)
            k = (f.kind, f.key)
            if k not in deduped or f.confidence > deduped[k].confidence:
                deduped[k] = f

        for (kind, key), fact in deduped.items():
            # Check for existing fact with same (kind, key) for this user
            from sqlalchemy import select
            q = select(MemoryFact).where(
                MemoryFact.user_id == ctx.user_id,
                MemoryFact.kind == kind,
                MemoryFact.key == key,
                MemoryFact.valid_to.is_(None),
            )
            res = await self.db.execute(q)
            existing = res.scalar_one_or_none()

            new_id = uuid4()
            now = datetime.utcnow()

            if existing:
                # If sources differ and values conflict, log to memory_conflicts
                if existing.value != fact.value and existing.source != fact.source:
                    conf = MemoryConflict(
                        id=uuid4(),
                        user_id=ctx.user_id,
                        fact_a={"id": str(existing.id), "value": existing.value, "source": existing.source},
                        fact_b={"value": fact.value, "source": fact.source},
                        run_id=ctx.run_id,
                        resolved=False,
                    )
                    self.db.add(conf)
                    conflicts += 1

                # Supersede existing fact
                existing.valid_to = now
                existing.superseded_by = new_id
                superseded += 1

            mf = MemoryFact(
                id=new_id,
                user_id=ctx.user_id,
                kind=fact.kind,
                key=fact.key,
                value=fact.value if isinstance(fact.value, dict) else {"val": fact.value},
                source=fact.source,
                source_run_id=ctx.run_id,
                confidence=fact.confidence,
                valid_from=now,
            )
            self.db.add(mf)
            written += 1

        return written, superseded, conflicts


class CommitCoordinator:
    """
    Applies ctx.staged actions and memory writes in ONE short transaction.
    Guarantees:
      - Memory writes and staged actions are applied together.
      - Never partial writes: failure rolls back everything.
      - Sets short DB statement and lock timeouts to avoid holding connection locks.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def commit(
        self,
        ctx: RunContext,
        *,
        memory_writer: MemoryWriter | None = None,
        facts: list[ProposedFact] | None = None,
    ) -> CommitReport:
        report = CommitReport()
        settings = get_settings()

        try:
            # Set short local statement and lock timeouts for this transaction
            stmt_to = f"{settings.db_statement_timeout_ms}ms"
            lock_to = f"{settings.db_lock_timeout_ms}ms"
            await self.db.execute(text(f"SET LOCAL statement_timeout = '{stmt_to}';"))
            await self.db.execute(text(f"SET LOCAL lock_timeout = '{lock_to}';"))

            # 1. Apply staged actions
            for staged in ctx.staged:
                tool_name = staged.get("tool")
                args = staged.get("args", {})
                idem_key = staged.get("idempotency_key")

                # Handle application tracker domain writes
                if tool_name == "save_application":
                    app = Application(
                        id=uuid4(),
                        user_id=ctx.user_id,
                        company=args.get("company", ""),
                        role=args.get("role", ""),
                        status=args.get("status", ApplicationStatus.applied),
                        applied_date=args.get("applied_date"),
                        notes=args.get("notes"),
                        ats_score=args.get("ats_score"),
                    )
                    self.db.add(app)
                    await self.db.flush()

                    # Audit event
                    event = ApplicationEvent(
                        id=uuid4(),
                        application_id=app.id,
                        user_id=ctx.user_id,
                        kind="created",
                        payload={"company": app.company, "role": app.role, "status": str(app.status)},
                        run_id=ctx.run_id,
                        ts=datetime.utcnow(),
                    )
                    self.db.add(event)

                    if idem_key:
                        self.db.add(
                            IdempotencyKey(
                                key=idem_key,
                                user_id=ctx.user_id,
                                tool=tool_name,
                                args_hash=staged.get("args_hash", ""),
                                request_id=ctx.request_id,
                                run_id=ctx.run_id,
                                result={"id": str(app.id), "status": "created"},
                                created_at=datetime.utcnow(),
                            )
                        )
                    report.staged_actions_applied += 1

                elif tool_name == "update_application_status":
                    app_id = UUID(str(args.get("application_id")))
                    status = args.get("status")
                    from sqlalchemy import update
                    await self.db.execute(
                        update(Application)
                        .where(Application.id == app_id, Application.user_id == ctx.user_id)
                        .values(status=status, updated_at=datetime.utcnow())
                    )
                    event = ApplicationEvent(
                        id=uuid4(),
                        application_id=app_id,
                        user_id=ctx.user_id,
                        kind="status_updated",
                        payload={"status": str(status)},
                        run_id=ctx.run_id,
                        ts=datetime.utcnow(),
                    )
                    self.db.add(event)

                    if idem_key:
                        self.db.add(
                            IdempotencyKey(
                                key=idem_key,
                                user_id=ctx.user_id,
                                tool=tool_name,
                                args_hash=staged.get("args_hash", ""),
                                request_id=ctx.request_id,
                                run_id=ctx.run_id,
                                result={"id": str(app_id), "status": str(status)},
                                created_at=datetime.utcnow(),
                            )
                        )
                    report.staged_actions_applied += 1

            # 2. Apply memory writes
            if memory_writer and facts:
                w, s, c = await memory_writer.commit_facts(ctx, facts)
                report.facts_written = w
                report.facts_superseded = s
                report.conflicts_logged = c

            # 3. Final commit
            await self.db.commit()
            return report

        except Exception as exc:
            logger.error("CommitCoordinator failed to commit run %s: %s", ctx.run_id, exc)
            await self.db.rollback()
            raise
