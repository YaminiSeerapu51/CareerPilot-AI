"""
harness/memory/semantic.py
──────────────────────────
SemanticStore: Long-term learned facts store with temporal supersession and confidence caps.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import MemoryFact

FactKind = Literal["target_role", "location_pref", "skill_claim", "salary_pref", "constraint", "other"]
FactSource = Literal["user_message", "resume_doc", "jd_doc", "tool_result", "summarizer"]
FactId = UUID


class Fact(BaseModel):
    id: FactId
    user_id: UUID
    kind: str
    key: str
    value: Any
    source: str
    source_run_id: UUID | None
    confidence: float
    valid_from: datetime
    valid_to: datetime | None = None
    superseded_by: FactId | None = None


class SemanticStore:
    """Manages persistent semantic facts with temporal history and supersession."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def upsert_fact(
        self,
        user_id: UUID,
        *,
        kind: str,
        key: str,
        value: Any,
        source: str,
        run_id: UUID | None = None,
        confidence: float = 1.0,
    ) -> FactId:
        # Provenance cap for untrusted inputs (resume/JD)
        if source in ("resume_doc", "jd_doc") and confidence > 0.6:
            confidence = 0.6

        now = datetime.utcnow()
        new_id = uuid4()

        # Supersede existing active fact for same kind + key
        q = select(MemoryFact).where(
            MemoryFact.user_id == user_id,
            MemoryFact.kind == kind,
            MemoryFact.key == key,
            MemoryFact.valid_to.is_(None),
        )
        res = await self.db.execute(q)
        existing = res.scalar_one_or_none()

        if existing:
            existing.valid_to = now
            existing.superseded_by = new_id

        mf = MemoryFact(
            id=new_id,
            user_id=user_id,
            kind=kind,
            key=key,
            value=value if isinstance(value, dict) else {"val": value},
            source=source,
            source_run_id=run_id,
            confidence=confidence,
            valid_from=now,
        )
        self.db.add(mf)
        await self.db.flush()
        return new_id

    async def get_facts(
        self,
        user_id: UUID,
        *,
        kinds: list[str] | None = None,
        as_of: datetime | None = None,
    ) -> list[Fact]:
        q = select(MemoryFact).where(MemoryFact.user_id == user_id)
        if as_of:
            q = q.where(
                MemoryFact.valid_from <= as_of,
                or_(MemoryFact.valid_to.is_(None), MemoryFact.valid_to > as_of),
            )
        else:
            q = q.where(MemoryFact.valid_to.is_(None))

        if kinds:
            q = q.where(MemoryFact.kind.in_(kinds))

        q = q.order_by(MemoryFact.valid_from.desc())
        res = await self.db.execute(q)
        rows = res.scalars().all()

        return [
            Fact(
                id=r.id,
                user_id=r.user_id,
                kind=r.kind,
                key=r.key,
                value=r.value,
                source=r.source,
                source_run_id=r.source_run_id,
                confidence=r.confidence,
                valid_from=r.valid_from,
                valid_to=r.valid_to,
                superseded_by=r.superseded_by,
            )
            for r in rows
        ]

    async def search_facts(self, user_id: UUID, query: str, k: int = 5) -> list[Fact]:
        """Simple keyword search over facts."""
        q = (
            select(MemoryFact)
            .where(
                MemoryFact.user_id == user_id,
                MemoryFact.valid_to.is_(None),
                MemoryFact.key.ilike(f"%{query}%"),
            )
            .limit(k)
        )
        res = await self.db.execute(q)
        rows = res.scalars().all()

        return [
            Fact(
                id=r.id,
                user_id=r.user_id,
                kind=r.kind,
                key=r.key,
                value=r.value,
                source=r.source,
                source_run_id=r.source_run_id,
                confidence=r.confidence,
                valid_from=r.valid_from,
                valid_to=r.valid_to,
                superseded_by=r.superseded_by,
            )
            for r in rows
        ]

    async def soft_delete(self, user_id: UUID, fact_id: UUID) -> bool:
        q = select(MemoryFact).where(
            MemoryFact.id == fact_id,
            MemoryFact.user_id == user_id,
            MemoryFact.valid_to.is_(None),
        )
        res = await self.db.execute(q)
        existing = res.scalar_one_or_none()
        if existing:
            existing.valid_to = datetime.utcnow()
            return True
        return False

    async def wipe(self, user_id: UUID) -> int:
        from sqlalchemy import update
        res = await self.db.execute(
            update(MemoryFact)
            .where(MemoryFact.user_id == user_id, MemoryFact.valid_to.is_(None))
            .values(valid_to=datetime.utcnow())
        )
        return res.rowcount
