"""
harness/memory/procedural.py
────────────────────────────
Procedural memory: versioned prompts, rubrics, and skills.
Assets are stored as markdown files with YAML frontmatter.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml

from app.harness.context import Untrusted


@dataclass(frozen=True)
class PromptSpec:
    id: str
    version: str
    sha256: str
    text: str
    kind: Literal["prompt", "rubric", "skill"]
    untrusted_slots: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class RenderedPrompt:
    spec: PromptSpec
    text: str


class PromptRegistry:
    """
    Registry for immutable, versioned procedural assets (prompts, rubrics, skills).
    Reads .md and .yaml files with YAML frontmatter from procedural_assets/.
    """

    def __init__(self, assets_dir: Path | None = None) -> None:
        if assets_dir is None:
            assets_dir = Path(__file__).resolve().parent.parent / "procedural_assets"
        self.assets_dir = assets_dir
        self._specs: dict[str, dict[str, PromptSpec]] = {}  # id -> {version -> PromptSpec}
        self.load()

    def load(self) -> None:
        self._specs.clear()
        if not self.assets_dir.exists():
            return

        for path in self.assets_dir.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix in (".md", ".markdown"):
                self._load_markdown(path)
            elif path.suffix in (".yaml", ".yml"):
                self._load_yaml(path)

    def _load_markdown(self, path: Path) -> None:
        raw = path.read_text(encoding="utf-8")
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest()

        # Parse YAML frontmatter between --- and ---
        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", raw, re.DOTALL)
        if not fm_match:
            return

        meta = yaml.safe_load(fm_match.group(1)) or {}
        body = fm_match.group(2).strip()

        pid = meta.get("id") or path.stem
        version = str(meta.get("version", "1.0"))
        kind = meta.get("kind", "prompt")
        untrusted_slots = meta.get("untrusted_slots", [])

        spec = PromptSpec(
            id=pid,
            version=version,
            sha256=h,
            text=body,
            kind=kind,
            untrusted_slots=untrusted_slots,
        )
        self._specs.setdefault(pid, {})[version] = spec

    def _load_yaml(self, path: Path) -> None:
        raw = path.read_text(encoding="utf-8")
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        meta = yaml.safe_load(raw) or {}
        if not isinstance(meta, dict):
            return

        pid = meta.get("id") or path.stem
        version = str(meta.get("version", "1.0"))
        kind = meta.get("kind", "rubric")
        spec = PromptSpec(
            id=pid,
            version=version,
            sha256=h,
            text=raw,
            kind=kind,
            untrusted_slots=[],
        )
        self._specs.setdefault(pid, {})[version] = spec

    def get(self, id: str, *, version: str | None = None) -> PromptSpec:
        """Get latest or specific version of a prompt spec."""
        if id not in self._specs or not self._specs[id]:
            raise KeyError(f"Prompt asset '{id}' not found in registry.")

        versions = self._specs[id]
        if version:
            if version not in versions:
                raise KeyError(f"Version '{version}' of prompt '{id}' not found.")
            return versions[version]

        # Latest by semantic/string version sorting
        latest_version = sorted(versions.keys())[-1]
        return versions[latest_version]

    def render(self, id: str, *, version: str | None = None, **vars: str | Untrusted) -> RenderedPrompt:
        """
        Renders prompt template.
        HAR-27: Rejects raw str in untrusted slots; requires Untrusted wrapper.
        """
        spec = self.get(id, version=version)
        rendered_text = spec.text

        for slot in spec.untrusted_slots:
            if slot in vars:
                val = vars[slot]
                if not isinstance(val, Untrusted):
                    raise ValueError(
                        f"Slot '{slot}' in prompt '{id}' is designated untrusted. "
                        f"Got raw '{type(val).__name__}', expected Untrusted."
                    )

        # String formatting for placeholders
        format_dict: dict[str, str] = {}
        for k, v in vars.items():
            if isinstance(v, Untrusted):
                format_dict[k] = v.normalize()
            else:
                format_dict[k] = str(v)

        try:
            rendered_text = rendered_text.format(**format_dict)
        except KeyError:
            # If formatting doesn't use simple brackets or has extra keys, fall back
            pass

        return RenderedPrompt(spec=spec, text=rendered_text)

    def all_versions(self) -> dict[str, str]:
        """Returns dict of id -> 'version:sha256' for all latest prompt assets."""
        res: dict[str, str] = {}
        for pid, versions in self._specs.items():
            latest = sorted(versions.keys())[-1]
            spec = versions[latest]
            res[pid] = f"{spec.version}:{spec.sha256[:12]}"
        return res
