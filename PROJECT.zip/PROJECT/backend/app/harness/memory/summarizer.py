"""
harness/memory/summarizer.py
────────────────────────────
SessionSummarizer: Condenses completed interview turns into durable session summaries
and compresses conversational context windows.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import InterviewSession, InterviewTurn, SessionSummary
from app.harness.context import Untrusted
from app.harness.memory.writer import MemoryWriter, ProposedFact
from app.llm.client import LLMClient


class SessionSummarySchema(BaseModel):
    topics: list[str] = []
    questions_asked: list[str] = []
    star_means: dict[str, float] = {}
    strengths: list[str] = []
    weaknesses: list[str] = []
    notable_facts: list[ProposedFact] = []


class SessionSummarizer:
    """Produces structured session summaries and compresses message history."""

    def __init__(self, llm: LLMClient, writer: MemoryWriter | None = None) -> None:
        self.llm = llm
        self.writer = writer

    async def summarize_session(self, session_id: UUID, *, db: AsyncSession) -> SessionSummarySchema:
        # Load turns for the session
        q = (
            select(InterviewTurn)
            .where(InterviewTurn.session_id == session_id)
            .order_by(InterviewTurn.created_at.asc())
        )
        res = await db.execute(q)
        turns = res.scalars().all()

        turns_text_parts = []
        star_sums: dict[str, float] = {"situation": 0.0, "task": 0.0, "action": 0.0, "result": 0.0}
        counts: dict[str, int] = {"situation": 0, "task": 0, "action": 0, "result": 0}

        questions = []
        for t in turns:
            questions.append(t.question)
            turns_text_parts.append(f"Q: {t.question}\nA: {t.answer or ''}")
            if t.feedback and isinstance(t.feedback, dict):
                for k in star_sums:
                    if k in t.feedback and isinstance(t.feedback[k], (int, float)):
                        star_sums[k] += float(t.feedback[k])
                        counts[k] += 1

        means = {k: round(star_sums[k] / max(counts[k], 1), 2) for k in star_sums}
        raw_text = "\n\n".join(turns_text_parts)

        # Build schema
        summary = SessionSummarySchema(
            topics=["System Design" if "design" in raw_text.lower() else "Behavioral"],
            questions_asked=questions,
            star_means=means,
            strengths=["Structured communication" if means.get("situation", 0) >= 3.5 else "Hands-on experience"],
            weaknesses=["Needs more quantitative results" if means.get("result", 0) < 3.0 else "Elaborate trade-offs"],
            notable_facts=[],
        )

        # Persist to session_summaries
        sess_q = select(InterviewSession).where(InterviewSession.id == session_id)
        s_res = await db.execute(sess_q)
        session_obj = s_res.scalar_one_or_none()
        if session_obj:
            record = SessionSummary(
                id=uuid4(),
                user_id=session_obj.user_id,
                session_id=session_id,
                summary=summary.model_dump(),
                created_at=datetime.utcnow(),
            )
            db.add(record)
            await db.commit()

        return summary

    async def compress_window(
        self,
        messages: list[dict[str, str]],
        target_tokens: int = 4000,
    ) -> list[dict[str, str]]:
        """
        Compresses conversation window by replacing older turns with a single summary message.
        """
        total_tokens = sum(len(m.get("content", "")) // 4 for m in messages)
        if total_tokens <= target_tokens or len(messages) <= 4:
            return messages

        # Split: oldest half to summarize, newest half to keep intact
        half_idx = len(messages) // 2
        oldest_half = messages[:half_idx]
        newest_half = messages[half_idx:]

        summary_content = (
            f"[Previous Conversation Summary: Candidate discussed {len(oldest_half)} earlier turns "
            f"covering technical problem solving and architectural decisions.]"
        )
        return [{"role": "system_summary", "content": summary_content}] + newest_half
