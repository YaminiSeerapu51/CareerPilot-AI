"""
harness/tools/executor.py
─────────────────────────
ToolExecutor: Enforces security allow-lists, schema validation, injection of context,
idempotency, timeouts, staged mutations, and human confirmation gates.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, ValidationError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.db.models import IdempotencyKey, PendingAction
from app.harness.context import RunContext
from app.harness.tools.registry import ToolRegistry, ToolSpec
from app.harness.tracing import SpanKind, get_tracer
from app.harness.tracing.redact import redact


@dataclass
class ToolCall:
    name: str
    args: dict[str, Any]
    call_id: str = field(default_factory=lambda: uuid4().hex)


@dataclass
class ToolErrorInfo:
    kind: Literal["not_allowed", "validation", "timeout", "limit_exceeded", "idempotency", "error"]
    detail: str


@dataclass
class ToolResult:
    ok: bool
    data: dict[str, Any] | None
    error: ToolErrorInfo | None
    latency_ms: int
    idempotency_key: str | None = None


def _canonical_json(data: dict[str, Any]) -> str:
    return json.dumps(data, sort_keys=True, default=str)


class ToolExecutor:
    """Safely executes tool calls on behalf of an agent within a RunContext."""

    def __init__(self, registry: ToolRegistry, db: AsyncSession) -> None:
        self.registry = registry
        self.db = db
        self.tracer = get_tracer()

    async def execute(
        self,
        call: ToolCall,
        ctx: RunContext,
        *,
        allow_list: list[str],
    ) -> ToolResult:
        start_time = time.perf_counter()

        async with self.tracer.span(SpanKind.TOOL, call.name, tool_call_id=call.call_id) as span:
            # 1. Allow-list check
            if call.name not in allow_list:
                err = ToolErrorInfo(
                    kind="not_allowed",
                    detail=f"Tool '{call.name}' is not in the agent's authorized allow-list.",
                )
                span.record_error(RuntimeError(err.detail))
                return ToolResult(ok=False, data=None, error=err, latency_ms=0)

            spec = self.registry.get(call.name)
            if not spec:
                err = ToolErrorInfo(kind="not_allowed", detail=f"Tool '{call.name}' not found.")
                span.record_error(RuntimeError(err.detail))
                return ToolResult(ok=False, data=None, error=err, latency_ms=0)

            # 2. Schema validation
            try:
                validated_args = spec.args_model.model_validate(call.args)
            except ValidationError as ve:
                err = ToolErrorInfo(
                    kind="validation",
                    detail=f"Argument validation failed: {ve.errors()}",
                )
                span.record_error(ve)
                return ToolResult(ok=False, data=None, error=err, latency_ms=0)

            args_dict = validated_args.model_dump()
            canonical_str = _canonical_json(args_dict)
            args_hash = hashlib.sha256(canonical_str.encode("utf-8")).hexdigest()[:16]

            # 3. Idempotency check for write operations
            idem_key = None
            if spec.access == "write":
                raw_key = f"{ctx.user_id}:{ctx.request_id}:{call.name}:{args_hash}"
                idem_key = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()

                existing = await self.db.execute(
                    select(IdempotencyKey).where(IdempotencyKey.key == idem_key)
                )
                cached = existing.scalar_one_or_none()
                if cached:
                    latency_ms = int((time.perf_counter() - start_time) * 1000)
                    span.set(idempotent_hit=True)
                    return ToolResult(
                        ok=True,
                        data=cached.result,
                        error=None,
                        latency_ms=latency_ms,
                        idempotency_key=idem_key,
                    )

            # 4. Human Confirmation Gate (destructive actions)
            if spec.requires_confirmation:
                settings = get_settings()
                expires_at = datetime.utcnow() + timedelta(minutes=settings.pending_action_ttl_min)
                pending_id = uuid4()
                pending = PendingAction(
                    id=pending_id,
                    user_id=ctx.user_id,
                    run_id=ctx.run_id,
                    tool=spec.name,
                    args_canonical=args_dict,
                    args_hash=args_hash,
                    idempotency_key=idem_key or "",
                    status="pending",
                    created_at=datetime.utcnow(),
                    expires_at=expires_at,
                )
                self.db.add(pending)
                await self.db.commit()

                latency_ms = int((time.perf_counter() - start_time) * 1000)
                span.set(pending_confirmation=True, pending_action_id=str(pending_id))
                return ToolResult(
                    ok=False,
                    data={"pending_action_id": str(pending_id), "status": "pending_confirmation"},
                    error=ToolErrorInfo(
                        kind="idempotency",
                        detail=f"Action '{spec.name}' requires explicit user confirmation before execution.",
                    ),
                    latency_ms=latency_ms,
                    idempotency_key=idem_key,
                )

            # 5. Execution vs Staging
            # Rule: write tools never touch domain tables directly during the loop;
            # they stage in ctx.staged and return a provisional result.
            if spec.access == "write":
                staged_action = {
                    "tool": spec.name,
                    "args": args_dict,
                    "idempotency_key": idem_key,
                    "args_hash": args_hash,
                }
                ctx.staged.append(staged_action)
                latency_ms = int((time.perf_counter() - start_time) * 1000)
                span.set(staged=True)
                return ToolResult(
                    ok=True,
                    data={"staged": True, "provisional": args_dict},
                    error=None,
                    latency_ms=latency_ms,
                    idempotency_key=idem_key,
                )

            # Read tools: execute with timeout and inject user_id and run_id
            try:
                result = await asyncio.wait_for(
                    spec.handler(
                        self.db,
                        user_id=ctx.user_id,
                        run_id=ctx.run_id,
                        **args_dict,
                    ),
                    timeout=spec.timeout_s,
                )
                latency_ms = int((time.perf_counter() - start_time) * 1000)

                data = result.model_dump() if isinstance(result, BaseModel) else result
                span.set(result_summary=str(redact(data))[:150])
                return ToolResult(
                    ok=True,
                    data=data,
                    error=None,
                    latency_ms=latency_ms,
                )
            except asyncio.TimeoutError:
                err = ToolErrorInfo(
                    kind="timeout",
                    detail=f"Tool '{spec.name}' exceeded timeout of {spec.timeout_s}s",
                )
                span.record_error(TimeoutError(err.detail))
                return ToolResult(
                    ok=False,
                    data=None,
                    error=err,
                    latency_ms=int((time.perf_counter() - start_time) * 1000),
                )
            except Exception as exc:
                err = ToolErrorInfo(kind="error", detail=str(exc))
                span.record_error(exc)
                return ToolResult(
                    ok=False,
                    data=None,
                    error=err,
                    latency_ms=int((time.perf_counter() - start_time) * 1000),
                )
