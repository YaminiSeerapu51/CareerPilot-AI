"""
harness/tools/registry.py
─────────────────────────
ToolSpec and ToolRegistry: Declarative specifications for agent tools.
"""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    args_model: type[BaseModel]
    handler: Callable[..., Awaitable[BaseModel | dict[str, Any]]]
    access: Literal["read", "write"]
    idempotent: bool
    requires_confirmation: bool = False
    effect: Literal["db", "external"] = "db"
    max_calls_per_run: int = 5
    timeout_s: float = 10.0


class ToolRegistry:
    """Central registry of all tools available across the system."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        self._tools[spec.name] = spec

    def get(self, name: str) -> ToolSpec | None:
        return self._tools.get(name)

    def for_agent(self, agent: str, *, allow_list: list[str]) -> list[ToolSpec]:
        """Returns only the ToolSpecs permitted for the specified agent."""
        return [self._tools[name] for name in allow_list if name in self._tools]

    def json_schemas(self, agent: str, *, allow_list: list[str]) -> list[dict[str, Any]]:
        """Generates JSON schema definitions formatted for LLM tool_use."""
        schemas = []
        for spec in self.for_agent(agent, allow_list=allow_list):
            schemas.append({
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.args_model.model_json_schema(),
            })
        return schemas
