"""
harness/diagnosis/report.py
───────────────────────────
Diagnostic report generation aggregating span anomalies, budgets, and failure classifications.
"""
from __future__ import annotations

from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel

from app.harness.context import RunContext
from app.harness.diagnosis.taxonomy import FailureClassification


class Anomaly(BaseModel):
    span_kind: str
    description: str
    severity: Literal["critical", "warning", "info"]


class DiagnosticReport(BaseModel):
    run_id: UUID
    agent: str
    stop_reason: str
    classification: FailureClassification
    anomalies: list[Anomaly]
    spans_summary: list[dict[str, Any]]
    manifest: dict[str, Any] | None = None
    summary: str


def build_report(
    ctx: RunContext,
    classification: FailureClassification,
) -> DiagnosticReport:
    anomalies: list[Anomaly] = []

    # Detect span anomalies
    for s in ctx.spans:
        kind = s.get("kind", "unknown")
        lat = s.get("latency_ms")
        if lat and lat > 5000:
            anomalies.append(
                Anomaly(
                    span_kind=kind,
                    description=f"High latency: {lat}ms",
                    severity="warning",
                )
            )
        if s.get("error"):
            anomalies.append(
                Anomaly(
                    span_kind=kind,
                    description=f"Span error: {s.get('error')}",
                    severity="critical",
                )
            )
        if kind == "canary_leak":
            anomalies.append(
                Anomaly(
                    span_kind="gate",
                    description="Canary token leaked in output payload",
                    severity="critical",
                )
            )

    human_summary = (
        f"Diagnostic Run [{ctx.run_id}]: Agent '{ctx.agent}' stopped with '{classification.stop_reason}'. "
        f"Detected {len(classification.failure_types)} failure types, {len(anomalies)} anomalies. "
        f"Recommendation: {classification.recommended_action}"
    )

    manifest = next((s for s in ctx.spans if s.get("kind") == "context_manifest"), None)

    return DiagnosticReport(
        run_id=ctx.run_id,
        agent=ctx.agent,
        stop_reason=classification.stop_reason,
        classification=classification,
        anomalies=anomalies,
        spans_summary=ctx.spans[:25],
        manifest=manifest,
        summary=human_summary,
    )
