"""
harness/diagnosis/taxonomy.py
──────────────────────────────
Failure taxonomy and deterministic failure classification over execution traces.
"""
from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel


class FailureType(StrEnum):
    PARSE_FAIL = "parse_fail"
    EMPTY_RETRIEVAL = "empty_retrieval"
    LOW_RETRIEVAL_SCORE = "low_retrieval_score"
    WRONG_ROUTE = "wrong_route"
    SCHEMA_FAIL = "schema_fail"
    UNGROUNDED_OUTPUT = "ungrounded_output"
    TOOL_ERROR = "tool_error"
    TOOL_ARGS_INVALID = "tool_args_invalid"
    LOOP_BUDGET = "loop_budget"
    REPEATED_CALL = "repeated_call"
    GUARDRAIL_TRIP = "guardrail_trip"
    INJECTION_SUSPECTED = "injection_suspected"
    LLM_ERROR = "llm_error"
    LLM_TIMEOUT = "llm_timeout"
    MEMORY_CONFLICT = "memory_conflict"
    CONTEXT_OVERFLOW = "context_overflow"
    UNKNOWN = "unknown"


class FailureClassification(BaseModel):
    failure_types: list[FailureType]
    stop_reason: str
    summary: str
    recoverable: bool
    recommended_action: str


def classify_failure(
    stop_reason: str,
    spans: list[dict[str, Any]] | None = None,
    violations: list[Any] | None = None,
    error: str | None = None,
) -> FailureClassification:
    """Classifies root causes deterministically from trace spans and stop reason."""
    types: set[FailureType] = set()
    spans = spans or []
    violations = violations or []

    # Check violations
    for v in violations:
        kind = getattr(v, "kind", str(v))
        if kind == "canary":
            types.add(FailureType.INJECTION_SUSPECTED)
            types.add(FailureType.GUARDRAIL_TRIP)
        elif kind == "grounding":
            types.add(FailureType.UNGROUNDED_OUTPUT)
            types.add(FailureType.GUARDRAIL_TRIP)
        elif kind == "schema":
            types.add(FailureType.SCHEMA_FAIL)

    # Check stop reason
    sr_lower = stop_reason.lower()
    if "repeated" in sr_lower:
        types.add(FailureType.REPEATED_CALL)
    elif "budget" in sr_lower or "max_steps" in sr_lower or "max_tool" in sr_lower:
        types.add(FailureType.LOOP_BUDGET)
    elif "timeout" in sr_lower:
        types.add(FailureType.LLM_TIMEOUT)
    elif "guardrail" in sr_lower:
        types.add(FailureType.GUARDRAIL_TRIP)

    # Check span signatures
    for s in spans:
        kind = s.get("kind")
        if kind == "schema_error":
            types.add(FailureType.SCHEMA_FAIL)
        elif s.get("empty") or "below threshold" in str(s.get("reason", "")):
            types.add(FailureType.EMPTY_RETRIEVAL)
        elif s.get("status") == "error":
            if kind == "tool":
                types.add(FailureType.TOOL_ERROR)
            elif kind == "llm":
                types.add(FailureType.LLM_ERROR)

    if not types:
        if error:
            types.add(FailureType.LLM_ERROR)
        else:
            types.add(FailureType.UNKNOWN)

    type_list = list(types)
    is_recoverable = bool(
        FailureType.LLM_TIMEOUT in types
        or FailureType.SCHEMA_FAIL in types
        or FailureType.TOOL_ERROR in types
    )

    rec_action = "Review agent prompts and test case"
    if FailureType.INJECTION_SUSPECTED in types:
        rec_action = "Inspect untrusted input and rotate canary token"
    elif FailureType.UNGROUNDED_OUTPUT in types:
        rec_action = "Increase source chunk retrieval count or tune grounding regex/aliases"
    elif FailureType.LOOP_BUDGET in types:
        rec_action = "Increase LoopBudget limits or refine tool descriptions to reduce exploratory calls"

    return FailureClassification(
        failure_types=type_list,
        stop_reason=stop_reason,
        summary=f"Run terminated with {stop_reason}; classified as {[t.value for t in type_list]}",
        recoverable=is_recoverable,
        recommended_action=rec_action,
    )
