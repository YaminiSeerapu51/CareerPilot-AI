"""
harness/diagnosis package
─────────────────────────
Exports FailureType, FailureClassification, classify_failure, Anomaly, DiagnosticReport, build_report.
"""
from __future__ import annotations

from app.harness.diagnosis.report import Anomaly, DiagnosticReport, build_report
from app.harness.diagnosis.taxonomy import FailureClassification, FailureType, classify_failure

__all__ = [
    "FailureType",
    "FailureClassification",
    "classify_failure",
    "Anomaly",
    "DiagnosticReport",
    "build_report",
]
