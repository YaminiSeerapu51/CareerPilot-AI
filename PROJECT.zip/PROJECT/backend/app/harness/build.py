"""
harness/build.py
────────────────
build_harness() — the single factory that wires up the HookBus,
registers all mandatory hooks, seals the bus, and returns the
fully-configured harness components.

This is the ONLY place mandatory hooks may be registered.
After seal(), no new mandatory hooks can be added.

Mandatory hooks installed (in phase order):

  RUN_START    │ SECURITY │ mint_canary      — generate per-run canary token
               │ SECURITY │ start_trace      — open the runs row
               │ POLICY   │ load_budget      — read LoopBudget for this agent

  PRE_LLM      │ SECURITY │ enforce_untrusted_wrapping — reject raw str in untrusted slots
               │ POLICY   │ token_budget_check — stop on token budget
               │ POLICY   │ cost_budget_check  — stop on cost budget

  POST_LLM     │ SECURITY │ canary_scan      — block if canary appears in LLM output
               │ POLICY   │ schema_parse     — validate structured output
               │ OBSERVE  │ record_usage     — tokens + cost into span

  PRE_TOOL     │ SECURITY │ permission_check — allow-list enforcement
               │ POLICY   │ repeat_detector  — repeated-call detection
               │ POLICY   │ confirmation_gate — requires_confirmation enforcement

  POST_TOOL    │ OBSERVE  │ record_tool_span — latency + result into trace
               │ POLICY   │ error_streak     — consecutive error counter
               │ POLICY   │ progress_detector — no-progress hash check

  PRE_FINAL    │ SECURITY │ final_gate       — H5.4 checks (schema, canary, grounding, ...)

  MEMORY_WRITE │ POLICY   │ memory_policy    — provenance caps, kind validation
"""
from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass
from typing import Any

from app.harness.hooks import (
    Allow,
    Block,
    HookBus,
    HookCtx,
    HookDecision,
    HookEvent,
    Modify,
    Phase,
)
from app.harness.context import RunContext


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _ctx_from(hook_ctx: HookCtx) -> RunContext:
    return hook_ctx.meta["run_ctx"]


# ---------------------------------------------------------------------------
# RUN_START hooks
# ---------------------------------------------------------------------------

async def _mint_canary(ctx: HookCtx) -> HookDecision:
    """Already set by new_run_context(); assert it's non-empty."""
    run_ctx: RunContext = _ctx_from(ctx)
    if not run_ctx.canary:
        return Block(reason="canary not minted", violation_kind="canary_missing")
    return Allow()


async def _start_trace(ctx: HookCtx) -> HookDecision:
    run_ctx: RunContext = _ctx_from(ctx)
    run_ctx.spans.append({
        "kind": "run_start",
        "run_id": str(run_ctx.run_id),
        "agent": run_ctx.agent,
        "started_at": time.time(),
    })
    return Allow()


async def _load_budget(ctx: HookCtx) -> HookDecision:
    """Budget is passed in meta by the caller; just validate it's present."""
    if "budget" not in ctx.meta:
        return Block(reason="no budget set for run", violation_kind="budget_missing")
    return Allow()


# ---------------------------------------------------------------------------
# PRE_LLM hooks
# ---------------------------------------------------------------------------

async def _enforce_untrusted_wrapping(ctx: HookCtx) -> HookDecision:
    """
    Scan the prompt payload for any retrieved content that appears outside
    a delimiter block.  We look for the per-request nonce (set in RunContext)
    being present when there IS retrieved content.
    Implements HAR-27.
    """
    run_ctx: RunContext = _ctx_from(ctx)
    prompt: dict[str, Any] = ctx.payload
    messages = prompt.get("messages", [])
    nonce = run_ctx.nonce

    for msg in messages:
        content = msg.get("content", "")
        # If there's any retrieved content signal but no nonce delimiter, block.
        if "<<<DATA-" in content and f"DATA-{nonce}" not in content:
            return Block(
                reason="retrieved content outside untrusted delimiter",
                violation_kind="untrusted_wrapping",
            )
    return Allow()


async def _token_budget_check(ctx: HookCtx) -> HookDecision:
    run_ctx: RunContext = _ctx_from(ctx)
    budget = ctx.meta.get("budget")
    if budget and run_ctx.token_count >= budget.max_total_tokens:
        return Block(reason="token budget exceeded", violation_kind="budget")
    return Allow()


async def _cost_budget_check(ctx: HookCtx) -> HookDecision:
    run_ctx: RunContext = _ctx_from(ctx)
    budget = ctx.meta.get("budget")
    if budget and run_ctx.cost_usd >= budget.max_cost_usd:
        return Block(reason="cost budget exceeded", violation_kind="budget")
    return Allow()


# ---------------------------------------------------------------------------
# POST_LLM hooks
# ---------------------------------------------------------------------------

_SLIDING_WINDOW = 80   # chars scanned on each new chunk for canary detection


async def _canary_scan(ctx: HookCtx) -> HookDecision:
    """
    Block if the per-run canary token appears in the LLM output.
    This catches real prompt leakage regardless of phrasing.
    """
    run_ctx: RunContext = _ctx_from(ctx)
    output: str = ctx.payload if isinstance(ctx.payload, str) else str(ctx.payload)
    if run_ctx.canary in output:
        run_ctx.spans.append({
            "kind": "canary_leak",
            "canary_prefix": run_ctx.canary[:12] + "...",
            "snippet": output[:200],
        })
        return Block(reason="canary token detected in output", violation_kind="canary_leak")
    return Allow()


async def _record_usage(ctx: HookCtx) -> HookDecision:
    run_ctx: RunContext = _ctx_from(ctx)
    usage: dict = ctx.meta.get("usage", {})
    run_ctx.token_count += usage.get("input_tokens", 0) + usage.get("output_tokens", 0)
    run_ctx.spans.append({
        "kind": "llm_usage",
        "input_tokens": usage.get("input_tokens", 0),
        "output_tokens": usage.get("output_tokens", 0),
        "model": usage.get("model", "unknown"),
    })
    return Allow()


async def _schema_parse(ctx: HookCtx) -> HookDecision:
    """Schema validation is handled inline by the loop; this hook logs the result."""
    meta = ctx.meta
    if meta.get("schema_error"):
        _ctx_from(ctx).spans.append({
            "kind": "schema_error",
            "detail": meta["schema_error"],
        })
    return Allow()


# ---------------------------------------------------------------------------
# PRE_TOOL hooks
# ---------------------------------------------------------------------------

async def _permission_check(ctx: HookCtx) -> HookDecision:
    tool_name: str = ctx.payload.get("name", "")
    allow_list: list[str] = ctx.meta.get("allow_list", [])
    if tool_name not in allow_list:
        return Block(
            reason=f"tool '{tool_name}' not in agent allow-list",
            violation_kind="not_allowed",
        )
    return Allow()


async def _repeat_detector(ctx: HookCtx) -> HookDecision:
    run_ctx: RunContext = _ctx_from(ctx)
    call = ctx.payload
    canonical = hashlib.sha256(
        f"{call.get('name')}:{sorted(call.get('args', {}).items())}".encode()
    ).hexdigest()[:16]

    counts: dict[str, int] = ctx.meta.setdefault("call_counts", {})
    counts[canonical] = counts.get(canonical, 0) + 1

    budget = ctx.meta.get("budget")
    limit = budget.max_identical_calls if budget else 2
    if counts[canonical] > limit:
        return Block(reason=f"repeated tool call: {call.get('name')}", violation_kind="repeated_call")
    return Allow()


async def _confirmation_gate(ctx: HookCtx) -> HookDecision:
    """
    requires_confirmation tools must be confirmed by the user via
    POST /api/actions/{id}/confirm — never by the model.
    """
    spec = ctx.meta.get("tool_spec")
    if spec and getattr(spec, "requires_confirmation", False):
        return Modify(payload={**ctx.payload, "_pending_confirmation": True})
    return Allow()


# ---------------------------------------------------------------------------
# POST_TOOL hooks
# ---------------------------------------------------------------------------

async def _record_tool_span(ctx: HookCtx) -> HookDecision:
    run_ctx: RunContext = _ctx_from(ctx)
    result = ctx.payload
    run_ctx.spans.append({
        "kind": "tool_call",
        "tool": ctx.meta.get("tool_name"),
        "latency_ms": result.get("latency_ms"),
        "ok": result.get("ok"),
        "error": result.get("error"),
    })
    return Allow()


async def _error_streak(ctx: HookCtx) -> HookDecision:
    result = ctx.payload
    meta = ctx.meta
    if not result.get("ok"):
        meta["consecutive_errors"] = meta.get("consecutive_errors", 0) + 1
    else:
        meta["consecutive_errors"] = 0

    budget = meta.get("budget")
    limit = budget.max_consecutive_errors if budget else 2
    if meta.get("consecutive_errors", 0) > limit:
        return Block(reason="error streak exceeded", violation_kind="error_streak")
    return Allow()


async def _progress_detector(ctx: HookCtx) -> HookDecision:
    meta = ctx.meta
    state_sig = hashlib.sha256(str(ctx.payload).encode()).hexdigest()[:16]
    last = meta.get("last_state_sig")
    same_count = meta.get("same_state_count", 0)
    if state_sig == last:
        same_count += 1
    else:
        same_count = 0
    meta["last_state_sig"] = state_sig
    meta["same_state_count"] = same_count
    if same_count >= 2:
        return Block(reason="no progress detected", violation_kind="no_progress")
    return Allow()


# ---------------------------------------------------------------------------
# PRE_FINAL hooks
# ---------------------------------------------------------------------------

async def _final_gate(ctx: HookCtx) -> HookDecision:
    """
    Delegates to FinalGate.check().  The gate is instantiated with the
    RunContext available in meta.
    """
    from app.harness.gates import FinalGate
    run_ctx: RunContext = _ctx_from(ctx)
    gate = FinalGate(run_ctx)
    result = gate.check(
        ctx.payload,
        model_cls=ctx.meta.get("model_cls"),
        retrieved_ids=ctx.meta.get("retrieved_ids"),
        jd_keywords=ctx.meta.get("jd_keywords"),
        system_prompt=ctx.meta.get("system_prompt"),
    )
    if not result.passed:
        details = "; ".join(v.detail for v in result.violations)
        return Block(reason=f"FinalGate failed: {details}", violation_kind="guardrail_block")
    return Allow()


# ---------------------------------------------------------------------------
# MEMORY_WRITE hooks
# ---------------------------------------------------------------------------

async def _memory_policy(ctx: HookCtx) -> HookDecision:
    """
    Enforce provenance caps:
    - Facts from resume_doc / jd_doc cannot have confidence > 0.6.
    - kind must be a valid FactKind value.
    """
    from app.harness.memory.semantic import FactKind
    fact = ctx.payload
    source = getattr(fact, "source", None) or fact.get("source", "")
    confidence = getattr(fact, "confidence", None) or fact.get("confidence", 1.0)
    kind = getattr(fact, "kind", None) or fact.get("kind", "")

    if source in ("resume_doc", "jd_doc") and confidence > 0.6:
        # Silently cap rather than block — the cap is the defense
        if hasattr(fact, "__dict__"):
            object.__setattr__(fact, "confidence", 0.6) if hasattr(fact, "__dataclass_fields__") else setattr(fact, "confidence", 0.6)
        else:
            fact["confidence"] = 0.6

    valid_kinds = {k.value for k in FactKind.__members__.values()} if hasattr(FactKind, "__members__") else set(FactKind)
    if kind not in valid_kinds:
        return Block(reason=f"invalid fact kind: {kind!r}", violation_kind="memory_policy")

    return Allow()


# ---------------------------------------------------------------------------
# build_harness()
# ---------------------------------------------------------------------------

@dataclass
class Harness:
    bus: HookBus


def build_harness() -> Harness:
    """
    Wire up the HookBus with all mandatory hooks and seal it.
    Call this ONCE at application startup.
    """
    bus = HookBus()

    # RUN_START
    bus.register(HookEvent.RUN_START,    _mint_canary,   mandatory=True, phase=Phase.SECURITY)
    bus.register(HookEvent.RUN_START,    _start_trace,   mandatory=True, phase=Phase.SECURITY)
    bus.register(HookEvent.RUN_START,    _load_budget,   mandatory=True, phase=Phase.POLICY)

    # PRE_LLM
    bus.register(HookEvent.PRE_LLM,      _enforce_untrusted_wrapping, mandatory=True, phase=Phase.SECURITY)
    bus.register(HookEvent.PRE_LLM,      _token_budget_check,         mandatory=True, phase=Phase.POLICY)
    bus.register(HookEvent.PRE_LLM,      _cost_budget_check,          mandatory=True, phase=Phase.POLICY)

    # POST_LLM
    bus.register(HookEvent.POST_LLM,     _canary_scan,   mandatory=True, phase=Phase.SECURITY)
    bus.register(HookEvent.POST_LLM,     _schema_parse,  mandatory=True, phase=Phase.POLICY)
    bus.register(HookEvent.POST_LLM,     _record_usage,  mandatory=True, phase=Phase.OBSERVE)

    # PRE_TOOL
    bus.register(HookEvent.PRE_TOOL,     _permission_check,  mandatory=True, phase=Phase.SECURITY)
    bus.register(HookEvent.PRE_TOOL,     _repeat_detector,   mandatory=True, phase=Phase.POLICY)
    bus.register(HookEvent.PRE_TOOL,     _confirmation_gate, mandatory=True, phase=Phase.POLICY)

    # POST_TOOL
    bus.register(HookEvent.POST_TOOL,    _record_tool_span,  mandatory=True, phase=Phase.OBSERVE)
    bus.register(HookEvent.POST_TOOL,    _error_streak,      mandatory=True, phase=Phase.POLICY)
    bus.register(HookEvent.POST_TOOL,    _progress_detector, mandatory=True, phase=Phase.POLICY)

    # PRE_FINAL
    bus.register(HookEvent.PRE_FINAL,    _final_gate,        mandatory=True, phase=Phase.SECURITY)

    # MEMORY_WRITE
    bus.register(HookEvent.MEMORY_WRITE, _memory_policy,     mandatory=True, phase=Phase.POLICY)

    bus.seal()
    return Harness(bus=bus)
