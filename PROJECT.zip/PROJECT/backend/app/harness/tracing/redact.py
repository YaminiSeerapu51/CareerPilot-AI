"""
harness/tracing/redact.py
─────────────────────────
Payload redaction before storage. Never let secrets reach the trace DB.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any

from app.config import get_settings

SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"sk-ant-[a-zA-Z0-9_\-]+", re.I), "[REDACTED_ANTHROPIC_KEY]"),
    (re.compile(r"Bearer\s+[a-zA-Z0-9_\-\.]+", re.I), "Bearer [REDACTED_TOKEN]"),
    (re.compile(r"(postgresql(?:\+[a-z0-9]+)?://[^:]+:)[^@]+(@)", re.I), r"\1[REDACTED_PASSWORD]\2"),
    (re.compile(r"(jwt_secret|password|secret|api_key)[\"']?\s*[:=]\s*[\"']?[^\"',\s]+", re.I), r"\1=[REDACTED]"),
]


def redact_string(val: str, *, truncate_length: int = 200, trace_payloads: bool | None = None) -> str:
    if trace_payloads is None:
        trace_payloads = get_settings().trace_payloads

    cleaned = val
    for pattern, replacement in SECRET_PATTERNS:
        cleaned = pattern.sub(replacement, cleaned)

    if not trace_payloads and len(cleaned) > truncate_length:
        h = hashlib.sha256(cleaned.encode("utf-8")).hexdigest()[:12]
        return f"{cleaned[:truncate_length]}... [sha256:{h}]"

    return cleaned


def redact(obj: Any, *, truncate_length: int = 200, trace_payloads: bool | None = None) -> Any:
    """
    Recursively walk dicts/lists/strings, scrubbing secret patterns and truncating
    large unstructured bodies unless trace_payloads is explicitly enabled.
    Never mutates the input; returns a sanitized deep-copy.
    """
    if isinstance(obj, str):
        return redact_string(obj, truncate_length=truncate_length, trace_payloads=trace_payloads)
    if isinstance(obj, dict):
        return {
            str(k): redact(v, truncate_length=truncate_length, trace_payloads=trace_payloads)
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [redact(item, truncate_length=truncate_length, trace_payloads=trace_payloads) for item in obj]
    if isinstance(obj, tuple):
        return tuple(redact(item, truncate_length=truncate_length, trace_payloads=trace_payloads) for item in obj)
    if isinstance(obj, set):
        return [redact(item, truncate_length=truncate_length, trace_payloads=trace_payloads) for item in obj]
    return obj
