"""
harness/tracing/langfuse.py
───────────────────────────
Optional Langfuse tracer integration (env-gated, no-op if package not installed).
"""
from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any
from uuid import UUID

from app.config import get_settings
from app.harness.tracing.tracer import RunHandle, SpanHandle, SpanKind, Tracer

logger = logging.getLogger(__name__)


class NoOpSpanHandle:
    def set(self, **attrs: Any) -> None:
        pass

    def record_llm(self, model: str, tokens_in: int, tokens_out: int) -> None:
        pass

    def record_error(self, exc: BaseException) -> None:
        pass


class NoOpRunHandle:
    def __init__(self, run_id: UUID) -> None:
        self.run_id = run_id

    def set(self, **attrs: Any) -> None:
        pass

    def record_usage(self, model: str, tokens_in: int, tokens_out: int, cost_usd: float) -> None:
        pass

    async def finish(self, stop_reason: str, failure_types: list[str] | None = None) -> None:
        pass


class LangfuseTracer:
    """Env-gated Langfuse tracer. Defaults to safe no-op if unconfigured or uninstalled."""

    def __init__(self) -> None:
        settings = get_settings()
        self.enabled = bool(
            settings.tracing_backend in ("langfuse", "both") and settings.langfuse_secret_key
        )
        self._client = None
        if self.enabled:
            try:
                import langfuse
                self._client = langfuse.Langfuse(
                    public_key=settings.langfuse_public_key,
                    secret_key=settings.langfuse_secret_key,
                    host=settings.langfuse_host or "https://cloud.langfuse.com",
                )
            except ImportError:
                logger.info("Langfuse requested but package 'langfuse' is not installed; running as no-op.")
                self.enabled = False

    @asynccontextmanager
    async def run(self, user_id: UUID, intent: str, **attrs: Any) -> AsyncIterator[RunHandle]:
        from uuid import uuid4
        run_id = attrs.get("run_id") or uuid4()
        yield NoOpRunHandle(run_id=run_id)

    @asynccontextmanager
    async def span(self, kind: SpanKind, name: str, **attrs: Any) -> AsyncIterator[SpanHandle]:
        yield NoOpSpanHandle()
