"""
harness/tracing/tracer.py
─────────────────────────
Tracer interface (H7.2) and span protocols.
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, Protocol
from uuid import UUID, uuid4


class SpanKind(StrEnum):
    LLM = "llm"
    TOOL = "tool"
    RETRIEVAL = "retrieval"
    MEMORY = "memory"
    GATE = "gate"
    HOOK = "hook"


class SpanStatus(StrEnum):
    OK = "ok"
    ERROR = "error"
    BLOCKED = "blocked"


@dataclass
class Span:
    id: UUID = field(default_factory=uuid4)
    run_id: UUID | None = None
    parent_id: UUID | None = None
    kind: SpanKind = SpanKind.HOOK
    name: str = ""
    started_at: datetime = field(default_factory=datetime.utcnow)
    ended_at: datetime | None = None
    latency_ms: int | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    status: SpanStatus = SpanStatus.OK
    error: str | None = None
    attrs: dict[str, Any] = field(default_factory=dict)
    input_ref: str | None = None
    output_ref: str | None = None
    children: list[Span] = field(default_factory=list)


class SpanHandle(Protocol):
    def set(self, **attrs: Any) -> None:
        """Set custom attributes on the span."""
        ...

    def record_llm(self, model: str, tokens_in: int, tokens_out: int) -> None:
        """Record model name and token counts."""
        ...

    def record_error(self, exc: BaseException) -> None:
        """Record error details and mark status as error."""
        ...


class RunHandle(Protocol):
    run_id: UUID

    def set(self, **attrs: Any) -> None:
        ...

    def record_usage(self, model: str, tokens_in: int, tokens_out: int, cost_usd: float) -> None:
        ...

    async def finish(self, stop_reason: str, failure_types: list[str] | None = None) -> None:
        ...


class Tracer(Protocol):
    def run(self, user_id: UUID, intent: str, **attrs: Any) -> Any:
        ...

    def span(self, kind: SpanKind, name: str, **attrs: Any) -> Any:
        ...
