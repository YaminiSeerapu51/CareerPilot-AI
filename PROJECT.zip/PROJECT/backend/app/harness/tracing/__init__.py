"""
harness/tracing package
───────────────────────
Exports Tracer protocol, PostgresTracer, LangfuseTracer, get_tracer(), and utility functions.
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any
from uuid import UUID

from app.config import get_settings
from app.harness.tracing.cost import compute_cost, load_price_table
from app.harness.tracing.langfuse import LangfuseTracer
from app.harness.tracing.postgres import PostgresTracer
from app.harness.tracing.redact import redact, redact_string
from app.harness.tracing.tracer import RunHandle, Span, SpanHandle, SpanKind, SpanStatus, Tracer


class CompositeRunHandle:
    def __init__(self, handles: list[RunHandle]) -> None:
        self.handles = handles
        self.run_id = handles[0].run_id if handles else UUID(int=0)

    def set(self, **attrs: Any) -> None:
        for h in self.handles:
            h.set(**attrs)

    def record_usage(self, model: str, tokens_in: int, tokens_out: int, cost_usd: float) -> None:
        for h in self.handles:
            h.record_usage(model, tokens_in, tokens_out, cost_usd)

    async def finish(self, stop_reason: str, failure_types: list[str] | None = None) -> None:
        for h in self.handles:
            await h.finish(stop_reason, failure_types)


class CompositeSpanHandle:
    def __init__(self, handles: list[SpanHandle]) -> None:
        self.handles = handles

    def set(self, **attrs: Any) -> None:
        for h in self.handles:
            h.set(**attrs)

    def record_llm(self, model: str, tokens_in: int, tokens_out: int) -> None:
        for h in self.handles:
            h.record_llm(model, tokens_in, tokens_out)

    def record_error(self, exc: BaseException) -> None:
        for h in self.handles:
            h.record_error(exc)


class CompositeTracer:
    def __init__(self, tracers: list[Tracer]) -> None:
        self.tracers = tracers

    @asynccontextmanager
    async def run(self, user_id: UUID, intent: str, **attrs: Any) -> AsyncIterator[RunHandle]:
        cms = [t.run(user_id, intent, **attrs) for t in self.tracers]
        handles: list[RunHandle] = []
        try:
            for cm in cms:
                h = await cm.__aenter__()
                handles.append(h)
            yield CompositeRunHandle(handles)
        finally:
            for cm in reversed(cms):
                await cm.__aexit__(None, None, None)

    @asynccontextmanager
    async def span(self, kind: SpanKind, name: str, **attrs: Any) -> AsyncIterator[SpanHandle]:
        cms = [t.span(kind, name, **attrs) for t in self.tracers]
        handles: list[SpanHandle] = []
        try:
            for cm in cms:
                h = await cm.__aenter__()
                handles.append(h)
            yield CompositeSpanHandle(handles)
        finally:
            for cm in reversed(cms):
                await cm.__aexit__(None, None, None)


_TRACER_INSTANCE: Tracer | None = None


def get_tracer() -> Tracer:
    global _TRACER_INSTANCE
    if _TRACER_INSTANCE is not None:
        return _TRACER_INSTANCE

    settings = get_settings()
    backend = settings.tracing_backend.lower()

    if backend == "both":
        _TRACER_INSTANCE = CompositeTracer([PostgresTracer(), LangfuseTracer()])
    elif backend == "langfuse":
        _TRACER_INSTANCE = LangfuseTracer()
    else:
        _TRACER_INSTANCE = PostgresTracer()

    return _TRACER_INSTANCE


__all__ = [
    "Tracer",
    "Span",
    "SpanHandle",
    "RunHandle",
    "SpanKind",
    "SpanStatus",
    "PostgresTracer",
    "LangfuseTracer",
    "CompositeTracer",
    "get_tracer",
    "compute_cost",
    "load_price_table",
    "redact",
    "redact_string",
]
