"""
harness/tracing/postgres.py
───────────────────────────
PostgresTracer: Default tracing implementation storing runs and spans in Postgres.
"""
from __future__ import annotations

import contextvars
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Run, SpanModel, SpanPayload
from app.db.session import SessionLocal
from app.harness.tracing.cost import compute_cost
from app.harness.tracing.redact import redact
from app.harness.tracing.tracer import RunHandle, SpanHandle, SpanKind, SpanStatus, Tracer

_current_run_ctx: contextvars.ContextVar[PostgresRunHandle | None] = contextvars.ContextVar(
    "_current_run_ctx", default=None
)
_current_span_id: contextvars.ContextVar[UUID | None] = contextvars.ContextVar(
    "_current_span_id", default=None
)


class PostgresSpanHandle:
    def __init__(
        self,
        span_id: UUID,
        run_id: UUID,
        kind: SpanKind,
        name: str,
        attrs: dict[str, Any],
    ) -> None:
        self.span_id = span_id
        self.run_id = run_id
        self.kind = kind
        self.name = name
        self.attrs = attrs
        self.tokens_in = 0
        self.tokens_out = 0
        self.status = SpanStatus.OK
        self.error: str | None = None
        self.started_perf = time.perf_counter()
        self.started_at = datetime.utcnow()
        self.input_redacted: str | None = None
        self.output_redacted: str | None = None
        self.full_input: str | None = None
        self.full_output: str | None = None

    def set(self, **attrs: Any) -> None:
        self.attrs.update(attrs)

    def record_llm(self, model: str, tokens_in: int, tokens_out: int) -> None:
        self.tokens_in += tokens_in
        self.tokens_out += tokens_out
        self.attrs["model"] = model
        run = _current_run_ctx.get()
        if run:
            cost = compute_cost(model, tokens_in, tokens_out)
            run.record_usage(model, tokens_in, tokens_out, cost)

    def record_error(self, exc: BaseException) -> None:
        self.status = SpanStatus.ERROR
        self.error = str(exc)
        self.attrs["exception_type"] = type(exc).__name__

    def set_payload(self, input_data: Any = None, output_data: Any = None) -> None:
        if input_data is not None:
            self.input_redacted = str(redact(input_data))
            self.full_input = str(input_data)
        if output_data is not None:
            self.output_redacted = str(redact(output_data))
            self.full_output = str(output_data)


class PostgresRunHandle:
    def __init__(self, run_id: UUID, user_id: UUID, intent: str, attrs: dict[str, Any]) -> None:
        self.run_id = run_id
        self.user_id = user_id
        self.intent = intent
        self.attrs = attrs
        self.total_tokens_in = 0
        self.total_tokens_out = 0
        self.cost_usd = 0.0
        self.model_by_role: dict[str, str] = {}
        self.prompt_versions: dict[str, Any] = {}
        self.failure_types: list[str] = []
        self.stop_reason: str | None = None

    def set(self, **attrs: Any) -> None:
        self.attrs.update(attrs)
        if "prompt_versions" in attrs and isinstance(attrs["prompt_versions"], dict):
            self.prompt_versions.update(attrs["prompt_versions"])
        if "eval_case_id" in attrs:
            self.attrs["eval_case_id"] = attrs["eval_case_id"]

    def record_usage(self, model: str, tokens_in: int, tokens_out: int, cost_usd: float) -> None:
        self.total_tokens_in += tokens_in
        self.total_tokens_out += tokens_out
        self.cost_usd = round(self.cost_usd + cost_usd, 6)
        role = self.attrs.get("role", "default")
        self.model_by_role[role] = model

    async def finish(self, stop_reason: str, failure_types: list[str] | None = None) -> None:
        self.stop_reason = stop_reason
        if failure_types:
            self.failure_types.extend(failure_types)
        async with SessionLocal() as db:
            await db.execute(
                update(Run)
                .where(Run.id == self.run_id)
                .values(
                    ended_at=datetime.utcnow(),
                    stop_reason=self.stop_reason,
                    total_tokens_in=self.total_tokens_in,
                    total_tokens_out=self.total_tokens_out,
                    cost_usd=self.cost_usd,
                    model_by_role=self.model_by_role,
                    prompt_versions=self.prompt_versions,
                    failure_types=self.failure_types,
                )
            )
            await db.commit()


class PostgresTracer:
    """Postgres-backed distributed tracer for agent operations."""

    @asynccontextmanager
    async def run(self, user_id: UUID, intent: str, **attrs: Any) -> AsyncIterator[PostgresRunHandle]:
        run_id = attrs.pop("run_id", None) or uuid4()
        session_id = attrs.pop("session_id", None)
        handle = PostgresRunHandle(run_id=run_id, user_id=user_id, intent=intent, attrs=attrs)

        async with SessionLocal() as db:
            db_run = Run(
                id=run_id,
                user_id=user_id,
                session_id=session_id,
                root_intent=intent,
                started_at=datetime.utcnow(),
                eval_case_id=attrs.get("eval_case_id"),
            )
            db.add(db_run)
            await db.commit()

        token = _current_run_ctx.set(handle)
        try:
            yield handle
        finally:
            _current_run_ctx.reset(token)

    @asynccontextmanager
    async def span(self, kind: SpanKind, name: str, **attrs: Any) -> AsyncIterator[PostgresSpanHandle]:
        run = _current_run_ctx.get()
        run_id = run.run_id if run else uuid4()
        parent_id = _current_span_id.get()
        span_id = uuid4()

        handle = PostgresSpanHandle(
            span_id=span_id,
            run_id=run_id,
            kind=kind,
            name=name,
            attrs=dict(attrs),
        )

        parent_token = _current_span_id.set(span_id)
        try:
            yield handle
        except BaseException as exc:
            handle.record_error(exc)
            raise
        finally:
            _current_span_id.reset(parent_token)
            latency_ms = int((time.perf_counter() - handle.started_perf) * 1000)

            # Persist span
            try:
                async with SessionLocal() as db:
                    span_rec = SpanModel(
                        id=handle.span_id,
                        run_id=handle.run_id,
                        parent_id=parent_id,
                        kind=handle.kind.value if hasattr(handle.kind, "value") else str(handle.kind),
                        name=handle.name,
                        started_at=handle.started_at,
                        latency_ms=latency_ms,
                        tokens_in=handle.tokens_in,
                        tokens_out=handle.tokens_out,
                        status=handle.status.value if hasattr(handle.status, "value") else str(handle.status),
                        error=handle.error,
                        attrs=redact(handle.attrs),
                    )
                    db.add(span_rec)

                    if handle.input_redacted is not None or handle.output_redacted is not None:
                        payload_rec = SpanPayload(
                            span_id=handle.span_id,
                            input_redacted=handle.input_redacted,
                            output_redacted=handle.output_redacted,
                            full_input=handle.full_input,
                            full_output=handle.full_output,
                        )
                        db.add(payload_rec)

                    await db.commit()
            except Exception:
                # Tracing persistence must never crash the main application thread
                pass
