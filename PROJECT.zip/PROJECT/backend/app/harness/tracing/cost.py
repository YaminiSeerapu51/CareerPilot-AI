"""
harness/tracing/cost.py
───────────────────────
Token → USD cost calculation using configurable price table.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from app.config import get_settings

logger = logging.getLogger(__name__)

# Default price table (USD per 1M tokens) if file not found
DEFAULT_PRICES: dict[str, dict[str, float]] = {
    "claude-haiku-4-5": {"input": 0.80, "output": 4.00},
    "claude-3-5-haiku-20241022": {"input": 0.80, "output": 4.00},
    "claude-sonnet-5": {"input": 3.00, "output": 15.00},
    "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
    "default": {"input": 1.00, "output": 5.00},
}

_CACHED_PRICES: dict[str, dict[str, float]] | None = None


def load_price_table() -> dict[str, dict[str, float]]:
    global _CACHED_PRICES
    if _CACHED_PRICES is not None:
        return _CACHED_PRICES

    settings = get_settings()
    path = Path(settings.price_table_path)
    if not path.is_file():
        # Try relative to repo root if run from backend/
        alt_path = Path("..") / settings.price_table_path
        if alt_path.is_file():
            path = alt_path

    if path.is_file():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                if isinstance(data, dict):
                    _CACHED_PRICES = data
                    return _CACHED_PRICES
        except Exception as e:
            logger.warning("Failed to load price table from %s: %s", path, e)

    _CACHED_PRICES = DEFAULT_PRICES
    return _CACHED_PRICES


def compute_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Compute USD cost given token counts and model name."""
    table = load_price_table()
    rates = table.get(model, table.get("default", {"input": 1.00, "output": 5.00}))
    in_cost = (input_tokens / 1_000_000.0) * rates.get("input", 1.0)
    out_cost = (output_tokens / 1_000_000.0) * rates.get("output", 5.0)
    return round(in_cost + out_cost, 6)
