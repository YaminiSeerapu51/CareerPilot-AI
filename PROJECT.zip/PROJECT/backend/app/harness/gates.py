"""
harness/gates.py
────────────────
FinalGate: Deterministic guardrail validation before output is shown to user or committed.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, ValidationError

from app.harness.context import RunContext

_ALIAS_TABLE: dict[str, str] = {
    "k8s": "kubernetes",
    "ml": "machine learning",
    "ai": "artificial intelligence",
    "js": "javascript",
    "ts": "typescript",
    "pg": "postgresql",
    "postgres": "postgresql",
    "aws": "amazon web services",
    "gcp": "google cloud platform",
}

_NUMBER_WORDS: dict[str, str] = {
    "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4",
    "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
}


def normalize_for_grounding(text: str) -> str:
    """Normalize text for deterministic grounding check."""
    normalized = unicodedata.normalize("NFKC", text).lower()
    for word, digit in _NUMBER_WORDS.items():
        normalized = re.sub(rf"\b{word}\b", digit, normalized)
    for alias, full in _ALIAS_TABLE.items():
        normalized = re.sub(rf"\b{alias}\b", full, normalized)
    return normalized


@dataclass
class Violation:
    kind: Literal["schema", "canary", "grounding", "scope", "leak", "claims"]
    detail: str
    severity: Literal["critical", "warning"] = "critical"


@dataclass
class GateResult:
    passed: bool
    violations: list[Violation]
    sanitized_output: str | None = None


class FinalGate:
    """Deterministic, code-enforced gate evaluated before release or database commit."""

    def __init__(self, ctx: RunContext) -> None:
        self.ctx = ctx

    def check(
        self,
        output: Any,
        *,
        model_cls: type[BaseModel] | None = None,
        retrieved_ids: set[str] | None = None,
        source_chunks: dict[str, str] | None = None,
        jd_keywords: list[str] | None = None,
        system_prompt: str | None = None,
    ) -> GateResult:
        violations: list[Violation] = []
        out_str = output if isinstance(output, str) else str(output)

        # 1. Schema check
        if model_cls is not None:
            if isinstance(output, dict):
                try:
                    model_cls.model_validate(output)
                except ValidationError as ve:
                    violations.append(Violation(kind="schema", detail=f"Pydantic validation failed: {ve}"))
            elif isinstance(output, str):
                try:
                    import json
                    from app.llm.guardrails import _extract_json
                    candidate = json.loads(_extract_json(output))
                    model_cls.model_validate(candidate)
                except Exception as e:
                    violations.append(Violation(kind="schema", detail=f"Failed to parse structured JSON: {e}"))

        # 2. Canary check (per-run nonce leak)
        if self.ctx.canary and self.ctx.canary in out_str:
            violations.append(
                Violation(
                    kind="canary",
                    detail="Canary token detected in output. Possible prompt injection or prompt leak.",
                )
            )

        # 3. Grounding check
        # For rewrites: verify numbers/percentages/technologies exist in source chunks or JD
        if isinstance(output, dict) and "rewrites" in output and isinstance(output["rewrites"], list):
            valid_ids = retrieved_ids or set()
            jd_keys_norm = [normalize_for_grounding(k) for k in (jd_keywords or [])]

            for idx, rewrite in enumerate(output["rewrites"]):
                if isinstance(rewrite, dict):
                    chunk_id = str(rewrite.get("source_chunk_id", ""))
                    if valid_ids and chunk_id not in valid_ids:
                        violations.append(
                            Violation(
                                kind="grounding",
                                detail=f"Rewrite #{idx} references ungrounded chunk_id: '{chunk_id}'",
                            )
                        )

                    rewritten_bullet = rewrite.get("rewritten", "")
                    norm_bullet = normalize_for_grounding(rewritten_bullet)

                    # Extract numbers, percentages, and metrics
                    metrics = re.findall(r"\b\d+(?:\.\d+)?%?\b", norm_bullet)
                    source_text = (source_chunks or {}).get(chunk_id, "")
                    haystack = normalize_for_grounding(source_text) + " " + " ".join(jd_keys_norm)

                    for m in metrics:
                        # Must be present in source chunk or JD keywords
                        if m not in haystack:
                            violations.append(
                                Violation(
                                    kind="grounding",
                                    detail=f"Rewrite #{idx} contains ungrounded metric: '{m}'",
                                )
                            )

        # 4. Scope check: no user_id leakage from another user
        # Scans for UUIDs that do not match the current user_id or run_id
        uuid_matches = re.findall(
            r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
            out_str,
            re.IGNORECASE,
        )
        for u in uuid_matches:
            if u.lower() not in (str(self.ctx.user_id).lower(), str(self.ctx.run_id).lower(), str(self.ctx.request_id).lower()):
                # Allow if it's in retrieved_ids
                if not (retrieved_ids and u in retrieved_ids):
                    violations.append(Violation(kind="scope", detail=f"Unrecognized UUID '{u}' detected in output."))

        # 5. Leak/PII check: n-gram overlap with system prompt text above threshold
        if system_prompt:
            # Check 6-gram overlaps
            sys_words = system_prompt.lower().split()
            out_words = out_str.lower().split()
            if len(sys_words) >= 6 and len(out_words) >= 6:
                sys_ngrams = {" ".join(sys_words[i : i + 6]) for i in range(len(sys_words) - 5)}
                out_ngrams = {" ".join(out_words[i : i + 6]) for i in range(len(out_words) - 5)}
                overlap = sys_ngrams.intersection(out_ngrams)
                if len(overlap) > 3:
                    violations.append(
                        Violation(
                            kind="leak",
                            detail=f"System prompt phrasing leaked (overlap on {len(overlap)} n-grams).",
                        )
                    )

        # 6. Claims check for tracker: "I logged X" requires matching staged action
        logged_claims = re.findall(r"\b(i logged|added application|saved application)\b", out_str, re.I)
        if logged_claims and not self.ctx.staged:
            violations.append(
                Violation(
                    kind="claims",
                    detail="Model claimed to log an application without staging any tool action.",
                )
            )

        passed = len(violations) == 0
        return GateResult(passed=passed, violations=violations, sanitized_output=out_str if passed else None)
