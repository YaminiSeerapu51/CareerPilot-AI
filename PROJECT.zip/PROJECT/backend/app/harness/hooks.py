"""
harness/hooks.py
────────────────
HookBus: the central event bus that every cross-cutting concern attaches to.
AgentHooks: the read-only handle agents receive; they can only observe, never block.

Design rules
  - Hooks run in Phase order (SECURITY → POLICY → NORMAL → OBSERVE).
  - mandatory=True hooks cannot be unregistered; an attempt raises HarnessSealedError.
  - seal() is called once at the end of build_harness().  After sealing, no new
    mandatory hooks may be registered.
  - emit() short-circuits on the first Block decision.
"""
from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import IntEnum, StrEnum
from typing import Any


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

class HookEvent(StrEnum):
    RUN_START    = "run_start"
    PRE_LLM      = "pre_llm"
    POST_LLM     = "post_llm"
    PRE_TOOL     = "pre_tool"
    POST_TOOL    = "post_tool"
    PRE_FINAL    = "pre_final"
    MEMORY_WRITE = "memory_write"
    RUN_END      = "run_end"


# ---------------------------------------------------------------------------
# Decision returned by each hook function
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Allow:
    """Proceed unchanged."""


@dataclass(frozen=True)
class Block:
    reason: str
    violation_kind: str = "hook_block"


@dataclass(frozen=True)
class Modify:
    """Replace the payload with a new value."""
    payload: Any


HookDecision = Allow | Block | Modify


# ---------------------------------------------------------------------------
# Hook context passed to every hook function
# ---------------------------------------------------------------------------

@dataclass
class HookCtx:
    event:   HookEvent
    payload: Any                     # mutable; hooks may read it
    meta:    dict[str, Any] = field(default_factory=dict)


HookFn       = Callable[[HookCtx], Awaitable[HookDecision]]
ObserverFn   = Callable[[HookCtx], Awaitable[None]]


# ---------------------------------------------------------------------------
# Phase — hooks within an event run in phase order
# ---------------------------------------------------------------------------

class Phase(IntEnum):
    SECURITY = 0
    POLICY   = 1
    NORMAL   = 2
    OBSERVE  = 3


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class HarnessSealedError(RuntimeError):
    """Raised when a mandatory hook registration is attempted after seal()."""


# ---------------------------------------------------------------------------
# HookBus
# ---------------------------------------------------------------------------

@dataclass
class _Entry:
    fn:        HookFn
    phase:     Phase
    mandatory: bool


class HookBus:
    """
    Central event bus.  build_harness() registers mandatory hooks, calls seal(),
    then hands agents an AgentHooks handle.
    """

    def __init__(self) -> None:
        self._registry: dict[HookEvent, list[_Entry]] = {e: [] for e in HookEvent}
        self._sealed = False

    def seal(self) -> None:
        """Freeze mandatory hook set.  Called once by build_harness()."""
        self._sealed = True

    def register(
        self,
        event: HookEvent,
        fn: HookFn,
        *,
        mandatory: bool = False,
        phase: Phase = Phase.NORMAL,
    ) -> None:
        if mandatory and self._sealed:
            raise HarnessSealedError(
                f"Cannot register mandatory hook '{fn.__name__}' after seal()."
            )
        entries = self._registry[event]
        entries.append(_Entry(fn=fn, phase=phase, mandatory=mandatory))
        entries.sort(key=lambda e: e.phase)

    def unregister(self, event: HookEvent, fn: HookFn) -> None:
        entries = self._registry[event]
        for entry in entries:
            if entry.fn is fn and entry.mandatory:
                raise HarnessSealedError(
                    f"Cannot unregister mandatory hook '{fn.__name__}'."
                )
        self._registry[event] = [e for e in entries if e.fn is not fn]

    async def emit(self, event: HookEvent, ctx: HookCtx, *, timeout_s: float = 5.0) -> HookDecision:
        """
        Run all registered hooks for *event* in phase order.
        Returns the first Block encountered, or the last Modify/Allow.
        Fail closed (HAR-30): If a mandatory hook raises or times out,
        it treats it as Block and the run stops.
        """
        decision: HookDecision = Allow()
        for entry in self._registry[event]:
            try:
                result = await asyncio.wait_for(entry.fn(ctx), timeout=timeout_s)
            except asyncio.TimeoutError:
                if entry.mandatory:
                    return Block(
                        reason=f"Mandatory hook '{entry.fn.__name__}' timed out after {timeout_s}s",
                        violation_kind="hook_timeout",
                    )
                continue
            except Exception as exc:
                if entry.mandatory:
                    return Block(
                        reason=f"Mandatory hook '{entry.fn.__name__}' failed: {exc}",
                        violation_kind="hook_exception",
                    )
                continue

            if isinstance(result, Block):
                return result          # short-circuit
            if isinstance(result, Modify):
                ctx.payload = result.payload
                decision = result
            # Allow → continue
        return decision


# ---------------------------------------------------------------------------
# AgentHooks — agents only get this; they cannot Block or Modify
# ---------------------------------------------------------------------------

class AgentHooks:
    """
    Read-only hook handle given to agents.
    Agents may observe events but cannot block or modify the payload.
    """

    def __init__(self, bus: HookBus) -> None:
        self._bus = bus

    def observe(self, event: HookEvent, fn: ObserverFn) -> None:
        async def _wrap(ctx: HookCtx) -> HookDecision:
            await fn(ctx)
            return Allow()

        self._bus.register(event, _wrap, mandatory=False, phase=Phase.OBSERVE)
