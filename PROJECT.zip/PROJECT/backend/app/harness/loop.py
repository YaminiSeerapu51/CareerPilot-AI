"""
harness/loop.py
───────────────
AgentLoop: Harness-controlled execution loop enforcing deterministic budgets,
progress detection, tool limits, hook events, and atomic commit coordination.
"""
from __future__ import annotations

import asyncio
import hashlib
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from enum import StrEnum
from typing import Any
from uuid import UUID

from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.harness.context import RunContext
from app.harness.hooks import Allow, Block, HookBus, HookCtx, HookEvent, Modify
from app.harness.memory.writer import CommitCoordinator, CommitReport
from app.harness.tools.executor import ToolCall, ToolExecutor
from app.harness.tracing import SpanKind, get_tracer
from app.llm.client import LLMClient
from app.schemas.chat import ChatEvent, Msg


class StopReason(StrEnum):
    FINAL_ANSWER = "final_answer"
    MAX_STEPS = "max_steps"
    MAX_TOOL_CALLS = "max_tool_calls"
    TIMEOUT = "timeout"
    TOKEN_BUDGET = "token_budget"
    COST_BUDGET = "cost_budget"
    REPEATED_CALL = "repeated_call"
    NO_PROGRESS = "no_progress"
    ERROR_STREAK = "error_streak"
    GUARDRAIL_BLOCK = "guardrail_block"
    PENDING_CONFIRMATION = "pending_confirmation"
    COMMIT_FAILED = "commit_failed"
    USER_CANCEL = "user_cancel"


@dataclass(frozen=True)
class LoopBudget:
    max_steps: int = 6
    max_tool_calls: int = 8
    max_wall_seconds: float = 30.0
    max_total_tokens: int = 20_000
    max_cost_usd: float = 0.10
    max_consecutive_errors: int = 2
    max_identical_calls: int = 2


class LoopResult(BaseModel):
    stop_reason: StopReason
    output: str | None = None
    structured: dict[str, Any] | None = None
    steps: int = 0
    tool_calls: int = 0
    tokens: int = 0
    cost_usd: float = 0.0
    committed: bool = False
    error: str | None = None


class AgentLoop:
    """Harness-owned execution loop."""

    def __init__(
        self,
        llm: LLMClient,
        executor: ToolExecutor,
        hooks: HookBus,
        budget: LoopBudget | None = None,
        db: AsyncSession | None = None,
    ) -> None:
        self.llm = llm
        self.executor = executor
        self.hooks = hooks
        self.budget = budget or LoopBudget()
        self.db = db
        self.tracer = get_tracer()

    async def run(
        self,
        ctx: RunContext,
        *,
        system_prompt: str,
        messages: list[Msg],
        allow_list: list[str],
        model_cls: type[BaseModel] | None = None,
    ) -> LoopResult:
        start_time = time.perf_counter()
        steps = 0
        tool_calls_count = 0
        consecutive_errors = 0
        call_hashes: dict[str, int] = {}
        last_state_hash = ""
        same_state_count = 0
        output_text: str | None = None
        structured_data: dict[str, Any] | None = None

        # 1. RUN_START Hook
        decision = await self.hooks.emit(
            HookEvent.RUN_START,
            HookCtx(event=HookEvent.RUN_START, payload={"messages": messages}, meta={"run_ctx": ctx, "budget": self.budget}),
        )
        if isinstance(decision, Block):
            return LoopResult(stop_reason=StopReason.GUARDRAIL_BLOCK, error=decision.reason)

        working_messages = list(messages)
        stop_reason = StopReason.MAX_STEPS

        while steps < self.budget.max_steps:
            steps += 1

            # Check Wall Time
            elapsed = time.perf_counter() - start_time
            if elapsed >= self.budget.max_wall_seconds:
                stop_reason = StopReason.TIMEOUT
                break

            # Check Tokens & Cost
            if ctx.token_count >= self.budget.max_total_tokens:
                stop_reason = StopReason.TOKEN_BUDGET
                break
            if ctx.cost_usd >= self.budget.max_cost_usd:
                stop_reason = StopReason.COST_BUDGET
                break

            # 80% budget nudge
            system_to_use = system_prompt
            if steps >= int(self.budget.max_steps * 0.8) or elapsed >= (self.budget.max_wall_seconds * 0.8):
                system_to_use += "\n\n[SYSTEM NOTE: Approaching step/time budget. Please wrap up and provide your final response now.]"

            # 2. PRE_LLM Hook
            prompt_payload = {"system": system_to_use, "messages": [m.model_dump() for m in working_messages]}
            decision = await self.hooks.emit(
                HookEvent.PRE_LLM,
                HookCtx(
                    event=HookEvent.PRE_LLM,
                    payload=prompt_payload,
                    meta={"run_ctx": ctx, "budget": self.budget},
                ),
            )
            if isinstance(decision, Block):
                stop_reason = StopReason.GUARDRAIL_BLOCK
                break

            # LLM Call
            async with self.tracer.span(SpanKind.LLM, f"step_{steps}") as llm_span:
                try:
                    response_text = await self.llm.complete(system_to_use, working_messages)
                    llm_span.record_llm("claude", tokens_in=len(str(working_messages)) // 4, tokens_out=len(response_text) // 4)
                except Exception as exc:
                    llm_span.record_error(exc)
                    stop_reason = StopReason.GUARDRAIL_BLOCK
                    break

            # 3. POST_LLM Hook
            decision = await self.hooks.emit(
                HookEvent.POST_LLM,
                HookCtx(
                    event=HookEvent.POST_LLM,
                    payload=response_text,
                    meta={"run_ctx": ctx, "usage": {"input_tokens": 100, "output_tokens": 50}},
                ),
            )
            if isinstance(decision, Block):
                stop_reason = StopReason.GUARDRAIL_BLOCK
                break

            # Check for structured JSON or final answer
            from app.llm.guardrails import _extract_json
            parsed_json = None
            try:
                candidate = _extract_json(response_text)
                import json
                parsed_json = json.loads(candidate)
            except Exception:
                parsed_json = None

            # Tool call detection: either structured tool call or completion
            if parsed_json and isinstance(parsed_json, dict) and "tool" in parsed_json:
                tool_calls_count += 1
                if tool_calls_count > self.budget.max_tool_calls:
                    stop_reason = StopReason.MAX_TOOL_CALLS
                    break

                t_name = parsed_json.get("tool")
                t_args = parsed_json.get("args", {})
                call_sig = hashlib.sha256(f"{t_name}:{sorted(t_args.items())}".encode()).hexdigest()[:16]
                call_hashes[call_sig] = call_hashes.get(call_sig, 0) + 1

                # Repeat detector
                if call_hashes[call_sig] > self.budget.max_identical_calls:
                    stop_reason = StopReason.REPEATED_CALL
                    break

                # 4. PRE_TOOL Hook
                t_payload = {"name": t_name, "args": t_args}
                decision = await self.hooks.emit(
                    HookEvent.PRE_TOOL,
                    HookCtx(
                        event=HookEvent.PRE_TOOL,
                        payload=t_payload,
                        meta={"run_ctx": ctx, "allow_list": allow_list, "budget": self.budget},
                    ),
                )
                if isinstance(decision, Block):
                    stop_reason = StopReason.GUARDRAIL_BLOCK
                    break

                # Execute Tool
                tool_call = ToolCall(name=t_name, args=t_args)
                tool_res = await self.executor.execute(tool_call, ctx, allow_list=allow_list)

                # Pending confirmation check
                if tool_res.error and tool_res.error.detail == "pending_confirmation":
                    stop_reason = StopReason.PENDING_CONFIRMATION
                    structured_data = tool_res.data
                    break

                # 5. POST_TOOL Hook
                decision = await self.hooks.emit(
                    HookEvent.POST_TOOL,
                    HookCtx(
                        event=HookEvent.POST_TOOL,
                        payload={"ok": tool_res.ok, "error": tool_res.error.detail if tool_res.error else None, "latency_ms": tool_res.latency_ms},
                        meta={"run_ctx": ctx, "tool_name": t_name, "budget": self.budget},
                    ),
                )
                if isinstance(decision, Block):
                    stop_reason = StopReason.ERROR_STREAK if decision.violation_kind == "error_streak" else StopReason.NO_PROGRESS
                    break

                if not tool_res.ok:
                    consecutive_errors += 1
                    if consecutive_errors >= self.budget.max_consecutive_errors:
                        stop_reason = StopReason.ERROR_STREAK
                        break
                    working_messages.append(Msg(role="assistant", content=response_text))
                    working_messages.append(Msg(role="user", content=f"Tool error: {tool_res.error.detail if tool_res.error else 'unknown error'}"))
                else:
                    consecutive_errors = 0
                    working_messages.append(Msg(role="assistant", content=response_text))
                    working_messages.append(Msg(role="user", content=f"Tool result: {tool_res.data}"))

                # Progress state hash
                cur_state_hash = hashlib.sha256(str(tool_res.data).encode()).hexdigest()[:16]
                if cur_state_hash == last_state_hash:
                    same_state_count += 1
                    if same_state_count >= 2:
                        stop_reason = StopReason.NO_PROGRESS
                        break
                else:
                    same_state_count = 0
                    last_state_hash = cur_state_hash

                continue

            # No tool proposed -> Final Answer
            output_text = response_text
            if parsed_json and isinstance(parsed_json, dict):
                structured_data = parsed_json
            stop_reason = StopReason.FINAL_ANSWER
            break

        # 6. PRE_FINAL Hook & Gate Check
        final_payload = structured_data if structured_data else (output_text or "")
        decision = await self.hooks.emit(
            HookEvent.PRE_FINAL,
            HookCtx(
                event=HookEvent.PRE_FINAL,
                payload=final_payload,
                meta={"run_ctx": ctx, "model_cls": model_cls, "system_prompt": system_prompt},
            ),
        )
        if isinstance(decision, Block):
            stop_reason = StopReason.GUARDRAIL_BLOCK

        # 7. Commit staged actions & memory writes if FINAL_ANSWER
        committed = False
        if stop_reason == StopReason.FINAL_ANSWER and self.db:
            try:
                coord = CommitCoordinator(self.db)
                await coord.commit(ctx)
                committed = True
            except Exception as e:
                stop_reason = StopReason.COMMIT_FAILED
                committed = False

        # 8. RUN_END Hook
        await self.hooks.emit(
            HookEvent.RUN_END,
            HookCtx(
                event=HookEvent.RUN_END,
                payload={"stop_reason": stop_reason, "committed": committed},
                meta={"run_ctx": ctx},
            ),
        )

        return LoopResult(
            stop_reason=stop_reason,
            output=output_text,
            structured=structured_data,
            steps=steps,
            tool_calls=tool_calls_count,
            tokens=ctx.token_count,
            cost_usd=ctx.cost_usd,
            committed=committed,
        )

    async def stream(
        self,
        ctx: RunContext,
        *,
        system_prompt: str,
        messages: list[Msg],
        allow_list: list[str],
        model_cls: type[BaseModel] | None = None,
    ) -> AsyncIterator[ChatEvent]:
        # Yield status events
        yield ChatEvent(type="tool", data={"status": "processing", "agent": ctx.agent, "run_id": str(ctx.run_id)})

        res = await self.run(
            ctx,
            system_prompt=system_prompt,
            messages=messages,
            allow_list=allow_list,
            model_cls=model_cls,
        )

        if res.stop_reason == StopReason.GUARDRAIL_BLOCK:
            yield ChatEvent(type="error", data="Output blocked by safety guardrails.")
        elif res.stop_reason == StopReason.PENDING_CONFIRMATION:
            yield ChatEvent(type="tool", data={"status": "pending_confirmation", "details": res.structured})
        elif res.structured:
            yield ChatEvent(type="result", data=res.structured)
        elif res.output:
            yield ChatEvent(type="token", data=res.output)

        yield ChatEvent(type="done", data={"stop_reason": res.stop_reason, "tokens": res.tokens, "cost_usd": res.cost_usd})
