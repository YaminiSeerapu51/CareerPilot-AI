"""
harness/retrieval/semantic.py
─────────────────────────────
Vector semantic search using Postgres pgvector.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Resume, ResumeChunk
from app.harness.retrieval.router import EmptyRetrieval, RetrievedChunk, SearchFilters
from app.harness.tracing import SpanKind, get_tracer


async def semantic_search(
    db: AsyncSession,
    query: str,
    k: int = 5,
    *,
    filters: SearchFilters,
    encoder: Callable[[str], list[float]] | None = None,
) -> list[RetrievedChunk] | EmptyRetrieval:
    tracer = get_tracer()

    async with tracer.span(SpanKind.RETRIEVAL, "semantic_search", query=query[:100], k=k) as span:
        # Generate query embedding
        if encoder is None:
            from app.tools.resume_tools import embed_chunks
            embeddings = embed_chunks([query])
            q_emb = embeddings[0]
        else:
            q_emb = encoder(query)

        # Distance calculation via pgvector cosine distance
        distance_col = ResumeChunk.embedding.cosine_distance(q_emb).label("distance")

        stmt = (
            select(ResumeChunk.id, ResumeChunk.chunk_text, distance_col)
            .join(Resume, ResumeChunk.resume_id == Resume.id)
            .where(Resume.user_id == filters.user_id)
        )

        if filters.resume_id:
            stmt = stmt.where(Resume.id == filters.resume_id)

        stmt = stmt.order_by(distance_col.asc()).limit(k)
        res = await db.execute(stmt)
        rows = res.all()

        if not rows:
            span.set(hits=0)
            return EmptyRetrieval(reason="No resume chunks found for user.")

        chunks: list[RetrievedChunk] = []
        for row in rows:
            chunk_id, text, dist = row
            # Cosine similarity score = 1.0 - distance
            score = round(max(0.0, 1.0 - float(dist)), 4)
            chunks.append(
                RetrievedChunk(
                    id=chunk_id,
                    text=text,
                    score=score,
                    source="resume",
                    method="vector",
                )
            )

        if not chunks or chunks[0].score < filters.min_score:
            span.set(top_score=chunks[0].score if chunks else 0.0, empty=True)
            return EmptyRetrieval(
                reason=f"Top vector similarity score ({chunks[0].score if chunks else 0.0}) fell below threshold {filters.min_score}"
            )

        span.set(hits=len(chunks), top_score=chunks[0].score)
        return chunks
