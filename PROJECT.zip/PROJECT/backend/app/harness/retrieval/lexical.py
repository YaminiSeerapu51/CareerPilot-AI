"""
harness/retrieval/lexical.py
───────────────────────────
Postgres full-text lexical search using tsvector and ts_rank.
"""
from __future__ import annotations

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Resume, ResumeChunk
from app.harness.retrieval.router import EmptyRetrieval, RetrievedChunk, SearchFilters
from app.harness.tracing import SpanKind, get_tracer


async def lexical_search(
    db: AsyncSession,
    query: str,
    k: int = 5,
    *,
    filters: SearchFilters,
) -> list[RetrievedChunk] | EmptyRetrieval:
    tracer = get_tracer()

    async with tracer.span(SpanKind.RETRIEVAL, "lexical_search", query=query[:100], k=k) as span:
        # Match using to_tsvector and plainto_tsquery
        ts_query = func.plainto_tsquery("english", query)
        rank_col = func.ts_rank(func.to_tsvector("english", ResumeChunk.chunk_text), ts_query).label("rank")

        stmt = (
            select(ResumeChunk.id, ResumeChunk.chunk_text, rank_col)
            .join(Resume, ResumeChunk.resume_id == Resume.id)
            .where(
                Resume.user_id == filters.user_id,
                func.to_tsvector("english", ResumeChunk.chunk_text).op("@@")(ts_query),
            )
        )

        if filters.resume_id:
            stmt = stmt.where(Resume.id == filters.resume_id)

        stmt = stmt.order_by(rank_col.desc()).limit(k)
        res = await db.execute(stmt)
        rows = res.all()

        if not rows:
            span.set(hits=0)
            return EmptyRetrieval(reason=f"No lexical keyword matches found for query: '{query[:50]}'")

        chunks: list[RetrievedChunk] = []
        for row in rows:
            chunk_id, chunk_text, rank_val = row
            chunks.append(
                RetrievedChunk(
                    id=chunk_id,
                    text=chunk_text,
                    score=round(float(rank_val), 4),
                    source="resume",
                    method="lexical",
                )
            )

        span.set(hits=len(chunks), top_score=chunks[0].score)
        return chunks
