"""
harness/retrieval/hybrid.py
───────────────────────────
Hybrid search combining vector semantic and full-text lexical search via Reciprocal Rank Fusion (RRF).
"""
from __future__ import annotations

from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.harness.retrieval.lexical import lexical_search
from app.harness.retrieval.router import EmptyRetrieval, RetrievedChunk, SearchFilters
from app.harness.retrieval.semantic import semantic_search
from app.harness.tracing import SpanKind, get_tracer

RRF_K = 60  # Standard smoothing constant for Reciprocal Rank Fusion


async def hybrid_search(
    db: AsyncSession,
    query: str,
    k: int = 5,
    *,
    filters: SearchFilters,
) -> list[RetrievedChunk] | EmptyRetrieval:
    tracer = get_tracer()

    async with tracer.span(SpanKind.RETRIEVAL, "hybrid_search", query=query[:100], k=k) as span:
        # Run both searches in parallel
        sem_res, lex_res = await (
            semantic_search(db, query, k=k * 2, filters=filters),
            lexical_search(db, query, k=k * 2, filters=filters),
        )

        sem_chunks = sem_res if isinstance(sem_res, list) else []
        lex_chunks = lex_res if isinstance(lex_res, list) else []

        if not sem_chunks and not lex_chunks:
            span.set(hits=0)
            return EmptyRetrieval(reason="Neither vector nor lexical search found relevant matches.")

        # Compute RRF scores
        rrf_scores: dict[UUID, float] = {}
        chunk_map: dict[UUID, RetrievedChunk] = {}

        for rank, chunk in enumerate(sem_chunks, start=1):
            rrf_scores[chunk.id] = rrf_scores.get(chunk.id, 0.0) + (1.0 / (RRF_K + rank))
            chunk_map[chunk.id] = chunk

        for rank, chunk in enumerate(lex_chunks, start=1):
            rrf_scores[chunk.id] = rrf_scores.get(chunk.id, 0.0) + (1.0 / (RRF_K + rank))
            chunk_map[chunk.id] = chunk

        # Sort descending by fused score
        sorted_ids = sorted(rrf_scores.keys(), key=lambda cid: rrf_scores[cid], reverse=True)[:k]

        fused_results: list[RetrievedChunk] = []
        for cid in sorted_ids:
            base_chunk = chunk_map[cid]
            fused_score = round(rrf_scores[cid], 5)
            fused_results.append(
                RetrievedChunk(
                    id=cid,
                    text=base_chunk.text,
                    score=fused_score,
                    source=base_chunk.source,
                    method="fusion",
                )
            )

        span.set(hits=len(fused_results), top_score=fused_results[0].score if fused_results else 0.0)
        return fused_results
