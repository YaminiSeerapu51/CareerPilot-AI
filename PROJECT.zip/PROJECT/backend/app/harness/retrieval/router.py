"""
harness/retrieval/router.py
───────────────────────────
Query routing between SQL, Semantic, and Hybrid retrieval modes.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal
from uuid import UUID

from pydantic import BaseModel


class Route(StrEnum):
    SQL = "sql"
    SEMANTIC = "semantic"
    HYBRID = "hybrid"


class SearchFilters(BaseModel):
    user_id: UUID
    resume_id: UUID | None = None
    sources: list[str] = ["resume", "fact", "jd"]
    min_score: float = 0.25


@dataclass(frozen=True)
class RetrievedChunk:
    id: UUID
    text: str
    score: float
    source: Literal["resume", "fact", "episode", "jd"]
    method: Literal["vector", "lexical", "fusion"]


@dataclass(frozen=True)
class EmptyRetrieval:
    reason: str


_SQL_KEYWORDS = re.compile(
    r"\b(application|applied|status|interview|offer|rejected|company|date|since|before|after|list|count|show)\b",
    re.I,
)
_SEMANTIC_KEYWORDS = re.compile(
    r"\b(experience|worked on|describe|tell me|skills|projects|built|designed|background|responsibilities)\b",
    re.I,
)


def route_query(query: str, intent: str | None = None, *, has_filters: bool = False) -> Route:
    """
    Deterministic rule-based query router.
    - Structured nouns & filters -> SQL
    - Open-ended / experience -> SEMANTIC
    - Mixed -> HYBRID
    """
    if intent == "tracker":
        return Route.SQL

    has_sql = bool(_SQL_KEYWORDS.search(query))
    has_sem = bool(_SEMANTIC_KEYWORDS.search(query))

    if has_filters and has_sql:
        return Route.SQL
    if has_sql and has_sem:
        return Route.HYBRID
    if has_sem or len(query.split()) > 8:
        return Route.SEMANTIC
    if has_sql:
        return Route.SQL

    return Route.SEMANTIC
