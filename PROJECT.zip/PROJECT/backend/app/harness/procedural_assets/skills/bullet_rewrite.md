---
id: bullet_rewrite
version: "1.0"
kind: skill
---
# Bullet Rewrite Playbook

When rewriting a candidate's resume bullet point for job-fit alignment:
1. **Formula**: [Strong Action Verb] + [What Was Built / Technical Context] + [Tools / Tech Used] + [Quantified Result / Impact].
2. **Strict Grounding**:
   - Only include numbers, percentages, and metrics that exist verbatim or algebraically in the source resume chunk.
   - Never invent throughput figures, cost savings, or latency improvements.
   - If no metric was provided in the source chunk, do not fabricate one; emphasize architectural complexity and ownership instead.
3. **Keyword Placement**: Integrate target keywords naturally into the technical context. Avoid "keyword stuffing".
4. **Length**: Keep bullets punchy and between 15 and 30 words.
