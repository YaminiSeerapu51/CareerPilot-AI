---
id: interview_probe
version: "1.0"
kind: skill
---
# Interview Probing Playbook

When probing a candidate's answer during a mock interview turn:
1. **Target the Weakest Link**:
   - If **Result** scored < 3: Ask for measurable business impact, system metrics, latency percentiles, or how success was tracked.
   - If **Action** scored < 3: Ask specifically what the candidate owned versus the rest of the team, what alternatives were evaluated, or what trade-offs were made.
   - If **Situation / Task** scored < 3: Ask about system constraints, team size, scale, or failure consequences.
2. **One Question Only**: Never ask compound questions. Ask a single, direct, probing inquiry.
3. **Tone**: Direct, professional, and encouraging.
