"""
harness/agent_spec.py
─────────────────────
AgentSpec: Standardized declarative specification for each sub-agent.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel

from app.harness.loop import LoopBudget


@dataclass(frozen=True)
class AgentSpec:
    name: str
    prompt_id: str
    allow_list: list[str] = field(default_factory=list)
    skill_id: str | None = None
    stream_policy: Literal["buffered", "guarded_stream"] = "buffered"
    budget: LoopBudget = field(default_factory=LoopBudget)
    model_cls: type[BaseModel] | None = None


# Pre-configured specifications for CareerPilot sub-agents
TRACKER_AGENT_SPEC = AgentSpec(
    name="tracker",
    prompt_id="system_tracker",
    allow_list=["save_application", "get_applications", "update_application_status"],
    stream_policy="buffered",
    budget=LoopBudget(max_steps=4, max_tool_calls=4, max_wall_seconds=15.0),
)

RESUME_AGENT_SPEC = AgentSpec(
    name="resume",
    prompt_id="system_resume",
    allow_list=["parse_resume", "embed_chunks"],
    stream_policy="buffered",
    budget=LoopBudget(max_steps=4, max_tool_calls=3, max_wall_seconds=20.0),
)

JOBFIT_AGENT_SPEC = AgentSpec(
    name="jobfit",
    prompt_id="system_jobfit",
    skill_id="bullet_rewrite",
    allow_list=["semantic_search", "lexical_search", "extract_keywords", "compute_ats_score"],
    stream_policy="buffered",
    budget=LoopBudget(max_steps=5, max_tool_calls=5, max_wall_seconds=25.0),
)

INTERVIEW_AGENT_SPEC = AgentSpec(
    name="interview",
    prompt_id="system_interview",
    skill_id="interview_probe",
    allow_list=["similar_past_questions", "score_answer"],
    stream_policy="guarded_stream",
    budget=LoopBudget(max_steps=4, max_tool_calls=3, max_wall_seconds=20.0),
)
