from functools import lru_cache
from typing import Literal, Self

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=(".env", "../.env"), extra="ignore")

    env: Literal["dev", "demo", "prod"] = "dev"
    database_url: str = "postgresql+asyncpg://cp:cp@localhost:5432/careerpilot"
    anthropic_api_key: str = ""
    claude_model_dev: str = "claude-haiku-4-5"
    claude_model_demo: str = "claude-sonnet-5"
    llm_mode: Literal["dev", "demo", "fake"] = "dev"
    jwt_secret: str = "dev-only-change-me"
    jwt_ttl_seconds: int = 3600
    seed_user_email: str = "demo@careerpilot.local"
    seed_user_password: str = "changeme"
    resume_bucket: str = ""
    aws_region: str = "us-east-1"
    max_upload_bytes: int = Field(default=5 * 1024 * 1024)

    # Harness / Tracing / Budgets
    tracing_backend: Literal["postgres", "langfuse", "both"] = "postgres"
    trace_payloads: bool = False
    langfuse_host: str = ""
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    retrieval_min_score: float = 0.25
    run_max_cost_usd: float = 0.10
    judge_model: str = ""
    judge_min_agreement: float = 0.75
    price_table_path: str = "config/prices.yaml"
    db_statement_timeout_ms: int = 5000
    db_lock_timeout_ms: int = 2000
    db_idle_in_tx_timeout_ms: int = 10000
    pending_action_ttl_min: int = 30

    @model_validator(mode="after")
    def load_prod_secrets(self) -> Self:
        if self.env != "prod":
            return self
        from app.secrets_loader import hydrate_from_secrets_manager

        return hydrate_from_secrets_manager(self)

    def claude_model(self) -> str:
        if self.llm_mode == "demo":
            return self.claude_model_demo
        return self.claude_model_dev


@lru_cache
def get_settings() -> Settings:
    return Settings()
