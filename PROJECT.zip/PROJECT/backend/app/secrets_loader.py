from __future__ import annotations

from typing import Any

import boto3

from app.config import Settings


def hydrate_from_secrets_manager(settings: Settings) -> Settings:
    client = boto3.client("secretsmanager", region_name=settings.aws_region)
    mapping = {
        "anthropic_api_key": "careerpilot/anthropic_api_key",
        "jwt_secret": "careerpilot/jwt_secret",
        "seed_user_password": "careerpilot/seed_password",
        "database_url": "careerpilot/database_url",
    }
    updates: dict[str, Any] = {}
    for field, secret_id in mapping.items():
        resp = client.get_secret_value(SecretId=secret_id)
        updates[field] = resp["SecretString"]
    return settings.model_copy(update=updates)
