from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )


class AgentLogPayload(BaseModel):
    agent: str
    event: str
    input_summary: str
    output_summary: str
    latency_ms: int
    error: str | None = None


def summarize(value: Any, limit: int = 400) -> str:
    text = str(value)
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."
