from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.agents import interview_agent, jobfit_agent, resume_agent, tracker_agent
from app.agents.state import GraphState, Intent
from app.llm.client import LLMClient, LLMSchemaError
from app.llm.guardrails import structured
from app.llm.prompts import CHITCHAT_SYSTEM, CLASSIFY_SYSTEM
from app.schemas.chat import Attachment, ChatEvent, IntentModel, Msg


async def classify_intent(llm: LLMClient, state: GraphState) -> Intent:
    try:
        parsed = await structured(
            llm,
            IntentModel,
            CLASSIFY_SYSTEM,
            state["messages"][-3:] or [Msg(role="user", content="")],
        )
        return parsed.intent
    except (LLMSchemaError, Exception):
        return "chitchat"


def _has_jd(state: GraphState) -> bool:
    text = state["messages"][-1].content if state["messages"] else ""
    if state["attachments"]:
        return "job" in text.lower() or "jd" in text.lower() or len(text) > 400
    return False


async def _chitchat(state: GraphState, llm: LLMClient, db: AsyncSession) -> GraphState:
    import time

    started = time.perf_counter()
    tokens: list[str] = []
    async for piece in llm.stream(CHITCHAT_SYSTEM, state["messages"]):
        tokens.append(piece)
    state["tokens"] = tokens
    state["result"] = {"type": "chitchat", "text": "".join(tokens)}
    from app.db.logs import write_agent_log

    await write_agent_log(
        db,
        user_id=state["user_id"],
        agent="chitchat",
        event="respond",
        input_summary=state["messages"][-1].content if state["messages"] else "",
        output_summary="".join(tokens),
        latency_ms=int((time.perf_counter() - started) * 1000),
    )
    return state


def build_graph(llm: LLMClient, db_factory: Callable[[], Any]) -> Any:
    """LangGraph compiled graph: classify -> agent -> respond."""
    from langgraph.graph import END, StateGraph

    async def classify_node(state: GraphState) -> GraphState:
        db = db_factory()
        try:
            intent = await classify_intent(llm, state)
            state["intent"] = intent
            return state
        finally:
            if hasattr(db, "close"):
                closer = db.close
                if callable(closer):
                    maybe = closer()
                    if hasattr(maybe, "__await__"):
                        await maybe  # type: ignore[misc]

    async def resume_node(state: GraphState) -> GraphState:
        async with db_factory() as db:
            return await resume_agent.run(state, llm, db)

    async def jobfit_node(state: GraphState) -> GraphState:
        async with db_factory() as db:
            return await jobfit_agent.run(state, llm, db)

    async def interview_node(state: GraphState) -> GraphState:
        async with db_factory() as db:
            return await interview_agent.run(state, llm, db)

    async def tracker_node(state: GraphState) -> GraphState:
        async with db_factory() as db:
            return await tracker_agent.run(state, llm, db)

    async def chitchat_node(state: GraphState) -> GraphState:
        async with db_factory() as db:
            return await _chitchat(state, llm, db)

    def route(state: GraphState) -> str:
        return state.get("intent") or "chitchat"

    def after_resume(state: GraphState) -> str:
        if _has_jd(state):
            return "jobfit"
        return "end"

    graph = StateGraph(dict)
    graph.add_node("classify", classify_node)
    graph.add_node("resume", resume_node)
    graph.add_node("jobfit", jobfit_node)
    graph.add_node("interview", interview_node)
    graph.add_node("tracker", tracker_node)
    graph.add_node("chitchat", chitchat_node)
    graph.set_entry_point("classify")
    graph.add_conditional_edges(
        "classify",
        route,
        {
            "resume": "resume",
            "jobfit": "jobfit",
            "interview": "interview",
            "tracker": "tracker",
            "chitchat": "chitchat",
        },
    )
    graph.add_conditional_edges("resume", after_resume, {"jobfit": "jobfit", "end": END})
    graph.add_edge("jobfit", END)
    graph.add_edge("interview", END)
    graph.add_edge("tracker", END)
    graph.add_edge("chitchat", END)
    return graph.compile()


async def run_chat(
    user_id: UUID,
    message: str,
    attachments: list[Attachment],
    *,
    llm: LLMClient | None = None,
    db: AsyncSession | None = None,
    interview_session_id: UUID | None = None,
) -> AsyncIterator[ChatEvent]:
    from app.db.session import SessionLocal
    from app.llm.client import get_llm_client

    client = llm or get_llm_client()
    state: GraphState = {
        "user_id": user_id,
        "messages": [Msg(role="user", content=message)],
        "intent": None,
        "attachments": attachments,
        "active_resume_id": None,
        "active_jd_id": None,
        "interview_session_id": interview_session_id,
        "result": None,
        "chain": [],
        "tokens": [],
        "error": None,
    }
    own_session = db is None
    session = db or SessionLocal()
    try:
        intent = await classify_intent(client, state)
        state["intent"] = intent
        yield ChatEvent(type="tool", data={"intent": intent})
        runners = {
            "resume": resume_agent.run,
            "jobfit": jobfit_agent.run,
            "interview": interview_agent.run,
            "tracker": tracker_agent.run,
            "chitchat": _chitchat,
        }
        state = await runners[intent](state, client, session)
        if intent == "resume" and _has_jd(state):
            state = await jobfit_agent.run(state, client, session)
        if state.get("error"):
            yield ChatEvent(type="error", data=state["error"])
        for token in state.get("tokens") or []:
            yield ChatEvent(type="token", data=token)
        if not state.get("tokens") and state.get("result"):
            summary = _result_summary(state["result"])
            for i in range(0, len(summary), 10):
                yield ChatEvent(type="token", data=summary[i : i + 10])
        if state.get("result"):
            yield ChatEvent(type="result", data=state["result"])
        await session.commit()
        yield ChatEvent(type="done", data={"intent": intent})
    except Exception as exc:  # noqa: BLE001
        await session.rollback()
        yield ChatEvent(type="error", data=str(exc))
        yield ChatEvent(type="done", data={})
    finally:
        if own_session:
            await session.close()


def _result_summary(result: dict[str, Any]) -> str:
    kind = result.get("type")
    if kind == "jobfit":
        report = result.get("report") or {}
        return f"ATS score {report.get('ats_score', '?')} with missing keywords {report.get('missing_keywords', [])}."
    if kind == "resume":
        skills = (result.get("resume") or {}).get("skills") or []
        return f"Parsed resume with skills: {', '.join(skills)}."
    if kind == "interview":
        return str(result.get("question") or result.get("follow_up_question") or "Interview updated.")
    if kind == "tracker":
        return "Application tracker updated."
    return str(result)
