from __future__ import annotations

import time
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.state import GraphState
from app.db.logs import write_agent_log
from app.db.models import JobDescription, Resume
from app.embeddings import cosine_similarity, embed_texts
from app.llm.client import LLMClient
from app.llm.guardrails import detect_injection, log_canary, structured, wrap_untrusted
from app.llm.prompts import JOBFIT_REWRITE_SYSTEM
from app.schemas.chat import Msg
from app.schemas.jobfit import BulletRewrite, JobFitReport
from app.schemas.resume import StructuredResume
from app.tools.jobfit_tools import compute_ats_score, extract_jd_keywords, matched_and_missing
from app.tools.retrieval import active_resume, vector_search
from app.tools.resume_tools import Chunk


async def run(state: GraphState, llm: LLMClient, db: AsyncSession) -> GraphState:
    started = time.perf_counter()
    jd_text = _jd_from_state(state)
    snippets = detect_injection(jd_text)
    if snippets:
        await log_canary(db, state["user_id"], "job_description", snippets)
    wrapped = wrap_untrusted(jd_text)
    keywords = extract_jd_keywords(jd_text)
    resume_row = await active_resume(db, state["user_id"])
    if resume_row is None:
        state["error"] = "Upload an active resume first"
        await write_agent_log(
            db,
            user_id=state["user_id"],
            agent="jobfit",
            event="no_resume",
            input_summary=jd_text[:200],
            output_summary="",
            latency_ms=int((time.perf_counter() - started) * 1000),
            error=state["error"],
        )
        return state
    resume = StructuredResume.model_validate(resume_row.structured_json)
    jd_emb = embed_texts([jd_text])[0]
    resume_emb = embed_texts([str(resume.model_dump())])[0]
    sim = cosine_similarity(jd_emb, resume_emb)
    score = compute_ats_score(resume, keywords, sim)
    matched, missing = matched_and_missing(resume, keywords)
    retrieved: list[Chunk] = []
    queries = missing[:5] or keywords[:3] or ["experience"]
    seen: set[UUID] = set()
    for q in queries:
        for chunk in await vector_search(db, state["user_id"], q, k=3):
            if chunk.id not in seen:
                seen.add(chunk.id)
                retrieved.append(chunk)
    report = await _rewrites(llm, wrapped, resume, matched, missing, score, retrieved)
    jd = JobDescription(user_id=state["user_id"], raw_text=jd_text, extracted_keywords=keywords)
    db.add(jd)
    await db.flush()
    state["active_jd_id"] = jd.id
    state["result"] = {"type": "jobfit", "report": report.model_dump(mode="json"), "jd_id": str(jd.id)}
    await write_agent_log(
        db,
        user_id=state["user_id"],
        agent="jobfit",
        event="analyzed",
        input_summary=keywords,
        output_summary={"ats_score": score, "missing": missing},
        latency_ms=int((time.perf_counter() - started) * 1000),
    )
    return state


def _jd_from_state(state: GraphState) -> str:
    if state["messages"]:
        return state["messages"][-1].content
    return ""


async def _rewrites(
    llm: LLMClient,
    wrapped_jd: str,
    resume: StructuredResume,
    matched: list[str],
    missing: list[str],
    score: float,
    retrieved: list[Chunk],
) -> JobFitReport:
    chunk_payload = [{"id": str(c.id), "text": c.text} for c in retrieved]
    allowed = {c.id for c in retrieved}
    originals = [b for exp in resume.experience for b in exp.bullets] or [
        "Worked on software projects",
        "Collaborated with teammates",
        "Delivered features",
    ]
    user = (
        f"JD:\n{wrapped_jd}\nChunks:{chunk_payload}\n"
        f"Matched:{matched}\nMissing:{missing}\n"
        "Produce a JobFitReport JSON with at least 3 grounded rewrites."
    )
    report: JobFitReport | None = None
    try:
        report = await structured(
            llm,
            JobFitReport,
            JOBFIT_REWRITE_SYSTEM,
            [Msg(role="user", content=user)],
        )
        report = _filter_grounded(report, allowed, score, matched, missing, originals, retrieved)
    except Exception:
        report = None
    if report is None or len(report.rewrites) < 3:
        report = _fallback_report(score, matched, missing, originals, retrieved)
    return report


def _filter_grounded(
    report: JobFitReport,
    allowed: set[UUID],
    score: float,
    matched: list[str],
    missing: list[str],
    originals: list[str],
    retrieved: list[Chunk],
) -> JobFitReport:
    kept = [r for r in report.rewrites if r.source_chunk_id in allowed]
    if len(kept) >= 3:
        return report.model_copy(update={"rewrites": kept, "ats_score": score, "matched_keywords": matched, "missing_keywords": missing})
    return _fallback_report(score, matched, missing, originals, retrieved)


def _fallback_report(
    score: float,
    matched: list[str],
    missing: list[str],
    originals: list[str],
    retrieved: list[Chunk],
) -> JobFitReport:
    rewrites: list[BulletRewrite] = []
    if not retrieved:
        retrieved = [Chunk(id=UUID("00000000-0000-0000-0000-000000000099"), text="Skills from resume")]
    for i in range(3):
        chunk = retrieved[i % len(retrieved)]
        original = originals[i % len(originals)]
        kw = missing[i % len(missing)] if missing else (matched[0] if matched else "impact")
        rewrites.append(
            BulletRewrite(
                original=original,
                rewritten=f"{original.rstrip('.')} with emphasis on {kw}, grounded in retrieved experience.",
                source_chunk_id=chunk.id,
                keywords_addressed=[kw],
            )
        )
    return JobFitReport(
        ats_score=score,
        matched_keywords=matched,
        missing_keywords=missing,
        rewrites=rewrites,
    )
