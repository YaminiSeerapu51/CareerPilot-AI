from __future__ import annotations

import time
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.state import GraphState
from app.db.logs import write_agent_log
from app.db.models import InterviewSession, InterviewTurn
from app.llm.client import LLMClient
from app.tools.interview_tools import score_answer
from app.tools.retrieval import vector_search


async def run(state: GraphState, llm: LLMClient, db: AsyncSession) -> GraphState:
    started = time.perf_counter()
    text = state["messages"][-1].content if state["messages"] else ""
    if state["interview_session_id"] is None and not _is_answer(text):
        session = await start_session(db, state["user_id"], role=_extract_role(text), jd_id=state["active_jd_id"])
        question = await _first_question(db, state["user_id"], session.role)
        db.add(InterviewTurn(session_id=session.id, question=question))
        await db.flush()
        state["interview_session_id"] = session.id
        state["result"] = {
            "type": "interview",
            "mode": "start",
            "session_id": str(session.id),
            "question": question,
        }
        await write_agent_log(
            db,
            user_id=state["user_id"],
            agent="interview",
            event="start",
            input_summary=text,
            output_summary=question,
            latency_ms=int((time.perf_counter() - started) * 1000),
        )
        return state
    session_id = state["interview_session_id"]
    if session_id is None:
        state["error"] = "No interview session"
        return state
    result = await answer_turn(db, llm, state["user_id"], session_id, text)
    state["result"] = {"type": "interview", "mode": "answer", **result}
    await write_agent_log(
        db,
        user_id=state["user_id"],
        agent="interview",
        event="answer",
        input_summary=text,
        output_summary=result.get("feedback"),
        latency_ms=int((time.perf_counter() - started) * 1000),
    )
    return state


def _is_answer(text: str) -> bool:
    return len(text.split()) > 12 and "start" not in text.lower()[:20]


def _extract_role(text: str) -> str:
    for token in ("SWE", "software engineer", "backend", "data scientist"):
        if token.lower() in text.lower():
            return token
    return "Software Engineer"


async def start_session(
    db: AsyncSession, user_id: UUID, role: str | None, jd_id: UUID | None
) -> InterviewSession:
    session = InterviewSession(user_id=user_id, role=role, jd_id=jd_id)
    db.add(session)
    await db.flush()
    return session


async def _first_question(db: AsyncSession, user_id: UUID, role: str | None) -> str:
    chunks = await vector_search(db, user_id, role or "experience", k=3)
    hint = chunks[0].text if chunks else "your recent work"
    return f"Tell me about a challenging project related to {hint}. Use the STAR format."


async def answer_turn(
    db: AsyncSession,
    llm: LLMClient,
    user_id: UUID,
    session_id: UUID,
    answer: str,
) -> dict[str, object]:
    pending = await db.execute(
        select(InterviewTurn)
        .where(InterviewTurn.session_id == session_id, InterviewTurn.answer.is_(None))
        .order_by(InterviewTurn.created_at.desc())
    )
    turn = pending.scalars().first()
    question = turn.question if turn else "Walk me through a recent technical decision."
    chunks = await vector_search(db, user_id, answer[:200] or question, k=5)
    feedback = await score_answer(llm, question, answer, chunks)
    if turn:
        turn.answer = answer
        turn.feedback = feedback.model_dump()
        turn.star_score = feedback.star_score
    else:
        db.add(
            InterviewTurn(
                session_id=session_id,
                question=question,
                answer=answer,
                feedback=feedback.model_dump(),
                star_score=feedback.star_score,
            )
        )
    follow = feedback.follow_up_question
    db.add(InterviewTurn(session_id=session_id, question=follow))
    await db.flush()
    return {
        "session_id": str(session_id),
        "feedback": feedback.model_dump(),
        "follow_up_question": follow,
        "star_score": feedback.star_score,
    }
