from __future__ import annotations

import json
import time
from datetime import date
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.state import GraphState
from app.db.logs import write_agent_log
from app.llm.client import LLMClient, ToolCall, ToolSpec
from app.llm.prompts import TRACKER_SYSTEM
from app.schemas.application import ApplicationCreate, ApplicationFilters
from app.schemas.chat import Msg
from app.tools.tracker_tools import (
    get_applications,
    resolve_relative_date,
    save_application,
    update_application_status,
)

TOOLS = [
    ToolSpec(
        name="save_application",
        description="Create an application row",
        parameters={
            "type": "object",
            "properties": {
                "company": {"type": "string"},
                "role": {"type": "string"},
                "status": {"type": "string"},
                "applied_date": {"type": "string"},
                "notes": {"type": "string"},
            },
            "required": ["company", "role"],
        },
    ),
    ToolSpec(
        name="update_application_status",
        description="Change kanban status",
        parameters={
            "type": "object",
            "properties": {
                "application_id": {"type": "string"},
                "status": {"type": "string"},
            },
            "required": ["application_id", "status"],
        },
    ),
    ToolSpec(
        name="get_applications",
        description="List applications with optional filters",
        parameters={
            "type": "object",
            "properties": {
                "company": {"type": "string"},
                "status": {"type": "string"},
            },
        },
    ),
]


async def run(state: GraphState, llm: LLMClient, db: AsyncSession) -> GraphState:
    started = time.perf_counter()
    today = date.today().isoformat()
    system = TRACKER_SYSTEM.format(today=today)
    messages = list(state["messages"])
    result_payload: dict[str, object] = {}
    for _ in range(4):
        call = await llm.tool_call(system, messages, TOOLS)
        if isinstance(call, str):
            result_payload = {"type": "tracker", "message": call}
            break
        output = await _dispatch(db, state["user_id"], call)
        result_payload = {"type": "tracker", "tool": call.name, "output": output}
        messages.append(Msg(role="assistant", content=json.dumps({"tool": call.name, "output": output})))
        if call.name == "save_application":
            break
    state["result"] = result_payload
    await write_agent_log(
        db,
        user_id=state["user_id"],
        agent="tracker",
        event="tool_loop",
        input_summary=state["messages"][-1].content if state["messages"] else "",
        output_summary=result_payload,
        latency_ms=int((time.perf_counter() - started) * 1000),
    )
    return state


async def _dispatch(db: AsyncSession, user_id: UUID, call: ToolCall) -> dict[str, object]:
    if call.name == "save_application":
        applied = call.arguments.get("applied_date")
        applied_date = resolve_relative_date(str(applied) if applied is not None else "today")
        record = ApplicationCreate(
            company=str(call.arguments.get("company", "")),
            role=str(call.arguments.get("role", "")),
            status=str(call.arguments.get("status", "applied")),  # type: ignore[arg-type]
            applied_date=applied_date,
            notes=call.arguments.get("notes"),  # type: ignore[arg-type]
        )
        app_id = await save_application(db, user_id, record)
        await db.flush()
        return {"id": str(app_id), "company": record.company, "role": record.role, "applied_date": str(applied_date)}
    if call.name == "update_application_status":
        await update_application_status(
            db,
            user_id,
            UUID(str(call.arguments["application_id"])),
            str(call.arguments["status"]),
        )
        return {"updated": True}
    apps = await get_applications(
        db,
        user_id,
        ApplicationFilters(
            company=call.arguments.get("company"),  # type: ignore[arg-type]
            status=call.arguments.get("status"),  # type: ignore[arg-type]
        ),
    )
    return {
        "applications": [
            {"id": str(a.id), "company": a.company, "role": a.role, "status": a.status.value} for a in apps
        ]
    }
