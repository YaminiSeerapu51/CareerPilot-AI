from __future__ import annotations

import base64
import time
from uuid import UUID

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.state import GraphState
from app.db.logs import write_agent_log
from app.db.models import Resume, ResumeChunk
from app.llm.client import LLMClient
from app.schemas.resume import StructuredResume
from app.storage import save_resume_bytes
from app.tools.resume_tools import chunk_resume, embed_chunks, parse_resume


async def run(state: GraphState, llm: LLMClient, db: AsyncSession) -> GraphState:
    started = time.perf_counter()
    att = state["attachments"][0] if state["attachments"] else None
    if att is None or not att.data_b64:
        state["error"] = "Resume upload required"
        await write_agent_log(
            db,
            user_id=state["user_id"],
            agent="resume",
            event="missing_attachment",
            input_summary=state["messages"][-1].content if state["messages"] else "",
            output_summary="no file",
            latency_ms=int((time.perf_counter() - started) * 1000),
            error=state["error"],
        )
        return state
    raw = base64.b64decode(att.data_b64)
    await save_resume_bytes(att.filename, raw)
    structured = await parse_resume(raw, att.filename, llm=llm, user_id=state["user_id"], db=db)
    await db.execute(
        update(Resume).where(Resume.user_id == state["user_id"]).values(is_active=False)
    )
    resume = Resume(
        user_id=state["user_id"],
        raw_text=structured.model_dump_json(),
        structured_json=structured.model_dump(),
        is_active=True,
    )
    db.add(resume)
    await db.flush()
    chunks = chunk_resume(structured)
    vectors = await embed_chunks(chunks)
    for text, vec in zip(chunks, vectors, strict=True):
        db.add(ResumeChunk(resume_id=resume.id, chunk_text=text, embedding=vec))
    await db.flush()
    state["active_resume_id"] = resume.id
    state["result"] = {"type": "resume", "resume": structured.model_dump(), "resume_id": str(resume.id)}
    await write_agent_log(
        db,
        user_id=state["user_id"],
        agent="resume",
        event="parsed",
        input_summary=att.filename,
        output_summary=structured.skills,
        latency_ms=int((time.perf_counter() - started) * 1000),
    )
    return state


async def persist_structured_upload(
    db: AsyncSession,
    user_id: UUID,
    filename: str,
    file_bytes: bytes,
    llm: LLMClient,
) -> StructuredResume:
    state: GraphState = {
        "user_id": user_id,
        "messages": [],
        "intent": "resume",
        "attachments": [],
        "active_resume_id": None,
        "active_jd_id": None,
        "interview_session_id": None,
        "result": None,
        "chain": [],
        "tokens": [],
        "error": None,
    }
    import base64 as b64

    from app.schemas.chat import Attachment

    state["attachments"] = [
        Attachment(filename=filename, content_type="application/octet-stream", data_b64=b64.b64encode(file_bytes).decode())
    ]
    await run(state, llm, db)
    await db.commit()
    assert state["result"] is not None
    return StructuredResume.model_validate(state["result"]["resume"])
