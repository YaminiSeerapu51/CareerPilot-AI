from __future__ import annotations

from typing import Literal, TypedDict
from uuid import UUID

from app.schemas.chat import Attachment, Msg

Intent = Literal["resume", "jobfit", "interview", "tracker", "chitchat"]


class GraphState(TypedDict):
    user_id: UUID
    messages: list[Msg]
    intent: Intent | None
    attachments: list[Attachment]
    active_resume_id: UUID | None
    active_jd_id: UUID | None
    interview_session_id: UUID | None
    result: dict | None
    chain: list[str]
    tokens: list[str]
    error: str | None
