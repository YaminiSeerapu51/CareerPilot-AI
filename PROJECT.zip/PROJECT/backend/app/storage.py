from __future__ import annotations

from pathlib import Path

from app.config import get_settings


def local_resume_dir() -> Path:
    path = Path("data/resumes")
    path.mkdir(parents=True, exist_ok=True)
    return path


async def save_resume_bytes(filename: str, data: bytes) -> str:
    settings = get_settings()
    if settings.resume_bucket:
        import boto3

        key = filename
        boto3.client("s3", region_name=settings.aws_region).put_object(
            Bucket=settings.resume_bucket,
            Key=key,
            Body=data,
        )
        return f"s3://{settings.resume_bucket}/{key}"
    dest = local_resume_dir() / filename
    dest.write_bytes(data)
    return str(dest)
