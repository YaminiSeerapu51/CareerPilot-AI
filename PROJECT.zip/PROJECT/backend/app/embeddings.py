from __future__ import annotations

from functools import lru_cache


@lru_cache
def _model() -> object:
    from sentence_transformers import SentenceTransformer

    return SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")


def embed_texts(texts: list[str]) -> list[list[float]]:
    model = _model()
    encode = getattr(model, "encode")
    vectors = encode(texts, normalize_embeddings=True)
    return [list(map(float, row)) for row in vectors]


def cosine_similarity(a: list[float], b: list[float]) -> float:
    return float(sum(x * y for x, y in zip(a, b, strict=True)))
