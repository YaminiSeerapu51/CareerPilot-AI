from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.resume_agent import persist_structured_upload
from app.auth import get_current_user
from app.config import get_settings
from app.db.models import Resume, User
from app.db.session import get_db
from app.llm.client import get_llm_client
from app.schemas.resume import StructuredResume
from app.tools.resume_tools import UnsupportedFileType

router = APIRouter()
ALLOWED = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/octet-stream",
}


@router.post("/resumes", response_model=StructuredResume)
async def upload_resume(
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> StructuredResume:
    settings = get_settings()
    data = await file.read()
    if len(data) > settings.max_upload_bytes:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "file too large")
    content_type = file.content_type or "application/octet-stream"
    name = file.filename or "resume.pdf"
    if content_type not in ALLOWED and not name.lower().endswith((".pdf", ".docx")):
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "only pdf/docx")
    try:
        return await persist_structured_upload(db, user.id, name, data, get_llm_client())
    except UnsupportedFileType as exc:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, str(exc)) from exc


@router.get("/resumes/active", response_model=StructuredResume)
async def active_resume(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> StructuredResume:
    result = await db.execute(select(Resume).where(Resume.user_id == user.id, Resume.is_active.is_(True)))
    row = result.scalar_one_or_none()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "no active resume")
    return StructuredResume.model_validate(row.structured_json)
