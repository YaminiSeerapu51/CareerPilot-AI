"""
app/api/memory.py
─────────────────
Endpoints allowing authenticated users to inspect, delete, and wipe learned memory facts.
"""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.db.models import User
from app.db.session import get_db
from app.harness.memory.semantic import Fact, SemanticStore

router = APIRouter(prefix="/memory", tags=["memory"])


@router.get("", response_model=list[Fact])
async def list_memory_facts(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[Fact]:
    """Retrieve all active durable facts stored for the current user."""
    store = SemanticStore(db)
    return await store.get_facts(user.id)


@router.delete("/{fact_id}")
async def delete_memory_fact(
    fact_id: UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    """Soft-delete a specific memory fact."""
    store = SemanticStore(db)
    deleted = await store.soft_delete(user.id, fact_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Fact not found or already deleted.")
    await db.commit()
    return {"status": "deleted", "id": str(fact_id)}


@router.delete("")
async def wipe_all_memory(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """Soft-delete all active memory facts for the authenticated user."""
    store = SemanticStore(db)
    count = await store.wipe(user.id)
    await db.commit()
    return {"status": "wiped", "count": count}
