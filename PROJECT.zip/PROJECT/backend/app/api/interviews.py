from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.interview_agent import answer_turn, start_session
from app.auth import get_current_user
from app.db.models import InterviewTurn, User
from app.db.session import get_db
from app.llm.client import get_llm_client
from app.schemas.interview import InterviewAnswer, InterviewStart, STARFeedback
from sqlalchemy import select

router = APIRouter()


@router.post("/interviews")
async def start_interview(
    body: InterviewStart,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    jd_id = UUID(body.jd_id) if body.jd_id else None
    session = await start_session(db, user.id, body.role, jd_id)
    from app.agents.interview_agent import _first_question

    question = await _first_question(db, user.id, body.role)
    db.add(InterviewTurn(session_id=session.id, question=question))
    await db.commit()
    return {"session_id": str(session.id), "question": question}


@router.post("/interviews/{session_id}/answer")
async def answer_interview(
    session_id: UUID,
    body: InterviewAnswer,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, object]:
    payload = await answer_turn(db, get_llm_client(), user.id, session_id, body.text)
    await db.commit()
    feedback = STARFeedback.model_validate(payload["feedback"])
    return {**payload, "feedback": feedback.model_dump()}


@router.get("/interviews/{session_id}")
async def get_session(
    session_id: UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, object]:
    result = await db.execute(select(InterviewTurn).where(InterviewTurn.session_id == session_id))
    turns = list(result.scalars().all())
    return {
        "session_id": str(session_id),
        "turns": [
            {
                "question": t.question,
                "answer": t.answer,
                "star_score": t.star_score,
            }
            for t in turns
        ],
    }
