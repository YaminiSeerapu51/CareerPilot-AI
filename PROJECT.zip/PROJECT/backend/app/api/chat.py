import asyncio
from uuid import UUID

from fastapi import APIRouter, Depends, Header
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.orchestrator import run_chat
from app.auth import get_current_user
from app.db.models import User
from app.db.session import get_db
from app.llm.client import get_llm_client
from app.schemas.chat import ChatRequest

router = APIRouter()

_KEEPALIVE_INTERVAL = 15.0  # seconds


@router.post("/chat")
async def chat(
    body: ChatRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    x_interview_session: str | None = Header(default=None),
) -> StreamingResponse:
    session_id = UUID(x_interview_session) if x_interview_session else None
    llm = get_llm_client()

    async def events():
        # Flush first bytes immediately so proxies and browsers open the stream
        # without waiting for real data.  SSE comments (": …") are ignored by
        # clients but keep the TCP connection alive through any idle timeout.
        yield ": keepalive\n\n"

        agent_gen = run_chat(
            user.id,
            body.message,
            body.attachments,
            llm=llm,
            db=db,
            interview_session_id=session_id,
        )

        while True:
            try:
                # Wait at most _KEEPALIVE_INTERVAL for the next event.
                # If the agent is still thinking, emit a comment so the
                # connection is not dropped by the proxy / load balancer.
                event = await asyncio.wait_for(
                    agent_gen.__anext__(),
                    timeout=_KEEPALIVE_INTERVAL,
                )
                yield f"data: {event.model_dump_json()}\n\n"
            except asyncio.TimeoutError:
                yield ": keepalive\n\n"
            except StopAsyncIteration:
                break

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        # X-Accel-Buffering: no  → tells nginx to disable proxy buffering for
        #                          this response without touching nginx.conf.
        # Cache-Control: no-cache → tells CDNs / browsers not to buffer.
        # Do NOT add Connection: keep-alive — it is a hop-by-hop header and is
        # ignored or actively rejected under HTTP/2.
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
