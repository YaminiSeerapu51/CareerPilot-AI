from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.db.models import Application, User
from app.db.session import get_db

router = APIRouter()


@router.get("/analytics")
async def analytics(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, object]:
    rows = await db.execute(select(Application).where(Application.user_id == user.id))
    apps = list(rows.scalars().all())
    avg_ats = None
    scores = [a.ats_score for a in apps if a.ats_score is not None]
    if scores:
        avg_ats = sum(scores) / len(scores)
    today = date.today()
    weeks: list[dict[str, object]] = []
    for i in range(7, -1, -1):
        start = today - timedelta(days=7 * i)
        end = start + timedelta(days=7)
        count = sum(1 for a in apps if a.applied_date and start <= a.applied_date < end)
        weeks.append({"week_start": start.isoformat(), "count": count})
    return {"applications_per_week": weeks, "avg_ats_score": avg_ats, "total": len(apps)}
