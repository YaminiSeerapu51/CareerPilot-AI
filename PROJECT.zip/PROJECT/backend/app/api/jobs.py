from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.jobfit_agent import run as run_jobfit
from app.agents.state import GraphState
from app.auth import get_current_user
from app.db.models import User
from app.db.session import get_db
from app.llm.client import get_llm_client
from app.llm.guardrails import detect_injection, log_canary
from app.schemas.chat import AnalyzeJobRequest, Msg
from app.schemas.jobfit import JobFitReport

router = APIRouter()


@router.post("/jobs/analyze", response_model=JobFitReport)
async def analyze_job(
    body: AnalyzeJobRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> JobFitReport:
    snippets = detect_injection(body.jd_text)
    if snippets:
        await log_canary(db, user.id, "job_description", snippets)
    state: GraphState = {
        "user_id": user.id,
        "messages": [Msg(role="user", content=body.jd_text)],
        "intent": "jobfit",
        "attachments": [],
        "active_resume_id": None,
        "active_jd_id": None,
        "interview_session_id": None,
        "result": None,
        "chain": [],
        "tokens": [],
        "error": None,
    }
    state = await run_jobfit(state, get_llm_client(), db)
    await db.commit()
    if state.get("error") or not state.get("result"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, state.get("error") or "analysis failed")
    return JobFitReport.model_validate(state["result"]["report"])
