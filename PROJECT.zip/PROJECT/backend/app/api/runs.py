"""
app/api/runs.py
───────────────
Endpoints for inspecting agent runs, span trees, and LLM telemetry.
"""
from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.db.models import Run, SpanModel, User
from app.db.session import get_db

router = APIRouter(prefix="/runs", tags=["runs"])


class RunSummary(BaseModel):
    id: UUID
    root_intent: str
    stop_reason: str | None
    total_tokens_in: int
    total_tokens_out: int
    cost_usd: float
    started_at: str
    ended_at: str | None
    failure_types: list[str]


class SpanOut(BaseModel):
    id: UUID
    parent_id: UUID | None
    kind: str
    name: str
    started_at: str
    latency_ms: int | None
    tokens_in: int
    tokens_out: int
    status: str
    error: str | None
    attrs: dict[str, Any]


class RunDetail(RunSummary):
    spans: list[SpanOut]


@router.get("", response_model=list[RunSummary])
async def list_runs(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[RunSummary]:
    """Lists the most recent agent execution runs for the authenticated user."""
    res = await db.execute(
        select(Run)
        .where(Run.user_id == user.id)
        .order_by(Run.started_at.desc())
        .limit(50)
    )
    rows = res.scalars().all()
    return [
        RunSummary(
            id=r.id,
            root_intent=r.root_intent,
            stop_reason=r.stop_reason,
            total_tokens_in=r.total_tokens_in,
            total_tokens_out=r.total_tokens_out,
            cost_usd=r.cost_usd,
            started_at=r.started_at.isoformat(),
            ended_at=r.ended_at.isoformat() if r.ended_at else None,
            failure_types=r.failure_types or [],
        )
        for r in rows
    ]


@router.get("/{run_id}", response_model=RunDetail)
async def get_run(
    run_id: UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> RunDetail:
    """Retrieve full execution trace and span tree for a specific run."""
    run_res = await db.execute(
        select(Run).where(Run.id == run_id, Run.user_id == user.id)
    )
    run = run_res.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")

    spans_res = await db.execute(
        select(SpanModel).where(SpanModel.run_id == run_id).order_by(SpanModel.started_at.asc())
    )
    spans = spans_res.scalars().all()

    return RunDetail(
        id=run.id,
        root_intent=run.root_intent,
        stop_reason=run.stop_reason,
        total_tokens_in=run.total_tokens_in,
        total_tokens_out=run.total_tokens_out,
        cost_usd=run.cost_usd,
        started_at=run.started_at.isoformat(),
        ended_at=run.ended_at.isoformat() if run.ended_at else None,
        failure_types=run.failure_types or [],
        spans=[
            SpanOut(
                id=s.id,
                parent_id=s.parent_id,
                kind=s.kind,
                name=s.name,
                started_at=s.started_at.isoformat(),
                latency_ms=s.latency_ms,
                tokens_in=s.tokens_in,
                tokens_out=s.tokens_out,
                status=s.status,
                error=s.error,
                attrs=s.attrs or {},
            )
            for s in spans
        ],
    )
