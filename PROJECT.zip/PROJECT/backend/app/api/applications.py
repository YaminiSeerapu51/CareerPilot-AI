from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.db.models import User
from app.db.session import get_db
from app.schemas.application import ApplicationCreate, ApplicationFilters, ApplicationOut, ApplicationPatch
from app.tools.tracker_tools import get_applications, save_application, update_application_status

router = APIRouter()


@router.get("/applications", response_model=list[ApplicationOut])
async def list_applications(
    company: str | None = Query(default=None),
    status_filter: str | None = Query(default=None, alias="status"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[ApplicationOut]:
    rows = await get_applications(db, user.id, ApplicationFilters(company=company, status=status_filter))
    return [ApplicationOut.model_validate(r) for r in rows]


@router.post("/applications", response_model=ApplicationOut)
async def create_application(
    body: ApplicationCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> ApplicationOut:
    app_id = await save_application(db, user.id, body)
    await db.commit()
    rows = await get_applications(db, user.id, ApplicationFilters())
    row = next(r for r in rows if r.id == app_id)
    return ApplicationOut.model_validate(row)


@router.patch("/applications/{application_id}", response_model=ApplicationOut)
async def patch_application(
    application_id: UUID,
    body: ApplicationPatch,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> ApplicationOut:
    await update_application_status(db, user.id, application_id, body.status)
    await db.commit()
    rows = await get_applications(db, user.id, ApplicationFilters())
    row = next((r for r in rows if r.id == application_id), None)
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "not found")
    return ApplicationOut.model_validate(row)
