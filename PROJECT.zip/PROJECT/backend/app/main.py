from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from starlette.middleware.gzip import GZipMiddleware

from app.api import analytics, applications, auth, chat, interviews, jobs, resumes
from app.logging_setup import configure_logging

configure_logging()

app = FastAPI(title="CareerPilot AI")

# ---------------------------------------------------------------------------
# GZip — exclude /api/chat because compression buffers the stream and breaks
# server-sent events.  Every other JSON endpoint benefits from compression.
# ---------------------------------------------------------------------------
class _SelectiveGzip(GZipMiddleware):
    """Skip GZip for the SSE chat endpoint."""

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] == "http" and scope.get("path", "").startswith("/api/chat"):
            # Bypass: call the next layer directly without wrapping the sender.
            await self.app(scope, receive, send)
        else:
            await super().__call__(scope, receive, send)


app.add_middleware(_SelectiveGzip, minimum_size=1000)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from app.api import analytics, applications, auth, chat, interviews, jobs, memory, resumes, runs

app.include_router(auth.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(resumes.router, prefix="/api")
app.include_router(jobs.router, prefix="/api")
app.include_router(interviews.router, prefix="/api")
app.include_router(applications.router, prefix="/api")
app.include_router(analytics.router, prefix="/api")
app.include_router(memory.router, prefix="/api")
app.include_router(runs.router, prefix="/api")


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}
