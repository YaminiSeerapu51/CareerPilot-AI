from __future__ import annotations

from app.schemas.resume import StructuredResume


def extract_jd_keywords(text: str) -> list[str]:
    """Normalized, order-preserving dedupe (UT-06)."""
    raw_parts = []
    for line in text.replace(",", "\n").splitlines():
        token = " ".join(line.strip().lower().split())
        if token:
            raw_parts.append(token)
    seen: set[str] = set()
    out: list[str] = []
    for part in raw_parts:
        for word in _keyword_candidates(part):
            if word not in seen:
                seen.add(word)
                out.append(word)
    return out


def _keyword_candidates(part: str) -> list[str]:
    stop = {
        "and",
        "or",
        "the",
        "a",
        "an",
        "to",
        "of",
        "in",
        "for",
        "with",
        "on",
        "is",
        "are",
        "we",
        "you",
        "our",
        "as",
        "be",
        "by",
        "at",
        "from",
        "this",
        "that",
        "will",
        "have",
        "has",
        "your",
        "their",
    }
    words = [w.strip(".;:()[]") for w in part.split()]
    multi: list[str] = []
    kept = [w for w in words if w and w not in stop and len(w) > 1]
    if len(kept) >= 2 and any(c.isalpha() for c in " ".join(kept)):
        phrase = " ".join(kept)
        if any(ch.isupper() for ch in part) or "-" in phrase or len(kept) <= 3:
            multi.append(phrase)
    singles = [w for w in kept if w not in stop]
    return [*(multi if multi and len(multi[0].split()) <= 4 else []), *singles]


def compute_ats_score(
    resume: StructuredResume,
    jd_keywords: list[str],
    embedding_similarity: float,
) -> float:
    if not jd_keywords:
        coverage = 0.0
    else:
        haystack = _resume_text(resume).lower()
        matched = sum(1 for kw in jd_keywords if kw.lower() in haystack)
        coverage = matched / len(jd_keywords)
    sim = max(0.0, min(1.0, embedding_similarity))
    score = 100.0 * (0.7 * coverage + 0.3 * sim)
    return max(0.0, min(100.0, score))


def _resume_text(resume: StructuredResume) -> str:
    bits = list(resume.skills)
    for exp in resume.experience:
        bits.extend([exp.company, exp.title, *exp.bullets])
    for edu in resume.education:
        bits.extend([edu.institution, edu.degree or "", edu.year or ""])
    return " ".join(bits)


def matched_and_missing(resume: StructuredResume, jd_keywords: list[str]) -> tuple[list[str], list[str]]:
    haystack = _resume_text(resume).lower()
    matched = [kw for kw in jd_keywords if kw.lower() in haystack]
    missing = [kw for kw in jd_keywords if kw.lower() not in haystack]
    return matched, missing
