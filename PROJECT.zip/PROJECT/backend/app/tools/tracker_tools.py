from __future__ import annotations

from datetime import date, datetime
from uuid import UUID

from pydantic import ValidationError
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Application, ApplicationStatus
from app.schemas.application import ApplicationCreate, ApplicationFilters


class SaveApplicationError(ValueError):
    pass


async def save_application(
    db: AsyncSession, user_id: UUID, record: ApplicationCreate | dict[str, object]
) -> UUID:
    try:
        payload = record.model_dump() if isinstance(record, ApplicationCreate) else record
        validated = ApplicationCreate.model_validate(payload)
    except ValidationError as exc:
        raise SaveApplicationError(str(exc)) from exc
    if not validated.company.strip() or not validated.role.strip():
        raise SaveApplicationError("company and role are required")
    app = Application(
        user_id=user_id,
        company=validated.company.strip(),
        role=validated.role.strip(),
        status=ApplicationStatus(validated.status),
        applied_date=validated.applied_date,
        notes=validated.notes,
        jd_id=validated.jd_id,
    )
    db.add(app)
    await db.flush()
    return app.id


async def update_application_status(
    db: AsyncSession, user_id: UUID, application_id: UUID, status: str
) -> None:
    if status not in {s.value for s in ApplicationStatus}:
        raise SaveApplicationError("invalid status")
    await db.execute(
        update(Application)
        .where(Application.id == application_id, Application.user_id == user_id)
        .values(status=ApplicationStatus(status), updated_at=datetime.utcnow())
    )


async def get_applications(
    db: AsyncSession, user_id: UUID, filters: ApplicationFilters
) -> list[Application]:
    stmt = select(Application).where(Application.user_id == user_id)
    if filters.company:
        stmt = stmt.where(Application.company.ilike(f"%{filters.company}%"))
    if filters.status:
        stmt = stmt.where(Application.status == ApplicationStatus(filters.status))
    if filters.since:
        stmt = stmt.where(Application.applied_date >= filters.since)
    stmt = stmt.order_by(Application.updated_at.desc())
    result = await db.execute(stmt)
    return list(result.scalars().all())


def resolve_relative_date(value: str | None, today: date | None = None) -> date | None:
    if value is None:
        return None
    today = today or date.today()
    lowered = value.strip().lower()
    if lowered == "today":
        return today
    weekdays = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    if lowered in weekdays:
        target = weekdays.index(lowered)
        delta = (target - today.weekday()) % 7
        from datetime import timedelta

        return today + timedelta(days=delta)
    try:
        return date.fromisoformat(value)
    except ValueError:
        return today
