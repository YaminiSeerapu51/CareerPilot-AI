from __future__ import annotations

from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Resume, ResumeChunk
from app.embeddings import embed_texts
from app.tools.resume_tools import Chunk


async def vector_search(db: AsyncSession, user_id: UUID, query: str, k: int = 5) -> list[Chunk]:
    vectors = embed_texts([query])
    embedding = vectors[0]
    vec_literal = "[" + ",".join(str(x) for x in embedding) + "]"
    stmt = text(
        """
        SELECT c.id, c.chunk_text, c.resume_id
        FROM resume_chunks c
        JOIN resumes r ON r.id = c.resume_id
        WHERE r.user_id = :user_id AND r.is_active = true
        ORDER BY c.embedding <=> CAST(:embedding AS vector)
        LIMIT :k
        """
    )
    result = await db.execute(stmt, {"user_id": user_id, "embedding": vec_literal, "k": k})
    rows = result.fetchall()
    return [Chunk(id=row[0], text=row[1], resume_id=row[2]) for row in rows]


async def active_resume(db: AsyncSession, user_id: UUID) -> Resume | None:
    result = await db.execute(select(Resume).where(Resume.user_id == user_id, Resume.is_active.is_(True)))
    return result.scalar_one_or_none()
