from __future__ import annotations

from app.llm.client import LLMClient
from app.llm.guardrails import structured, wrap_untrusted
from app.llm.prompts import INTERVIEW_SYSTEM
from app.schemas.chat import Msg
from app.schemas.interview import STARFeedback
from app.tools.resume_tools import Chunk


async def score_answer(
    llm: LLMClient,
    question: str,
    answer: str,
    context_chunks: list[Chunk],
) -> STARFeedback:
    context = "\n".join(f"{c.id}: {c.text}" for c in context_chunks) or "No resume chunks."
    user = (
        f"Question: {wrap_untrusted(question, 'QUESTION')}\n"
        f"Answer: {wrap_untrusted(answer, 'ANSWER')}\n"
        f"Resume context:\n{wrap_untrusted(context, 'RESUME_CHUNKS')}\n"
        "Return STARFeedback JSON."
    )
    try:
        return await structured(llm, STARFeedback, INTERVIEW_SYSTEM, [Msg(role="user", content=user)])
    except Exception:
        length = len(answer.split())
        base = 4 if length > 40 else 2 if length > 10 else 1
        return STARFeedback(
            situation=base,
            task=base,
            action=min(5, base + 1),
            result=base,
            strengths=["Clear communication"] if length > 10 else ["Attempted an answer"],
            improvements=["Add measurable results", "Name specific tools"],
            star_score=float(min(100, base * 20)),
            follow_up_question="Can you quantify the impact of that work?",
        )
