from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from uuid import UUID, uuid4

from app.embeddings import embed_texts
from app.llm.client import LLMClient, get_llm_client
from app.llm.guardrails import detect_injection, structured, wrap_untrusted
from app.llm.prompts import RESUME_PARSE_SYSTEM
from app.schemas.chat import Msg
from app.schemas.resume import StructuredResume


class UnsupportedFileType(ValueError):
    pass


@dataclass
class Chunk:
    id: UUID
    text: str
    resume_id: UUID | None = None


def extract_raw_text(file_bytes: bytes, filename: str) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf"):
        import pdfplumber

        pages: list[str] = []
        with pdfplumber.open(BytesIO(file_bytes)) as pdf:
            for page in pdf.pages:
                pages.append(page.extract_text() or "")
        return "\n".join(pages)
    if lower.endswith(".docx"):
        import docx

        document = docx.Document(BytesIO(file_bytes))
        return "\n".join(p.text for p in document.paragraphs)
    raise UnsupportedFileType(filename)


async def parse_resume(
    file_bytes: bytes,
    filename: str,
    *,
    llm: LLMClient | None = None,
    user_id: UUID | None = None,
    db: object | None = None,
) -> StructuredResume:
    raw = extract_raw_text(file_bytes, filename)
    snippets = detect_injection(raw)
    if snippets and db is not None and user_id is not None:
        from app.llm.guardrails import log_canary
        from sqlalchemy.ext.asyncio import AsyncSession

        await log_canary(db, user_id, "resume_upload", snippets)  # type: ignore[arg-type]
    client = llm or get_llm_client()
    wrapped = wrap_untrusted(raw, "UNTRUSTED_CONTENT")
    try:
        return await structured(
            client,
            StructuredResume,
            RESUME_PARSE_SYSTEM,
            [Msg(role="user", content=wrapped)],
        )
    except Exception:
        return _heuristic_parse(raw)


def _heuristic_parse(raw: str) -> StructuredResume:
    skills: list[str] = []
    for token in (
        "Python",
        "SQL",
        "FastAPI",
        "React",
        "AWS",
        "Docker",
        "TypeScript",
        "Java",
        "Kubernetes",
    ):
        if token.lower() in raw.lower():
            skills.append(token)
    if not skills:
        skills = ["Communication"]
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    name = lines[0] if lines else None
    return StructuredResume(
        name=name,
        email=None,
        skills=skills,
        experience=[],
        education=[],
    )


def chunk_resume(structured_resume: StructuredResume, max_tokens: int = 200) -> list[str]:
    pieces: list[str] = []
    if structured_resume.skills:
        pieces.append("Skills: " + ", ".join(structured_resume.skills))
    for exp in structured_resume.experience:
        block = f"{exp.title} at {exp.company}. " + " ".join(exp.bullets)
        pieces.extend(_split_tokens(block, max_tokens))
    for edu in structured_resume.education:
        pieces.append(f"{edu.degree or 'Study'} at {edu.institution} ({edu.year or ''})")
    if not pieces:
        pieces.append("Empty resume")
    return pieces


def _split_tokens(text: str, max_tokens: int) -> list[str]:
    words = text.split()
    if not words:
        return []
    chunks: list[str] = []
    current: list[str] = []
    for word in words:
        current.append(word)
        if len(current) >= max_tokens:
            chunks.append(" ".join(current))
            current = []
    if current:
        chunks.append(" ".join(current))
    return chunks


async def embed_chunks(chunks: list[str]) -> list[list[float]]:
    vectors = embed_texts(chunks)
    for vec in vectors:
        if len(vec) != 384:
            raise ValueError("embedding dimension must be 384")
    return vectors


def placeholder_chunk_ids(n: int) -> list[UUID]:
    return [uuid4() for _ in range(n)]
