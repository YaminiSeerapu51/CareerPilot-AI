from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

from app.config import get_settings
from app.schemas.chat import Msg


class LLMSchemaError(Exception):
    pass


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]


@dataclass
class ToolCall:
    name: str
    arguments: dict[str, Any]


@runtime_checkable
class LLMClient(Protocol):
    async def complete(self, system: str, messages: list[Msg], *, max_tokens: int = 1000) -> str: ...

    def stream(self, system: str, messages: list[Msg]) -> AsyncIterator[str]: ...

    async def tool_call(
        self, system: str, messages: list[Msg], tools: list[ToolSpec]
    ) -> ToolCall | str: ...


class AnthropicLLM:
    def __init__(self, model: str, api_key: str) -> None:
        self._model = model
        self._api_key = api_key

    def _client(self) -> Any:
        import anthropic

        return anthropic.AsyncAnthropic(api_key=self._api_key)

    def _payload(self, messages: list[Msg]) -> list[dict[str, str]]:
        return [{"role": m.role, "content": m.content} for m in messages if m.role != "system"]

    async def complete(self, system: str, messages: list[Msg], *, max_tokens: int = 1000) -> str:
        client = self._client()
        resp = await client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            system=system,
            messages=self._payload(messages),
        )
        return "".join(block.text for block in resp.content if getattr(block, "type", "") == "text")

    async def stream(self, system: str, messages: list[Msg]) -> AsyncIterator[str]:
        client = self._client()
        async with client.messages.stream(
            model=self._model,
            max_tokens=800,
            system=system,
            messages=self._payload(messages),
        ) as stream:
            async for text in stream.text_stream:
                yield text

    async def tool_call(self, system: str, messages: list[Msg], tools: list[ToolSpec]) -> ToolCall | str:
        client = self._client()
        anth_tools = [
            {
                "name": t.name,
                "description": t.description,
                "input_schema": t.parameters,
            }
            for t in tools
        ]
        resp = await client.messages.create(
            model=self._model,
            max_tokens=1000,
            system=system,
            messages=self._payload(messages),
            tools=anth_tools,
        )
        for block in resp.content:
            if getattr(block, "type", "") == "tool_use":
                return ToolCall(name=block.name, arguments=dict(block.input))
        return "".join(block.text for block in resp.content if getattr(block, "type", "") == "text")


class FakeLLM:
    """Deterministic stand-in. Tests must never hit Anthropic."""

    SYSTEM_CANARY = "CAREERPILOT_SYSTEM_PROMPT_CANARY"

    async def complete(self, system: str, messages: list[Msg], *, max_tokens: int = 1000) -> str:
        user = " ".join(m.content for m in messages if m.role == "user").lower()
        if "ignore previous" in user and "<<<" not in " ".join(m.content for m in messages):
            return system
        if "classify" in system.lower() or "intent" in system.lower():
            if "resume" in user or "upload" in user or ".pdf" in user or ".docx" in user:
                return '{"intent":"resume"}'
            if "interview" in user or "mock" in user:
                return '{"intent":"interview"}'
            if "applied" in user or "kanban" in user or "log that" in user:
                return '{"intent":"tracker"}'
            if "job" in user or "jd" in user or "match" in user or "ats" in user:
                return '{"intent":"jobfit"}'
            return '{"intent":"chitchat"}'
        if "python" in user or "software" in user:
            return (
                '{"name":"Alex Rivera","email":"alex@example.com",'
                '"skills":["Python","SQL","FastAPI"],'
                '"experience":[{"company":"Acme","title":"SWE","start":"2022","end":null,'
                '"bullets":["Built APIs in Python"]}],'
                '"education":[{"institution":"State U","degree":"BS CS","year":"2021"}]}'
            )
        return "I can help with resumes, job-fit scoring, mock interviews, and tracking applications."

    async def stream(self, system: str, messages: list[Msg]) -> AsyncIterator[str]:
        text = await self.complete(system, messages)
        for i in range(0, len(text), 12):
            yield text[i : i + 12]

    async def tool_call(self, system: str, messages: list[Msg], tools: list[ToolSpec]) -> ToolCall | str:
        user = " ".join(m.content for m in messages if m.role == "user")
        lower = user.lower()
        names = {t.name for t in tools}
        if "save_application" in names and ("applied" in lower or "log" in lower):
            company = "Google" if "google" in lower else "Unknown"
            role = "SWE" if "swe" in lower else "Engineer"
            return ToolCall(
                name="save_application",
                arguments={"company": company, "role": role, "status": "applied", "applied_date": "today"},
            )
        if "update_application_status" in names and "status" in lower:
            return ToolCall(
                name="update_application_status",
                arguments={"application_id": "00000000-0000-0000-0000-000000000001", "status": "interviewing"},
            )
        if "get_applications" in names:
            return ToolCall(name="get_applications", arguments={})
        return await self.complete(system, messages)


class LeakyFakeLLM(FakeLLM):
    """Leaks the system prompt if the user text instructs it — used by SEC-05."""

    async def complete(self, system: str, messages: list[Msg], *, max_tokens: int = 1000) -> str:
        blob = " ".join(m.content for m in messages)
        if "Ignore previous instructions" in blob and "<<<UNTRUSTED_CONTENT" not in blob:
            return system
        return "Parsed resume without following injected instructions."


def get_llm_client() -> LLMClient:
    settings = get_settings()
    if settings.llm_mode == "fake" or not settings.anthropic_api_key:
        return FakeLLM()
    model = settings.claude_model()
    return AnthropicLLM(model=model, api_key=settings.anthropic_api_key)
