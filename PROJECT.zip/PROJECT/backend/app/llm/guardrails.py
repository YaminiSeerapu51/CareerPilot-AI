from __future__ import annotations

import json
import re
from typing import TypeVar
from uuid import UUID

from pydantic import BaseModel, ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import InjectionCanary
from app.llm.client import LLMClient, LLMSchemaError
from app.schemas.chat import Msg

T = TypeVar("T", bound=BaseModel)

INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"ignore previous instructions", re.I),
    re.compile(r"reveal (your|the) system prompt", re.I),
    re.compile(r"you are now", re.I),
    re.compile(r"disregard (all|any) (previous|prior)", re.I),
    re.compile(r"<\s*system\s*>", re.I),
]


def wrap_untrusted(text: str, label: str = "UNTRUSTED_CONTENT") -> str:
    escaped = text.replace("<<<", "\\<\\<\\<").replace(">>>", "\\>\\>\\>")
    return f"<<<{label}\n{escaped}\n>>>"


def detect_injection(text: str) -> list[str]:
    hits: list[str] = []
    for pattern in INJECTION_PATTERNS:
        found = pattern.search(text)
        if found:
            hits.append(found.group(0))
    return hits


async def log_canary(db: AsyncSession, user_id: UUID, source: str, snippets: list[str]) -> None:
    for snippet in snippets:
        db.add(InjectionCanary(user_id=user_id, source=source, snippet=snippet))
    await db.flush()


def _extract_json(raw: str) -> str:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?", "", raw).removesuffix("```").strip()
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        return raw[start : end + 1]
    return raw


async def structured(
    llm: LLMClient,
    model: type[T],
    system: str,
    messages: list[Msg],
    *,
    retries: int = 1,
) -> T:
    last_error: str | None = None
    working = list(messages)
    for _attempt in range(retries + 1):
        raw = await llm.complete(system, working)
        try:
            payload = json.loads(_extract_json(raw))
            return model.model_validate(payload)
        except (json.JSONDecodeError, ValidationError) as exc:
            last_error = str(exc)
            working = working + [Msg(role="user", content=f"Your previous output failed validation: {last_error}")]
    raise LLMSchemaError(last_error or "schema validation failed")
