from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field


class Attachment(BaseModel):
    filename: str
    content_type: str
    data_b64: str | None = None


class Msg(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class ChatRequest(BaseModel):
    message: str
    attachments: list[Attachment] = Field(default_factory=list)


class ChatEvent(BaseModel):
    type: Literal["token", "tool", "result", "done", "error"]
    data: Any = None


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class AnalyzeJobRequest(BaseModel):
    jd_text: str


class IntentModel(BaseModel):
    intent: Literal["resume", "jobfit", "interview", "tracker", "chitchat"]
