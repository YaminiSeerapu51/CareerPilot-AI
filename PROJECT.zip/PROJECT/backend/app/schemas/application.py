from datetime import date
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


class ApplicationCreate(BaseModel):
    company: str = Field(min_length=1)
    role: str = Field(min_length=1)
    status: Literal["applied", "interviewing", "offer", "rejected"] = "applied"
    applied_date: date | None = None
    notes: str | None = None
    jd_id: UUID | None = None


class ApplicationFilters(BaseModel):
    company: str | None = None
    status: str | None = None
    since: date | None = None


class ApplicationOut(BaseModel):
    id: UUID
    company: str
    role: str
    status: Literal["applied", "interviewing", "offer", "rejected"]
    applied_date: date | None
    notes: str | None
    jd_id: UUID | None
    ats_score: float | None

    model_config = {"from_attributes": True}

    @field_validator("status", mode="before")
    @classmethod
    def coerce_status(cls, value: object) -> object:
        return getattr(value, "value", value)


class ApplicationPatch(BaseModel):
    status: Literal["applied", "interviewing", "offer", "rejected"]
