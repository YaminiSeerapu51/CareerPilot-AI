from uuid import UUID

from pydantic import BaseModel, Field


class JDKeywords(BaseModel):
    required: list[str]
    preferred: list[str] = Field(default_factory=list)


class BulletRewrite(BaseModel):
    original: str
    rewritten: str
    source_chunk_id: UUID
    keywords_addressed: list[str]


class JobFitReport(BaseModel):
    ats_score: float = Field(ge=0, le=100)
    matched_keywords: list[str]
    missing_keywords: list[str]
    rewrites: list[BulletRewrite] = Field(min_length=3)
