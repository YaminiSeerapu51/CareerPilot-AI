from pydantic import BaseModel, Field


class Experience(BaseModel):
    company: str
    title: str
    start: str | None = None
    end: str | None = None
    bullets: list[str] = Field(default_factory=list)


class Education(BaseModel):
    institution: str
    degree: str | None = None
    year: str | None = None


class StructuredResume(BaseModel):
    name: str | None = None
    email: str | None = None
    skills: list[str] = Field(default_factory=list)
    experience: list[Experience] = Field(default_factory=list)
    education: list[Education] = Field(default_factory=list)
