from pydantic import BaseModel, Field


class STARFeedback(BaseModel):
    situation: int = Field(ge=0, le=5)
    task: int = Field(ge=0, le=5)
    action: int = Field(ge=0, le=5)
    result: int = Field(ge=0, le=5)
    strengths: list[str]
    improvements: list[str]
    star_score: float = Field(ge=0, le=100)
    follow_up_question: str


class InterviewStart(BaseModel):
    role: str | None = None
    jd_id: str | None = None


class InterviewAnswer(BaseModel):
    text: str
