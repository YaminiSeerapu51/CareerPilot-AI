from __future__ import annotations

import asyncio
from datetime import date, timedelta

from sqlalchemy import select

from app.auth import hash_password
from app.config import get_settings
from app.db.models import Application, ApplicationStatus, User
from app.db.session import SessionLocal

# ---------------------------------------------------------------------------
# Demo applications — realistic spread across all four Kanban columns.
#
# Only application rows are seeded here.  Resume parsing, ATS scoring, and
# interview coaching are NOT pre-faked; those features must be demonstrated
# live so the agent pipeline is real during a demo.
# ---------------------------------------------------------------------------
_DEMO_APPLICATIONS: list[dict] = [
    {
        "company": "Stripe",
        "role": "Senior Backend Engineer",
        "status": ApplicationStatus.offer,
        "applied_date": date.today() - timedelta(days=28),
        "ats_score": 91.0,
        "notes": "Passed system design round. Offer: $195k base + equity. Decision due Friday.",
    },
    {
        "company": "Datadog",
        "role": "Software Engineer II — Distributed Systems",
        "status": ApplicationStatus.interviewing,
        "applied_date": date.today() - timedelta(days=19),
        "ats_score": 84.0,
        "notes": "Completed phone screen. Onsite loop scheduled: system design + 2x coding + behavioural.",
    },
    {
        "company": "Google",
        "role": "Software Engineer L4",
        "status": ApplicationStatus.interviewing,
        "applied_date": date.today() - timedelta(days=14),
        "ats_score": 78.0,
        "notes": "Recruiter call done. Coding rounds next week. Prep: trees, graphs, dynamic programming.",
    },
    {
        "company": "Notion",
        "role": "Full-Stack Engineer",
        "status": ApplicationStatus.applied,
        "applied_date": date.today() - timedelta(days=9),
        "ats_score": 76.0,
        "notes": "Applied via referral from Alex. Strong React + real-time collab match.",
    },
    {
        "company": "Anthropic",
        "role": "Software Engineer — Product",
        "status": ApplicationStatus.applied,
        "applied_date": date.today() - timedelta(days=6),
        "ats_score": 72.0,
        "notes": "Tailored resume bullets to highlight LLM / agentic AI work.",
    },
    {
        "company": "Vercel",
        "role": "Infrastructure Engineer",
        "status": ApplicationStatus.applied,
        "applied_date": date.today() - timedelta(days=3),
        "ats_score": 68.0,
        "notes": "Strong fit on edge compute + Terraform IaC experience.",
    },
    {
        "company": "Palantir",
        "role": "Forward Deployed Engineer",
        "status": ApplicationStatus.rejected,
        "applied_date": date.today() - timedelta(days=35),
        "ats_score": 61.0,
        "notes": "Rejected after first round. Feedback: wanted stronger data pipeline experience.",
    },
    {
        "company": "Figma",
        "role": "Backend Engineer — Collaboration",
        "status": ApplicationStatus.rejected,
        "applied_date": date.today() - timedelta(days=42),
        "ats_score": 58.0,
        "notes": "No response after final round. Followed up twice.",
    },
]


async def seed() -> None:
    settings = get_settings()
    async with SessionLocal() as db:
        # ------------------------------------------------------------------ #
        # 1. Upsert the demo user                                             #
        # ------------------------------------------------------------------ #
        existing_user = (
            await db.execute(select(User).where(User.email == settings.seed_user_email))
        ).scalar_one_or_none()

        if existing_user is None:
            user = User(
                email=settings.seed_user_email,
                password_hash=hash_password(settings.seed_user_password),
            )
            db.add(user)
            await db.flush()
        else:
            user = existing_user

        # ------------------------------------------------------------------ #
        # 2. Skip if demo applications already exist (idempotent)             #
        # ------------------------------------------------------------------ #
        already_seeded = (
            await db.execute(
                select(Application).where(Application.user_id == user.id).limit(1)
            )
        ).scalar_one_or_none()

        if already_seeded is not None:
            await db.commit()
            return

        # ------------------------------------------------------------------ #
        # 3. Seed applications                                                #
        # ------------------------------------------------------------------ #
        for app_data in _DEMO_APPLICATIONS:
            db.add(
                Application(
                    user_id=user.id,
                    company=app_data["company"],
                    role=app_data["role"],
                    status=app_data["status"],
                    applied_date=app_data["applied_date"],
                    ats_score=app_data["ats_score"],
                    notes=app_data["notes"],
                )
            )

        await db.commit()


if __name__ == "__main__":
    asyncio.run(seed())
