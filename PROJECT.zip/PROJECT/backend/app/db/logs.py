from __future__ import annotations

from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import AgentLog
from app.logging_setup import summarize


async def write_agent_log(
    db: AsyncSession,
    *,
    user_id: UUID | None,
    agent: str,
    event: str,
    input_summary: Any,
    output_summary: Any,
    latency_ms: int,
    error: str | None = None,
    commit: bool = False,
) -> None:
    db.add(
        AgentLog(
            user_id=user_id,
            agent=agent,
            event=event,
            input_summary=summarize(input_summary),
            output_summary=summarize(output_summary),
            latency_ms=latency_ms,
            error=error,
        )
    )
    if commit:
        await db.commit()
