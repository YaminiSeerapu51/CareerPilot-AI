# CareerPilot AI

Private, single-user agentic job-search copilot: parse a resume, score a job description, run a mock interview, and track applications.

## Architecture

See `docs/ARCHITECTURE.md`. Edge TLS in AWS is **nginx on EC2** (self-signed), not an ALB.

```
Browser --HTTPS allowlisted IP--> nginx (EC2)
                                 |-- frontend (React)
                                 |-- backend (FastAPI + LangGraph)
                                      |-- Postgres + pgvector
                                      |-- Claude via app/llm/client.py
                                      |-- MiniLM embeddings (local)
```

## Local setup

```bash
cp .env.example .env
# set JWT_SECRET and SEED_USER_PASSWORD; leave LLM_MODE=fake for tests
docker compose up --build
```

- API: http://localhost:8000/healthz
- UI: http://localhost:5173 (compose frontend) or http://localhost (nginx)
- Login: `SEED_USER_EMAIL` / `SEED_USER_PASSWORD` from `.env`

Backend only:

```bash
cd backend
python -m venv .venv
.venv/Scripts/activate   # Windows
pip install -e ".[dev]"
python tests/generate_fixtures.py
alembic upgrade head
python -m app.db.seed
LLM_MODE=fake uvicorn app.main:app --reload
```

Frontend only: `cd frontend && npm install && npm run dev`

## Tests

Tests **never** call Anthropic (`LLM_MODE=fake` / `FakeLLM`).

```bash
cd backend && pytest --cov=app/agents --cov=app/tools --cov-fail-under=70
cd frontend && npm test && npm run lint
cd frontend && npx playwright test   # needs compose stack
```

## AWS

1. Fill `infra/terraform` variables (`allowed_ip_cidrs` has **no default**).
2. `infra/bootstrap` creates the state bucket + DynamoDB lock.
3. Apply main stack. Values for Secrets Manager are set out-of-band.
4. Deploy containers via GitHub Actions CD (OIDC, manual `production` environment) and `scripts/deploy_ssm.sh`.
5. `terraform destroy` is intended to run clean (`force_destroy = true` on buckets — see `docs/DECISIONS.md`).

Security scripts: `scripts/sec_aws_checks.sh`, `scripts/check_no_secrets.sh`.

## Cost note (NFR-4/5)

Expect roughly **one `t3.small` + 30 GB gp3 + Secrets Manager + CloudWatch logs + a small S3 bucket**. At 2026 on-demand us-east-1 pricing this is typically **tens of USD per month**, plus Claude API usage if `LLM_MODE` is not `fake`. A budget alarm fires at `budget_limit_usd`.

## Latency (NFR-2)

p95 single-turn latency with `LLM_MODE=fake` over 20 sample `/api/chat` calls: **recorded after local soak as < 8s** (see `docs/evidence/latency.txt`). Live Claude (Haiku/Sonnet) will be slower and depends on Anthropic.

## Limitations

Single instance, single user, self-signed TLS. v2 roadmap in `docs/LIMITATIONS.md`.

Out of scope: Cognito, Fargate+ALB, multi-AZ, Langfuse, Voyage embeddings, multi-user.
