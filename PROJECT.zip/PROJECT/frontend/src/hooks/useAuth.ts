import { useEffect, useState } from "react";
import { token } from "../api/client";

export function useAuth() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  useEffect(() => {
    setAuthed(Boolean(token()));
    setReady(true);
  }, []);
  return { ready, authed };
}
