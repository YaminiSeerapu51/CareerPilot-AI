import { useCallback, useState } from "react";
import { streamChat, type ChatEvent } from "../api/client";

export function useSSE() {
  const [tokens, setTokens] = useState("");
  const [result, setResult] = useState<unknown>(null);
  const [streaming, setStreaming] = useState(false);

  const send = useCallback(async (
    message: string,
    attachments: { filename: string; content_type: string; data_b64: string }[],
  ) => {
    setTokens("");
    setResult(null);
    setStreaming(true);
    await streamChat(message, attachments, (ev: ChatEvent) => {
      if (ev.type === "token") setTokens((t) => t + String(ev.data));
      if (ev.type === "result") setResult(ev.data);
      if (ev.type === "done" || ev.type === "error") setStreaming(false);
    });
    setStreaming(false);
  }, []);

  return { tokens, result, streaming, send };
}
