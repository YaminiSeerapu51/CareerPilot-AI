export type ChatEvent = {
  type: "token" | "tool" | "result" | "done" | "error";
  data: unknown;
};

export type StructuredResume = {
  name: string | null;
  email: string | null;
  skills: string[];
  experience: { company: string; title: string; bullets: string[] }[];
  education: { institution: string; degree: string | null; year: string | null }[];
};

export type JobFitReport = {
  ats_score: number;
  matched_keywords: string[];
  missing_keywords: string[];
  rewrites: {
    original: string;
    rewritten: string;
    source_chunk_id: string;
    keywords_addressed: string[];
  }[];
};

export type Application = {
  id: string;
  company: string;
  role: string;
  status: "applied" | "interviewing" | "offer" | "rejected";
  applied_date: string | null;
  notes: string | null;
  ats_score: number | null;
};

const API = "";

export function token(): string | null {
  return localStorage.getItem("cp_token");
}

export function setToken(value: string): void {
  localStorage.setItem("cp_token", value);
}

export function clearToken(): void {
  localStorage.removeItem("cp_token");
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const t = token();
  if (t) headers.set("Authorization", `Bearer ${t}`);
  if (!(init.body instanceof FormData) && !headers.has("Content-Type") && init.body) {
    headers.set("Content-Type", "application/json");
  }
  const res = await fetch(`${API}${path}`, { ...init, headers });
  if (res.status === 401) {
    clearToken();
    if (!path.includes("/auth/login")) window.location.assign("/login");
    throw new Error("unauthorized");
  }
  if (!res.ok) {
    throw new Error(await res.text());
  }
  return (await res.json()) as T;
}

export function login(email: string, password: string) {
  return request("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
}

export function uploadResume(file: File) {
  const data = new FormData();
  data.append("file", file);
  return request("/api/resumes", { method: "POST", body: data });
}

export function analyzeJob(jd_text: string) {
  return request("/api/jobs/analyze", { method: "POST", body: JSON.stringify({ jd_text }) });
}

export function listApplications() {
  return request("/api/applications");
}

export function createApplication(body: {
  company: string;
  role: string;
  status?: Application["status"];
}) {
  return request("/api/applications", { method: "POST", body: JSON.stringify(body) });
}

export function patchApplication(id: string, status: Application["status"]) {
  return request(`/api/applications/${id}`, { method: "PATCH", body: JSON.stringify({ status }) });
}

export function analytics(): Promise<{
  applications_per_week: { week_start: string; count: number }[];
  avg_ats_score: number | null;
  total: number;
}> {
  return request("/api/analytics");
}

export function startInterview(role: string) {
  return request("/api/interviews", { method: "POST", body: JSON.stringify({ role }) });
}

export function answerInterview(
  id: string,
  text: string,
) {
  return request(`/api/interviews/${id}/answer`, { method: "POST", body: JSON.stringify({ text }) });
}

export function getInterview(id: string) {
  return request(`/api/interviews/${id}`);
}

export async function streamChat(
  message: string,
  attachments: { filename: string; content_type: string; data_b64: string }[],
  onEvent: (ev: ChatEvent) => void,
) {
  const t = token();
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(t ? { Authorization: `Bearer ${t}` } : {}),
    },
    body: JSON.stringify({ message, attachments }),
  });
  if (res.status === 401) {
    clearToken();
    window.location.assign("/login");
    return;
  }
  const reader = res.body?.getReader();
  if (!reader) return;
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const parts = buf.split("\n\n");
    buf = parts.pop() ?? "";
    for (const part of parts) {
      const line = part.replace(/^data:\s*/, "").trim();
      if (!line) continue;
      onEvent(JSON.parse(line) as ChatEvent);
    }
  }
}
