import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  analytics,
  createApplication,
  listApplications,
  type Application,
} from "../api/client";
import KanbanBoard from "../components/KanbanBoard";
import ApplicationsChart from "../components/charts/ApplicationsChart";
import AtsChart from "../components/charts/AtsChart";

export default function Dashboard() {
  const [apps, setApps] = useState<Application[] | null>(null);
  const [weeks, setWeeks] = useState<{ week_start: string; count: number }[]>([]);
  const [avg, setAvg] = useState<number | null>(null);
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");

  async function refresh() {
    const [rows, stats] = await Promise.all([listApplications(), analytics()]);
    setApps(rows);
    setWeeks(stats.applications_per_week);
    setAvg(stats.avg_ats_score);
  }

  useEffect(() => {
    void refresh();
  }, []);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    await createApplication({ company, role, status: "applied" });
    setCompany("");
    setRole("");
    await refresh();
  }

  return (
    <div className="mx-auto max-w-6xl p-6">
      <header className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold">Applications</h1>
        <Link className="text-sm underline" to="/">
          Chat
        </Link>
      </header>
      <form onSubmit={onCreate} className="mb-6 flex gap-2">
        <input
          placeholder="Company"
          className="rounded border px-3 py-2"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
          required
        />
        <input
          placeholder="Role"
          className="rounded border px-3 py-2"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
        />
        <button className="rounded bg-slate-900 px-4 py-2 text-white" type="submit">
          Add
        </button>
      </form>
      {apps && apps.length === 0 ? (
        <p data-testid="empty-dashboard" className="mb-6 rounded border border-dashed p-8 text-center text-slate-600">
          No applications yet. Log one in chat or use the form above.
        </p>
      ) : null}
      {apps ? <KanbanBoard items={apps} onChange={setApps} /> : <p>Loading…</p>}
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <ApplicationsChart data={weeks} />
        <AtsChart avg={avg} />
      </div>
    </div>
  );
}
