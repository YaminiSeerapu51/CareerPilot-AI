import { Link } from "react-router-dom";
import ChatWindow from "../components/ChatWindow";

export default function Chat() {
  return (
    <div className="mx-auto max-w-5xl p-6">
      <header className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold">CareerPilot Chat</h1>
        <Link className="text-sm underline" to="/dashboard">
          Dashboard
        </Link>
      </header>
      <ChatWindow />
    </div>
  );
}
