import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { describe, expect, it, vi } from "vitest";
import Dashboard from "../pages/Dashboard";

vi.mock("../api/client", () => ({
  listApplications: async () => [],
  analytics: async () => ({ applications_per_week: [], avg_ats_score: null, total: 0 }),
  createApplication: async () => ({}),
  patchApplication: async () => ({}),
}));

describe("Dashboard empty", () => {
  it("shows empty state", async () => {
    render(
      <MemoryRouter>
        <Dashboard />
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("empty-dashboard")).toBeInTheDocument();
  });
});
