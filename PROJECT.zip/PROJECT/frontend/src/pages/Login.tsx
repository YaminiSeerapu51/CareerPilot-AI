import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login, setToken } from "../api/client";

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("demo@careerpilot.local");
  const [password, setPassword] = useState("changeme");
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = await login(email, password);
      setToken(res.access_token);
      nav("/");
    } catch {
      setError("Invalid credentials");
    }
  }

  return (
    <main className="mx-auto mt-24 max-w-md rounded-xl border bg-white p-8 shadow-sm">
      <h1 className="mb-6 text-2xl font-semibold">CareerPilot AI</h1>
      <form onSubmit={onSubmit} className="space-y-4">
        <label className="block text-sm">
          Email
          <input
            className="mt-1 w-full rounded border px-3 py-2"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label className="block text-sm">
          Password
          <input
            type="password"
            className="mt-1 w-full rounded border px-3 py-2"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        {error ? <p className="text-sm text-red-600">{error}</p> : null}
        <button className="w-full rounded bg-slate-900 py-2 text-white" type="submit">
          Sign in
        </button>
      </form>
    </main>
  );
}
