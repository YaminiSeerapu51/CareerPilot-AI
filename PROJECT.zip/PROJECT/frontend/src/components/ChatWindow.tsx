import { useState } from "react";
import { useSSE } from "../hooks/useSSE";
import BulletRewrites from "./BulletRewrites";
import InterviewPanel from "./InterviewPanel";
import MessageBubble from "./MessageBubble";
import ResumeUpload from "./ResumeUpload";
import ScoreCard from "./ScoreCard";
import type { JobFitReport, StructuredResume } from "../api/client";

type Msg = { role: "user" | "assistant"; text: string };

function fileToB64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const s = String(reader.result);
      resolve(s.split(",")[1] ?? "");
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function ChatWindow() {
  const { tokens, result, streaming, send } = useSSE();
  const [input, setInput] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [history, setHistory] = useState<Msg[]>([]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const attachments = file
      ? [
          {
            filename: file.name,
            content_type: file.type || "application/octet-stream",
            data_b64: await fileToB64(file),
          },
        ]
      : [];
    setHistory((h) => [...h, { role: "user", text: input || (file ? `Uploaded ${file.name}` : "") }]);
    await send(input || "Please parse this resume.", attachments);
    setInput("");
    setFile(null);
  }

  const report = isJobFit(result);
  const resume = isResume(result);
  const interview = isInterview(result);

  return (
    <div className="grid gap-4 md:grid-cols-[2fr,1fr]">
      <section className="rounded-xl border bg-white p-4 shadow-sm">
        <div className="mb-4 min-h-[240px] space-y-2">
          {history.map((m, i) => (
            <MessageBubble key={i} role={m.role} text={m.text} />
          ))}
          {(tokens || streaming) && <MessageBubble role="assistant" text={tokens || "…"} />}
        </div>
        <form onSubmit={onSubmit} className="flex flex-col gap-2">
          <ResumeUpload file={file} onFile={setFile} />
          <textarea
            className="min-h-[80px] w-full rounded border px-3 py-2"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask to parse a resume, paste a JD, start an interview, or log an application…"
          />
          <button className="rounded bg-slate-900 px-4 py-2 text-white" disabled={streaming} type="submit">
            Send
          </button>
        </form>
      </section>
      <aside className="space-y-4">
        {resume ? (
          <div className="rounded-xl border bg-white p-4" data-testid="resume-card">
            <h2 className="font-medium">Parsed resume</h2>
            <p>{resume.name}</p>
            <p className="text-sm">{resume.skills.join(", ")}</p>
          </div>
        ) : null}
        {report ? (
          <>
            <ScoreCard score={report.ats_score} missing={report.missing_keywords} matched={report.matched_keywords} />
            <BulletRewrites rewrites={report.rewrites} />
          </>
        ) : null}
        {interview ? <InterviewPanel data={interview} /> : null}
      </aside>
    </div>
  );
}

function isJobFit(result: unknown): JobFitReport | null {
  if (result && typeof result === "object" && "report" in result) {
    return (result as { report: JobFitReport }).report;
  }
  return null;
}

function isResume(result: unknown): StructuredResume | null {
  if (result && typeof result === "object" && "resume" in result) {
    return (result as { resume: StructuredResume }).resume;
  }
  return null;
}

function isInterview(result: unknown): Record<string, unknown> | null {
  if (result && typeof result === "object" && "type" in result && (result as { type: string }).type === "interview") {
    return result as Record<string, unknown>;
  }
  return null;
}
