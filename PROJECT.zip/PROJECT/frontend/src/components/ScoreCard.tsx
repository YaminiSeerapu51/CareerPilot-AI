export default function ScoreCard({
  score,
  missing,
  matched,
}: {
  score: number;
  missing: string[];
  matched: string[];
}) {
  return (
    <div className="rounded-xl border bg-white p-4" data-testid="score-card">
      <p className="text-sm text-slate-500">ATS score</p>
      <p className="text-3xl font-semibold">{Math.round(score)}</p>
      <p className="mt-2 text-sm">
        <span className="font-medium">Matched:</span> {matched.join(", ") || "—"}
      </p>
      <p className="text-sm">
        <span className="font-medium">Missing:</span> {missing.join(", ") || "—"}
      </p>
    </div>
  );
}
