import { DndContext, useDraggable, useDroppable, type DragEndEvent } from "@dnd-kit/core";
import { useState } from "react";
import { patchApplication, type Application } from "../api/client";
import ApplicationCard from "./ApplicationCard";

const COLUMNS: Application["status"][] = ["applied", "interviewing", "offer", "rejected"];

export default function KanbanBoard({
  items,
  onChange,
}: {
  items: Application[];
  onChange: (next: Application[]) => void;
}) {
  const [error, setError] = useState<string | null>(null);

  async function onDragEnd(event: DragEndEvent) {
    const id = String(event.active.id);
    const over = event.over?.id ? String(event.over.id) : null;
    if (!over || !COLUMNS.includes(over as Application["status"])) return;
    const status = over as Application["status"];
    const prev = items;
    onChange(items.map((a) => (a.id === id ? { ...a, status } : a)));
    try {
      await patchApplication(id, status);
      setError(null);
    } catch {
      onChange(prev);
      setError("Could not update status");
    }
  }

  return (
    <DndContext onDragEnd={(e) => void onDragEnd(e)}>
      {error ? <p className="mb-2 text-sm text-red-600">{error}</p> : null}
      <div className="grid gap-3 md:grid-cols-4">
        {COLUMNS.map((col) => (
          <Column key={col} status={col} items={items.filter((a) => a.status === col)} />
        ))}
      </div>
    </DndContext>
  );
}

function Column({ status, items }: { status: Application["status"]; items: Application[] }) {
  const { setNodeRef, isOver } = useDroppable({ id: status });
  return (
    <section
      ref={setNodeRef}
      className={`min-h-[200px] rounded-xl p-3 ${isOver ? "bg-slate-200" : "bg-slate-100"}`}
      data-status={status}
    >
      <h2 className="mb-2 text-sm font-semibold capitalize">{status}</h2>
      <div className="space-y-2">
        {items.map((a) => (
          <DraggableCard key={a.id} app={a} />
        ))}
      </div>
    </section>
  );
}

function DraggableCard({ app }: { app: Application }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({ id: app.id });
  const style = transform ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` } : undefined;
  return (
    <div ref={setNodeRef} style={style} {...listeners} {...attributes} data-app-id={app.id}>
      <ApplicationCard company={app.company} role={app.role} status={app.status} />
    </div>
  );
}
