import type { JobFitReport } from "../api/client";

export default function BulletRewrites({ rewrites }: { rewrites: JobFitReport["rewrites"] }) {
  return (
    <div className="rounded-xl border bg-white p-4" data-testid="rewrites">
      <h2 className="mb-2 font-medium">Grounded rewrites</h2>
      <ul className="space-y-3 text-sm">
        {rewrites.map((r) => (
          <li key={r.source_chunk_id + r.rewritten} className="rounded bg-slate-50 p-2">
            <p className="text-slate-500 line-through">{r.original}</p>
            <p>{r.rewritten}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
