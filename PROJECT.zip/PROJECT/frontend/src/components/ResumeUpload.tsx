import { DragEvent } from "react";

export default function ResumeUpload({
  file,
  onFile,
}: {
  file: File | null;
  onFile: (f: File | null) => void;
}) {
  function onDrop(e: DragEvent) {
    e.preventDefault();
    const next = e.dataTransfer.files[0];
    if (next) onFile(next);
  }

  return (
    <label
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
      className="block cursor-pointer rounded border border-dashed p-4 text-center text-sm text-slate-600"
    >
      {file ? file.name : "Drop a PDF/DOCX resume or click to upload"}
      <input
        type="file"
        accept=".pdf,.docx"
        className="hidden"
        onChange={(e) => onFile(e.target.files?.[0] ?? null)}
      />
    </label>
  );
}
