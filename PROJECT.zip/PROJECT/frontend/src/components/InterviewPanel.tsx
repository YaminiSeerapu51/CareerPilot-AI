import { FormEvent, useEffect, useState } from "react";
import { answerInterview, getInterview, startInterview } from "../api/client";

export default function InterviewPanel({ data }: { data: Record<string, unknown> }) {
  const [sessionId, setSessionId] = useState(String(data.session_id ?? localStorage.getItem("cp_interview") ?? ""));
  const [question, setQuestion] = useState(String(data.question ?? data.follow_up_question ?? ""));
  const [answer, setAnswer] = useState("");
  const [score, setScore] = useState<number | null>(typeof data.star_score === "number" ? data.star_score : null);

  useEffect(() => {
    if (sessionId) localStorage.setItem("cp_interview", sessionId);
  }, [sessionId]);

  useEffect(() => {
    const stored = localStorage.getItem("cp_interview");
    if (stored) {
      void getInterview(stored).then((s) => {
        setSessionId(s.session_id);
        const last = s.turns[s.turns.length - 1];
        if (last) setQuestion(last.question);
      });
    }
  }, []);

  async function onStart() {
    const res = await startInterview("Software Engineer");
    setSessionId(res.session_id);
    setQuestion(res.question);
    localStorage.setItem("cp_interview", res.session_id);
  }

  async function onAnswer(e: FormEvent) {
    e.preventDefault();
    if (!sessionId) return;
    const res = await answerInterview(sessionId, answer);
    setScore(res.star_score);
    setQuestion(res.follow_up_question);
    setAnswer("");
  }

  return (
    <div className="rounded-xl border bg-white p-4" data-testid="interview-panel">
      <h2 className="mb-2 font-medium">Mock interview</h2>
      {!sessionId ? (
        <button className="rounded bg-slate-900 px-3 py-1 text-white" onClick={() => void onStart()}>
          Start
        </button>
      ) : (
        <>
          <p className="text-sm">{question}</p>
          {score !== null ? <p className="text-sm">STAR score: {score}</p> : null}
          <form onSubmit={onAnswer} className="mt-2 space-y-2">
            <textarea className="w-full rounded border p-2 text-sm" value={answer} onChange={(e) => setAnswer(e.target.value)} />
            <button className="rounded bg-slate-900 px-3 py-1 text-white" type="submit">
              Answer
            </button>
          </form>
        </>
      )}
    </div>
  );
}
