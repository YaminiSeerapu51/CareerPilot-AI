export default function ApplicationCard({
  company,
  role,
  status,
}: {
  company: string;
  role: string;
  status: string;
}) {
  return (
    <article className="rounded-lg border bg-white p-3 shadow-sm" data-testid="application-card">
      <p className="font-medium">{company}</p>
      <p className="text-sm text-slate-600">{role}</p>
      <p className="text-xs uppercase text-slate-400">{status}</p>
    </article>
  );
}
