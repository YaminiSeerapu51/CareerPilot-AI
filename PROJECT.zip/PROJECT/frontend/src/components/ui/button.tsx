import type { ButtonHTMLAttributes } from "react";

export function Button(props: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={`inline-flex items-center justify-center rounded-md bg-slate-900 px-3 py-2 text-sm text-white ${props.className ?? ""}`}
    />
  );
}
