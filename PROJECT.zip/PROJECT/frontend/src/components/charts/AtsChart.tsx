import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";

export default function AtsChart({ avg }: { avg: number | null }) {
  const value = avg ?? 0;
  const data = [
    { name: "score", value },
    { name: "rest", value: Math.max(0, 100 - value) },
  ];
  return (
    <div className="h-64 rounded-xl border bg-white p-4" data-testid="ats-chart">
      <h2 className="mb-2 text-sm font-medium">Average ATS score</h2>
      <p className="text-2xl font-semibold">{avg === null ? "—" : Math.round(avg)}</p>
      <ResponsiveContainer width="100%" height="70%">
        <PieChart>
          <Pie data={data} dataKey="value" innerRadius={40} outerRadius={70}>
            <Cell fill="#0f172a" />
            <Cell fill="#e2e8f0" />
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
