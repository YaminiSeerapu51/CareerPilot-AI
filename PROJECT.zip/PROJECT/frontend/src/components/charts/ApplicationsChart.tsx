import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export default function ApplicationsChart({ data }: { data: { week_start: string; count: number }[] }) {
  return (
    <div className="h-64 rounded-xl border bg-white p-4" data-testid="apps-chart">
      <h2 className="mb-2 text-sm font-medium">Applications per week</h2>
      <ResponsiveContainer width="100%" height="90%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="week_start" hide />
          <YAxis allowDecimals={false} />
          <Tooltip />
          <Bar dataKey="count" fill="#0f172a" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
