import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import ScoreCard from "../components/ScoreCard";

describe("ScoreCard", () => {
  it("renders score", () => {
    render(<ScoreCard score={72} matched={["python"]} missing={["k8s"]} />);
    expect(screen.getByText("72")).toBeInTheDocument();
    expect(screen.getByText(/k8s/)).toBeInTheDocument();
  });
});
