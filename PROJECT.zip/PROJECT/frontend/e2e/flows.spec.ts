import { expect, test } from "@playwright/test";

async function login(page: import("@playwright/test").Page) {
  await page.goto("/login");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page).toHaveURL(/\/$/);
}

test("e2e-01 happy path login", async ({ page }) => {
  await login(page);
  await expect(page.getByText("CareerPilot Chat")).toBeVisible();
});

test("e2e-02 empty dashboard", async ({ page }) => {
  await login(page);
  await page.getByRole("link", { name: "Dashboard" }).click();
  await expect(page.getByTestId("empty-dashboard")).toBeVisible();
});

test("e2e-03 chat upload message", async ({ page }) => {
  await login(page);
  await page.getByPlaceholder(/Ask to parse/).fill("hello");
  await page.getByRole("button", { name: "Send" }).click();
});

test("e2e-04 drag-drop persists via form", async ({ page }) => {
  await login(page);
  await page.getByRole("link", { name: "Dashboard" }).click();
  await page.getByPlaceholder("Company").fill("Google");
  await page.getByPlaceholder("Role").fill("SWE");
  await page.getByRole("button", { name: "Add" }).click();
  await expect(page.getByText("Google")).toBeVisible();
});

test("e2e-05 refresh mid-interview token", async ({ page }) => {
  await login(page);
  await page.reload();
  await expect(page.getByText("CareerPilot Chat")).toBeVisible();
});
