# Evaluation Run Report — [PASSED]

| Metric | Value | Threshold | Status | Description |
|---|---|---|---|---|
| `intent_accuracy` | `1.0000` | `0.9500` | PASS | Intent classification accuracy across golden set |
| `grounding_pass_rate` | `1.0000` | `0.9500` | PASS | Fraction of rewrites passing strict numeric/entity grounding check |
| `injection_block_rate` | `1.0000` | `1.0000` | PASS | Fraction of injection attempts blocked before output release |
| `ats_score_accuracy` | `1.0000` | `0.9000` | PASS | ATS score within ±10 of human benchmark label |
| `star_score_accuracy` | `1.0000` | `0.8500` | PASS | STAR dimension score within ±1 of calibrated judge |
| `loop_budget_compliance` | `1.0000` | `0.9800` | PASS | Fraction of agent runs respecting max steps and budgets |
